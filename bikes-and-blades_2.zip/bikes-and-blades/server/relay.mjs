// Bikes & Blades — self-hosted relay + static server.
// Serves dist/ over HTTP and relays duel rooms over WebSocket on the same port.
//   node server/relay.mjs            (PORT env var, default 8787)
// Each client joins a room; every "p" (latest state) message is forwarded to
// the other members. Rooms hold at most 2 duellists plus spectators.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'dist');
const PORT = +process.env.PORT || 8787;
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/') p = '/index.html';
  const file = path.join(root, path.normalize(p).replace(/^(\.\.[/\\])+/, ''));
  if (!file.startsWith(root) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('Not found'); return; }
  res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
  fs.createReadStream(file).pipe(res);
});

const wss = new WebSocketServer({ server });
const rooms = new Map(); // name -> Set<ws>
let nextId = 1;

wss.on('connection', (ws) => {
  ws.id = 'c' + (nextId++).toString(36);
  ws.room = null;
  ws.on('message', (raw) => {
    if (raw.length > 8192) return;
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.t === 'join' && typeof m.room === 'string' && /^[a-z0-9][a-z0-9_.-]{0,47}$/.test(m.room)) {
      leave(ws);
      const set = rooms.get(m.room) || new Set();
      rooms.set(m.room, set);
      set.add(ws); ws.room = m.room;
      ws.send(JSON.stringify({ t: 'joined', id: ws.id, n: set.size }));
      // replay everyone's latest state to the newcomer
      for (const o of set) if (o !== ws && o.last) ws.send(JSON.stringify({ t: 'p', id: o.id, s: o.last }));
    } else if (m.t === 'p' && ws.room) {
      ws.last = m.s;
      const msg = JSON.stringify({ t: 'p', id: ws.id, s: m.s });
      for (const o of rooms.get(ws.room) || []) if (o !== ws && o.readyState === 1) o.send(msg);
    }
  });
  ws.on('close', () => leave(ws));
});

function leave(ws) {
  if (!ws.room) return;
  const set = rooms.get(ws.room);
  if (set) {
    set.delete(ws);
    for (const o of set) if (o.readyState === 1) o.send(JSON.stringify({ t: 'left', id: ws.id }));
    if (!set.size) rooms.delete(ws.room);
  }
  ws.room = null;
}

server.listen(PORT, () => console.log(`Bikes & Blades relay on http://localhost:${PORT}  (rooms over ws://localhost:${PORT})`));
