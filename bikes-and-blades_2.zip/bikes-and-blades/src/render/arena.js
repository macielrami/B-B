// The Ashen Causeway — a jousting bridge over an abyss, before a kneeling colossus.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { envMaterials, getMaps, addOutlines, mergeStatic } from './materials.js';
import { ARENA } from '../core/data.js';
import { LOOK } from './look.js';
import { dressReliquary, updateReliquary } from './reliquary.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
function rng(seed) { let a = seed; return () => { a = (a * 1664525 + 1013904223) | 0; return ((a >>> 0) / 4294967296); }; }

function m(geo, mat, parent, p, r, s) {
  const o = new THREE.Mesh(geo, mat);
  if (p) o.position.set(...p);
  if (r) o.rotation.set(...r);
  if (s) (typeof s === 'number') ? o.scale.setScalar(s) : o.scale.set(...s);
  parent.add(o); return o;
}
// Box with UVs scaled to world size so textures keep a constant density.
function worldBox(w, h, d, texel = 2.2, r = 0.04) {
  const g = r > 0 ? new RoundedBoxGeometry(w, h, d, 2, Math.min(r, w / 2 - 0.01, h / 2 - 0.01, d / 2 - 0.01)) : new THREE.BoxGeometry(w, h, d);
  const pos = g.attributes.position, nor = g.attributes.normal, uv = g.attributes.uv;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const nx = Math.abs(nor.getX(i)), ny = Math.abs(nor.getY(i));
    if (ny > 0.7) uv.setXY(i, x / texel, z / texel);
    else if (nx > 0.7) uv.setXY(i, z / texel, y / texel);
    else uv.setXY(i, x / texel, y / texel);
  }
  return g;
}

const FLAME_VS = `
attribute float aSeed;
uniform float uTime;
varying vec2 vUv; varying float vSeed;
void main(){
  vUv = uv; vSeed = aSeed;
  vec4 mv = modelViewMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
  float sx = length(instanceMatrix[0].xyz), sy = length(instanceMatrix[1].xyz);
  mv.xy += vec2(position.x * sx, position.y * sy);
  gl_Position = projectionMatrix * mv;
}`;
const FLAME_FS = `
uniform float uTime; uniform sampler2D uNoise; uniform float uBoost;
varying vec2 vUv; varying float vSeed;
void main(){
  vec2 uv = vUv;
  float t = uTime * (1.6 + vSeed * 0.4) + vSeed * 13.0;
  float n1 = texture2D(uNoise, vec2(uv.x * 0.8 + vSeed, uv.y * 0.9 - t * 0.55)).r;
  float n2 = texture2D(uNoise, vec2(uv.x * 1.7 - vSeed, uv.y * 1.6 - t * 0.9)).g;
  float n = n1 * 0.6 + n2 * 0.4;
  float x = (uv.x - 0.5) * 2.0;
  float shape = 1.0 - smoothstep(0.0, 1.0, abs(x) / max(0.05, (1.0 - uv.y) * 0.95));
  float body = shape * smoothstep(0.0, 0.18, uv.y) * (1.0 - smoothstep(0.35, 1.0, uv.y + (n - 0.5) * 0.9));
  float a = clamp(body * (0.6 + n * 1.2), 0.0, 1.0);
  vec3 hot = vec3(1.0, 0.86, 0.68), mid = vec3(0.9, 0.2, 0.1), cool = vec3(0.32, 0.03, 0.05);
  vec3 c = mix(cool, mid, smoothstep(0.1, 0.5, a));
  c = mix(c, hot, smoothstep(0.6, 0.95, a));
  gl_FragColor = vec4(c * (2.2 + uBoost), a);
  if (a < 0.01) discard;
}`;

const SKY_VS = `varying vec3 vDir; void main(){ vDir = normalize(position); vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }`;
const SKY_FS = `
uniform float uTime; uniform sampler2D uNoise; uniform vec3 uSunDir; uniform float uFlash;
varying vec3 vDir;
float fbm(vec2 p){ float s=0.0, a=0.5; for(int i=0;i<4;i++){ s+=a*texture2D(uNoise,p).r; p*=2.03; a*=0.5;} return s; }
void main(){
  vec3 d = normalize(vDir);
  float h = d.y;
  // overcast ash vault, burgundy at the horizon
  vec3 top = vec3(0.012, 0.011, 0.016), hor = vec3(0.07, 0.022, 0.03), low = vec3(0.02, 0.012, 0.016);
  vec3 col = mix(hor, top, smoothstep(-0.02, 0.5, h));
  col = mix(col, low, smoothstep(0.0, -0.25, h));
  float glow = exp(-abs(h - 0.02) * 8.0);
  col += vec3(0.22, 0.03, 0.04) * glow * 0.35;
  // heavy, slow clouds
  vec2 cp = d.xz / max(0.12, d.y + 0.25) * 0.16 + vec2(uTime * 0.003, uTime * 0.0015);
  float c = fbm(cp);
  float cl = smoothstep(0.36, 0.72, c) * smoothstep(-0.05, 0.2, h);
  // a pale veiled moon with a crimson halo — the Wheel's eye
  float sd = acos(clamp(dot(d, uSunDir), -1.0, 1.0));
  float disc = 1.0 - smoothstep(0.085, 0.09, sd);
  float halo = exp(-pow((sd - 0.17) * 26.0, 2.0)) * 0.9 + exp(-pow((sd - 0.26) * 40.0, 2.0)) * 0.35;
  float bloomz = exp(-sd * 7.0) * 0.4;
  vec3 moon = vec3(0.9, 0.84, 0.74) * disc * (0.7 + 0.3 * fbm(d.xy * 6.0));
  vec3 ring = vec3(0.75, 0.08, 0.06) * halo + vec3(0.6, 0.2, 0.14) * bloomz;
  col += (moon * 1.4 + ring) * (1.0 - cl * 0.75);
  col = mix(col, vec3(0.035, 0.03, 0.04) + vec3(0.16, 0.02, 0.03) * glow + vec3(0.25, 0.05, 0.04) * bloomz, cl * 0.8);
  col += vec3(0.55, 0.5, 0.55) * uFlash * (0.4 + cl);
  gl_FragColor = vec4(col, 1.0);
}`;

const FOG_VS = `varying vec2 vUv; varying vec3 vW; void main(){ vUv = uv; vec4 w = modelMatrix * vec4(position,1.0); vW = w.xyz; gl_Position = projectionMatrix * viewMatrix * w; }`;
const FOG_FS = `
uniform float uTime; uniform sampler2D uNoise; uniform vec3 uColor; uniform float uAlpha; uniform float uScale; uniform float uSpeed;
varying vec2 vUv; varying vec3 vW;
void main(){
  vec2 p = vW.xz * 0.0 + vec2(vW.x, vW.y + vW.z) * uScale;
  float n = texture2D(uNoise, p * 0.5 + vec2(uTime * uSpeed, 0.0)).r * 0.6 + texture2D(uNoise, p * 1.3 - vec2(uTime * uSpeed * 1.7, uTime * 0.01)).g * 0.4;
  float edge = smoothstep(0.0, 0.25, vUv.y) * smoothstep(1.0, 0.55, vUv.y) * smoothstep(0.0, 0.1, vUv.x) * smoothstep(1.0, 0.9, vUv.x);
  float a = smoothstep(0.3, 0.85, n) * edge * uAlpha;
  gl_FragColor = vec4(uColor, a);
}`;

export class Arena {
  constructor(scene, quality = 'high') {
    this.scene = scene;
    this.quality = quality;
    this.group = new THREE.Group(); scene.add(this.group);
    this.mats = envMaterials();
    this.maps = getMaps();
    this.time = 0;
    this.flashT = 0; this.nextLightning = 6 + Math.random() * 8;
    this.excite = 0;
    this.buildLights();
    this.buildSky();
    this.buildBridge();
    this.buildBarrier();
    this.buildBraziers();
    this.buildGallery();
    dressReliquary(this);
    this.buildCathedral();
    this.buildForeground();
    this.buildFog();
    this.buildAmbient();
    this.mergeStats = mergeStatic(this.group);
  }

  // ------------------------------------------------------------ lighting
  buildLights() {
    const s = this.scene;
    s.background = new THREE.Color(0x0b0c0f);
    s.fog = new THREE.FogExp2(LOOK.fog.color, LOOK.fog.density);
    this.hemi = new THREE.HemisphereLight(LOOK.hemi.sky, LOOK.hemi.ground, LOOK.hemi.intensity);
    s.add(this.hemi);
    // cold moon / black-sun rim light from behind, casting shadows toward the camera
    this.moon = new THREE.DirectionalLight(LOOK.moon.color, LOOK.moon.intensity);
    this.moon.position.set(-14, 22, -18);
    this.moon.castShadow = true;
    const sz = this.quality === 'low' ? 1024 : 2048;
    this.moon.shadow.mapSize.set(sz, sz);
    const c = this.moon.shadow.camera;
    c.left = -22; c.right = 22; c.top = 14; c.bottom = -14; c.near = 1; c.far = 70;
    this.moon.shadow.bias = -0.0004; this.moon.shadow.normalBias = 0.03;
    s.add(this.moon); s.add(this.moon.target);
    // warm low key from the camera side (torchlight off-screen)
    this.key = new THREE.DirectionalLight(LOOK.key.color, LOOK.key.intensity);
    this.key.position.set(6, 7, 14);
    s.add(this.key);
    this.baseMoon = LOOK.moon.intensity;
  }

  // Image-based lighting: a tiny hand-built environment (cold sky, ember horizon,
  // brazier panels) prefiltered with PMREM so metal armour has something to reflect.
  buildEnvironment(renderer) {
    const env = new THREE.Scene();
    const sky = new THREE.Mesh(new THREE.SphereGeometry(50, 32, 16), new THREE.ShaderMaterial({
      side: THREE.BackSide,
      vertexShader: 'varying vec3 vD; void main(){ vD = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
      fragmentShader: `varying vec3 vD; void main(){ float h = vD.y;
        vec3 c = mix(vec3(0.16,0.10,0.07), vec3(0.10,0.13,0.19), smoothstep(-0.05, 0.6, h));
        c = mix(c, vec3(0.03,0.028,0.026), smoothstep(0.0, -0.4, h));
        c += vec3(0.5,0.22,0.08) * exp(-abs(h) * 10.0) * 0.6;
        gl_FragColor = vec4(c, 1.0); }`,
    }));
    env.add(sky);
    const panel = (w, h, pos, color, k) => {
      const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: new THREE.Color(color).multiplyScalar(k), side: THREE.DoubleSide }));
      p.position.set(...pos); p.lookAt(0, 0, 0); env.add(p);
    };
    panel(30, 14, [-20, 30, -25], 0xc9c0c4, 2.0);   // pale moon from behind
    for (let i = -2; i <= 2; i++) panel(4, 3, [i * 9, 2, -20], 0xe0482c, 3.5); // braziers
    panel(12, 12, [-9, 14, -30], 0xc42a2c, 2.5); // the wheel window
    panel(26, 8, [10, 10, 30], 0xd8573c, 1.2);       // candle side
    const pmrem = new THREE.PMREMGenerator(renderer);
    const rt = pmrem.fromScene(env, 0.035);
    this.scene.environment = rt.texture;
    this.scene.environmentIntensity = 0.85;
    pmrem.dispose();
  }

  buildSky() {
    const geo = new THREE.SphereGeometry(400, 48, 24);
    this.skyMat = new THREE.ShaderMaterial({
      vertexShader: SKY_VS, fragmentShader: SKY_FS, side: THREE.BackSide, depthWrite: false,
      uniforms: { uTime: { value: 0 }, uNoise: { value: this.maps.noise }, uSunDir: { value: V(0.32, 0.4, -0.86).normalize() }, uFlash: { value: 0 } },
    });
    const sky = new THREE.Mesh(geo, this.skyMat);
    sky.renderOrder = -10; sky.frustumCulled = false;
    this.scene.add(sky);
    this.sky = sky;
  }

  // ------------------------------------------------------------ the causeway
  buildBridge() {
    const g = this.group, M = this.mats, R = rng(7);
    const L = 110, W = 8.8;
    // deck
    const deckGeo = new THREE.PlaneGeometry(L, W, 220, 18);
    deckGeo.rotateX(-Math.PI / 2);
    const pos = deckGeo.attributes.position, uv = deckGeo.attributes.uv;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      uv.setXY(i, x / 3.2, z / 3.2);
      // worn ruts along both lanes
      const rut = Math.exp(-Math.pow((Math.abs(z) - 1.55) / 0.35, 2)) * -0.04;
      pos.setY(i, rut + (Math.sin(x * 1.7) * Math.cos(z * 2.3)) * 0.012);
    }
    deckGeo.computeVertexNormals();
    const deck = m(deckGeo, M.cobble, g);
    deck.receiveShadow = true;
    // deck slab and the near face of the bridge (seen from the camera)
    const slab = m(worldBox(L, 2.4, W + 0.6, 2.6, 0), M.stone, g, [0, -1.25, 0]);
    slab.receiveShadow = true;
    // under-arches on the near face, sinking into the abyss
    for (let x = -54; x <= 54; x += 13.5) {
      const pier = m(worldBox(3.2, 48, 6.5, 2.6, 0.1), M.stoneDark, g, [x, -26, 0]);
      const arch = new THREE.Mesh(new THREE.TorusGeometry(5.1, 0.9, 10, 32, Math.PI), M.stoneDark);
      arch.position.set(x + 6.75, -4.6, 3.2); arch.rotation.z = Math.PI; arch.scale.set(1, 0.85, 1);
      g.add(arch);
      const arch2 = arch.clone(); arch2.position.z = -3.2; g.add(arch2);
    }
    // cornice along the near edge
    m(worldBox(L, 0.3, 0.7, 2.2, 0.05), M.stone, g, [0, -0.05, W / 2 + 0.25]);
    // near parapet: low and broken, so it never hides the near rider
    for (let x = -52; x < 52; x += 2.6) {
      if (R() < 0.28) continue;
      const h = 0.22 + R() * 0.28;
      const b = m(worldBox(2.3 + R() * 0.2, h, 0.55, 2.2, 0.06), M.stone, g, [x + R() * 0.2, h / 2, W / 2 + 0.05]);
      b.rotation.y = (R() - 0.5) * 0.05; b.castShadow = true; b.receiveShadow = true;
    }
    // far parapet: taller, crenellated
    for (let x = -54; x < 54; x += 2.2) {
      const broken = R() < 0.12;
      const h = broken ? 0.5 + R() * 0.4 : 1.15;
      const b = m(worldBox(2.1, h, 0.6, 2.2, 0.05), M.stone, g, [x, h / 2, -W / 2 - 0.1]);
      b.castShadow = true; b.receiveShadow = true;
      if (!broken && Math.round(x / 2.2) % 2 === 0) m(worldBox(1.0, 0.45, 0.62, 2.2, 0.05), M.stone, g, [x, h + 0.22, -W / 2 - 0.1]).castShadow = true;
    }
    // rubble scattered at the base of the walls
    const rubGeo = new THREE.DodecahedronGeometry(0.18, 0);
    const rub = new THREE.InstancedMesh(rubGeo, M.stoneDark, 160);
    const mt = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
    for (let i = 0; i < 160; i++) {
      const side = R() < 0.5 ? -1 : 1;
      const sc = 0.4 + R() * 1.4;
      e.set(R() * 6, R() * 6, R() * 6); q.setFromEuler(e);
      mt.compose(V((R() - 0.5) * 104, 0.05 * sc, side * (W / 2 - 0.3 - R() * 0.6)), q, V(sc, sc * 0.7, sc));
      rub.setMatrixAt(i, mt);
    }
    rub.castShadow = true; rub.receiveShadow = true;
    g.add(rub);
    // arena end gates: portcullis arches at both ends
    for (const sx of [-1, 1]) {
      const gx = sx * (ARENA.half + ARENA.runoff + 3.2);
      const gate = new THREE.Group(); gate.position.set(gx, 0, 0); g.add(gate);
      m(worldBox(1.4, 7, 1.4, 2.2), M.stone, gate, [0, 3.5, 4.7]).castShadow = true;
      m(worldBox(1.4, 7, 1.4, 2.2), M.stone, gate, [0, 3.5, -4.7]).castShadow = true;
      const arch = m(new THREE.TorusGeometry(4.7, 0.6, 10, 30, Math.PI), M.stone, gate, [0, 6.6, 0], [0, Math.PI / 2, 0]);
      arch.castShadow = true;
      // portcullis bars
      for (let z = -3.9; z <= 3.9; z += 0.65) m(new THREE.BoxGeometry(0.1, 5.6, 0.1), M.iron, gate, [0, 6.2, z]);
      for (let y = 4.2; y < 9; y += 0.9) m(new THREE.BoxGeometry(0.1, 0.1, 8), M.iron, gate, [0, y, 0]);
      // banners hanging from the arch
      const ban = m(new THREE.PlaneGeometry(1.4, 3.6, 4, 10), M.cloth, gate, [sx * -0.3, 7.2, 2.6], [0, Math.PI / 2, 0]);
      const ban2 = m(new THREE.PlaneGeometry(1.4, 3.6, 4, 10), M.cloth, gate, [sx * -0.3, 7.2, -2.6], [0, Math.PI / 2, 0]);
      ban.castShadow = ban2.castShadow = true;
    }
  }

  buildBarrier() {
    const g = this.group, M = this.mats, R = rng(21);
    const L = (ARENA.endZone + 1) * 2; // the tilt runs the lists; the turning ends are open ground
    // low wooden rail on iron posts with sagging chains: the tilt
    const rail = m(worldBox(L, 0.12, 0.16, 2.5, 0.03), M.wood, g, [0, 0.52, 0]);
    rail.castShadow = true; rail.receiveShadow = true;
    m(worldBox(L, 0.08, 0.1, 2.5, 0.02), M.wood, g, [0, 0.22, 0]).castShadow = true;
    const postGeo = new THREE.CylinderGeometry(0.07, 0.09, 0.7, 8);
    const capGeo = new THREE.ConeGeometry(0.1, 0.22, 6);
    this.chainLinks = [];
    const linkGeo = new THREE.TorusGeometry(0.04, 0.012, 5, 10);
    const linkCount = Math.floor(L / 2.5) * 12;
    const links = new THREE.InstancedMesh(linkGeo, M.iron, linkCount);
    let li = 0;
    const mt = new THREE.Matrix4(), q = new THREE.Quaternion();
    for (let x = -L / 2; x <= L / 2 + 0.01; x += 2.5) {
      const p = m(postGeo, M.iron, g, [x, 0.35, 0]); p.castShadow = true;
      m(capGeo, M.iron, g, [x, 0.8, 0]);
      if (R() < 0.18) {
        const sk = m(new THREE.SphereGeometry(0.11, 10, 8), M.bone, g, [x, 0.98, 0], null, [1, 0.9, 0.85]);
        sk.castShadow = true;
      }
      if (x + 2.5 <= L / 2 + 0.01) for (let i = 0; i < 12; i++) {
        const t = (i + 0.5) / 12;
        const sag = Math.sin(t * Math.PI) * 0.2;
        q.setFromEuler(new THREE.Euler(i % 2 ? Math.PI / 2 : 0, 0, 0));
        mt.compose(V(x + t * 2.5, 0.72 - sag, 0), q, V(1, 1, 1));
        if (li < linkCount) links.setMatrixAt(li++, mt);
      }
    }
    links.count = li;
    g.add(links);
    // torn cloth strips tied to the rail
    for (let i = 0; i < 14; i++) {
      const strip = m(new THREE.PlaneGeometry(0.22, 0.6, 1, 4), M.cloth, g, [(R() - 0.5) * L, 0.28, 0.09], [0, 0, (R() - 0.5) * 0.3]);
      strip.castShadow = true;
    }
  }

  buildBraziers() {
    const g = this.group, M = this.mats;
    this.flameMat = new THREE.ShaderMaterial({
      vertexShader: FLAME_VS, fragmentShader: FLAME_FS, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uNoise: { value: this.maps.noise }, uBoost: { value: 0 } },
    });
    const xs = [-30, -18, -6, 6, 18, 30];
    const flameCount = xs.length + 2;
    const fg = new THREE.PlaneGeometry(1, 1); fg.translate(0, 0.5, 0);
    const flames = new THREE.InstancedMesh(fg, this.flameMat, flameCount);
    const seeds = new Float32Array(flameCount);
    this.braziers = [];
    const mt = new THREE.Matrix4();
    const nLights = this.quality === 'low' ? 3 : 6;
    xs.forEach((x, i) => {
      const z = -4.7;
      const b = new THREE.Group(); b.position.set(x, 1.15, z); g.add(b);
      for (let k = 0; k < 3; k++) {
        const a = k / 3 * Math.PI * 2;
        const leg = m(new THREE.CylinderGeometry(0.035, 0.035, 1.1, 6), M.iron, b, [Math.cos(a) * 0.22, 0.45, Math.sin(a) * 0.22], [Math.sin(a) * 0.25, 0, -Math.cos(a) * 0.25]);
        leg.castShadow = true;
      }
      const bowl = m(new THREE.SphereGeometry(0.42, 18, 10, 0, Math.PI * 2, Math.PI * 0.5, Math.PI * 0.5), M.rust, b, [0, 1.05, 0], [Math.PI, 0, 0]);
      bowl.material = M.rust; bowl.castShadow = true;
      m(new THREE.TorusGeometry(0.42, 0.04, 6, 20), M.iron, b, [0, 1.05, 0], [Math.PI / 2, 0, 0]);
      // glowing coals
      m(new THREE.CircleGeometry(0.38, 16), new THREE.MeshBasicMaterial({ color: new THREE.Color(1.0, 0.35, 0.08).multiplyScalar(3) }), b, [0, 1.06, 0], [-Math.PI / 2, 0, 0]);
      mt.compose(V(x, 2.22, z), new THREE.Quaternion(), V(1.0, 1.7, 1));
      flames.setMatrixAt(i, mt); seeds[i] = Math.random();
      if (i < nLights || (nLights === 3 && i % 2 === 0)) {
        const l = new THREE.PointLight(LOOK.brazier.color, LOOK.brazier.intensity, 12, 1.8);
        l.position.set(x, 2.6, z + 0.4);
        g.add(l);
        this.braziers.push({ l, base: LOOK.brazier.intensity, seed: Math.random() * 10, pos: V(x, 2.4, z) });
      } else this.braziers.push({ l: null, pos: V(x, 2.4, z), seed: Math.random() * 10 });
    });
    // two great fires atop the end gates
    [-1, 1].forEach((sx, k) => {
      const x = sx * (ARENA.half + ARENA.runoff + 3.2);
      mt.compose(V(x, 11.2, 0), new THREE.Quaternion(), V(2.4, 4.2, 1));
      flames.setMatrixAt(xs.length + k, mt); seeds[xs.length + k] = Math.random();
      m(new THREE.CylinderGeometry(0.9, 0.6, 0.6, 10), M.rust, g, [x, 11.2, 0]);
    });
    flames.geometry.setAttribute('aSeed', new THREE.InstancedBufferAttribute(seeds, 1));
    flames.frustumCulled = false; flames.renderOrder = 22;
    g.add(flames);
    this.flames = flames;
  }

  buildGallery() {
    // A raised stone gallery behind the far wall where hooded hollows watch.
    const g = this.group, M = this.mats, R = rng(33);
    const L = 76;
    m(worldBox(L, 2.0, 3.2, 2.2, 0.05), M.stoneDark, g, [0, 1.0, -7.4]).receiveShadow = true;
    m(worldBox(L, 0.5, 3.6, 2.2, 0.05), M.stone, g, [0, 2.15, -7.4]).receiveShadow = true;
    // back wall with pointed arches
    m(worldBox(L, 7, 0.8, 2.2, 0.05), M.stoneDark, g, [0, 4.5, -9.3]);
    for (let x = -36; x <= 36; x += 4) {
      m(worldBox(0.7, 5.4, 0.9, 2.2, 0.05), M.stone, g, [x, 5.0, -8.8]).castShadow = true;
      const arch = m(new THREE.TorusGeometry(1.65, 0.22, 6, 16, Math.PI), M.stone, g, [x + 2, 6.1, -8.85]);
      m(new THREE.PlaneGeometry(3.0, 3.6), new THREE.MeshBasicMaterial({ color: 0x050505 }), g, [x + 2, 4.6, -8.88]);
    }
    m(worldBox(L, 0.6, 1.2, 2.2, 0.05), M.stone, g, [0, 8.3, -8.9]);
    // the hollow crowd
    const n = this.quality === 'low' ? 40 : 70;
    const body = new THREE.CylinderGeometry(0.2, 0.34, 0.95, 9); body.translate(0, 0.48, 0);
    const shoulders = new THREE.SphereGeometry(0.26, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.5); shoulders.scale(1.15, 0.55, 0.9); shoulders.translate(0, 0.92, 0);
    const head = new THREE.SphereGeometry(0.17, 10, 8); head.translate(0.03, 1.12, 0);
    const hood = new THREE.SphereGeometry(0.21, 10, 8, 0, Math.PI * 2, 0, Math.PI * 0.62); hood.scale(1, 1.25, 1); hood.translate(-0.02, 1.13, 0);
    const tip = new THREE.ConeGeometry(0.1, 0.22, 6); tip.rotateZ(0.6); tip.translate(-0.12, 1.4, 0);
    const merged = mergeGeos([body, shoulders, head, hood, tip]);
    const crowdMat = new THREE.MeshStandardMaterial({ color: 0x2a2520, roughness: 1, map: this.maps.cloth.map });
    this.crowd = new THREE.InstancedMesh(merged, crowdMat, n);
    this.crowdData = [];
    const mt = new THREE.Matrix4();
    const torchPos = new Float32Array(n * 3), torchSeed = new Float32Array(n);
    let t = 0;
    for (let i = 0; i < n; i++) {
      const x = -36 + (i + R() * 0.6) / n * 72;
      const z = -6.6 - R() * 2.2;
      const s = 0.85 + R() * 0.35;
      const d = { x, z, s, phase: R() * 6.28, lean: (R() - 0.5) * 0.25 };
      this.crowdData.push(d);
      mt.compose(V(x, 2.4, z), new THREE.Quaternion(), V(s, s, s));
      this.crowd.setMatrixAt(i, mt);
      if (R() < 0.45) { torchPos.set([x + 0.25 * s, 2.4 + 1.35 * s, z + 0.15], t * 3); torchSeed[t] = R(); t++; }
    }
    this.crowd.castShadow = true;
    g.add(this.crowd);
    // torches as flickering sprites
    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.BufferAttribute(torchPos.slice(0, t * 3), 3));
    tg.setAttribute('aSeed', new THREE.BufferAttribute(torchSeed.slice(0, t), 1));
    this.torchMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uMap: { value: this.maps.soft }, uExcite: { value: 0 }, uScale: { value: 300 } },
      vertexShader: `attribute float aSeed; uniform float uTime; uniform float uExcite; uniform float uScale; varying float vF;
        void main(){ vec3 p = position; p.y += uExcite * (0.35 + 0.2*sin(uTime*9.0 + aSeed*20.0));
          vec4 mv = modelViewMatrix * vec4(p,1.0); vF = 0.7 + 0.3*sin(uTime*(11.0+aSeed*7.0) + aSeed*40.0);
          gl_PointSize = uScale * (0.35 + 0.1*vF) / -mv.z; gl_Position = projectionMatrix * mv; }`,
      fragmentShader: `uniform sampler2D uMap; varying float vF; void main(){ float a = texture2D(uMap, gl_PointCoord).a; gl_FragColor = vec4(vec3(1.0,0.5,0.15)*3.0*vF, a); }`,
    });
    const torches = new THREE.Points(tg, this.torchMat);
    torches.frustumCulled = false; torches.renderOrder = 21;
    g.add(torches);
    this.torches = torches;
  }

  buildColossus() {
    // A kneeling knight carved from the cliff, hands on a planted greatsword.
    const g = new THREE.Group(); g.position.set(14, -4, -40); g.rotation.y = -0.35; g.scale.setScalar(1.15);
    this.group.add(g);
    const S = this.mats.stone, D = this.mats.stoneDark;
    const box = (w, h, d, p, r, mat = S) => { const o = m(worldBox(w, h, d, 3.5, 0.4), mat, g, p, r); o.castShadow = true; return o; };
    box(16, 4, 12, [0, 2, 0], null, D);                 // plinth
    box(3.2, 6.5, 3.4, [-2.6, 7, 2.2], [0.25, 0, 0]);   // shin (kneeling leg)
    box(3.4, 3.2, 6.8, [-2.6, 9.6, -0.4], [0.1, 0, 0]); // thigh
    box(3.0, 7.0, 3.2, [2.6, 7.5, -2.2], [-0.15, 0, 0]);// other leg (knee up)
    box(3.4, 3.0, 5, [2.6, 11.2, 0.6], [-0.5, 0, 0]);
    box(7.6, 4.2, 5.0, [0, 12.6, -0.6]);                // hips
    box(9.2, 8.5, 5.8, [0, 18.4, -0.2], [0.08, 0, 0]);  // chest
    for (const s of [1, -1]) {
      const p = m(new THREE.SphereGeometry(3.0, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.6), S, g, [s * 5.4, 22.2, -0.2], [0, 0, s * -0.3], [1.1, 0.9, 1.1]); p.castShadow = true;
      box(2.4, 7.0, 2.6, [s * 5.0, 17.5, 2.4], [-0.9, 0, s * 0.15]);
      box(2.6, 2.6, 2.6, [s * 1.6, 15.6, 5.4]);          // fists on the pommel
    }
    // great helm head, bowed
    const helm = m(new THREE.LatheGeometry([[0, 0], [2.4, 0], [2.6, 0.5], [2.65, 2.6], [2.5, 3.8], [1.9, 4.4], [0, 4.6]].map(p => new THREE.Vector2(p[0], p[1])), 20), S, g, [0, 22.6, 0.6], [0.35, 0, 0]);
    helm.castShadow = true;
    m(new THREE.BoxGeometry(0.4, 0.4, 3.6), this.mats.silhouette, helm, [2.5, 2.8, 0], [0, Math.PI / 2, 0]).scale.set(1, 1, 1);
    // the greatsword
    box(1.0, 3.8, 1.0, [0, 16.4, 5.6]);                 // grip
    box(6.4, 0.9, 1.2, [0, 14.2, 5.6]);                 // crossguard
    const blade = m(worldBox(1.8, 14, 0.5, 3.5, 0.1), S, g, [0, 6.6, 5.7], [0.04, 0, 0]); blade.castShadow = true;
    // ember glowing in the helm's slit
    const glow = new THREE.PointLight(0xff6a20, 30, 18, 2);
    glow.position.set(0, 25.5, 4.2); g.add(glow);
    this.colossusGlow = glow;
    // chains binding the colossus
    const chainMat = this.mats.iron;
    for (const s of [1, -1]) {
      const pts = [];
      for (let i = 0; i <= 12; i++) { const t = i / 12; pts.push(V(s * (5 + t * 14), 20 - t * 18 + Math.sin(t * Math.PI) * -3, -1 - t * 6)); }
      m(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 40, 0.25, 6), chainMat, g);
    }
  }

  buildCathedral() {
    // Far silhouette layers. Fog turns them into atmosphere.
    const g = new THREE.Group(); g.position.set(-42, -6, -105); this.group.add(g);
    const S = this.mats.stoneDark;
    const R = rng(55);
    const box = (w, h, d, x, y, z) => m(worldBox(w, h, d, 6, 0), S, g, [x, y + h / 2, z]);
    box(26, 30, 60, 0, 0, 0);
    for (const sx of [-1, 1]) {
      box(9, 58, 9, sx * 13, 0, 28);
      m(new THREE.ConeGeometry(6.4, 28, 8), S, g, [sx * 13, 58 + 14, 28]);
      for (let k = 0; k < 4; k++) m(new THREE.ConeGeometry(1.2, 9, 6), S, g, [sx * 13 + (k % 2 ? 4 : -4), 62, 28 + (k < 2 ? 4 : -4)]);
    }
    m(new THREE.ConeGeometry(5, 36, 8), S, g, [0, 30 + 18, -10]);
    // buttresses
    for (let z = -25; z <= 20; z += 9) for (const sx of [-1, 1]) {
      const b = m(new THREE.BoxGeometry(1.6, 26, 2), S, g, [sx * 18, 13, z], [0, 0, sx * 0.35]);
      m(new THREE.ConeGeometry(0.9, 6, 5), S, g, [sx * 22.5, 27, z]);
    }
    // glowing lancet windows
    const winMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(1.0, 0.45, 0.15).multiplyScalar(0.12), fog: true });
    for (let z = -24; z <= 24; z += 8) {
      if (R() < 0.3) continue;
      const w = m(new THREE.PlaneGeometry(2.4, 9), winMat, g, [13.1, 14, z], [0, Math.PI / 2, 0]);
    }
    m(new THREE.CircleGeometry(3.5, 24), winMat, g, [0, 22, 30.1]);
    // ruined towers on the horizon
    const far = new THREE.Group(); far.position.set(0, -10, -190); this.group.add(far);
    for (let i = 0; i < 26; i++) {
      const x = (i - 13) * 22 + (R() - 0.5) * 12;
      const h = 30 + R() * 70;
      m(new THREE.BoxGeometry(6 + R() * 8, h, 8), this.mats.silhouette, far, [x, h / 2, (R() - 0.5) * 40]);
      if (R() < 0.6) m(new THREE.ConeGeometry(4 + R() * 3, 14 + R() * 20, 6), this.mats.silhouette, far, [x, h + 8, 0]);
    }
  }

  buildForeground() {
    // Broken columns rising out of the abyss between the camera and the bridge,
    // and hanging cages. They slide past the lens and sell the depth.
    const g = this.group;
    // foreground reads as dark framing silhouettes, with a faint ember rim
    const dark = new THREE.MeshStandardMaterial({ color: 0x0d0c0c, roughness: 0.95, metalness: 0.2, normalMap: this.maps.ashlar.normalMap });
    const M = { stone: dark, stoneDark: dark, iron: dark, bone: dark, silhouette: dark };
    this.fgChains = [];
    const colGeo = new THREE.CylinderGeometry(1.0, 1.15, 30, 14);
    for (const [x, top] of [[-27, 3.2], [24, 1.6], [-60, 4], [52, 2.4]]) {
      const c = m(colGeo, M.stoneDark, g, [x, top - 15, 9.5]);
      c.material = M.stone;
      // jagged broken top
      for (let i = 0; i < 5; i++) m(new THREE.ConeGeometry(0.4, 0.8 + Math.random() * 0.8, 5), M.stone, g, [x + Math.cos(i) * 0.6, top + 0.2, 9.5 + Math.sin(i) * 0.6], [Math.random() * 0.4, 0, Math.random() * 0.4]);
      c.castShadow = false;
    }
    // hanging cages on long chains (in front of the action, high in frame)
    for (const [x, z, len] of [[-14, 7, 6], [9, 6.2, 5], [33, 7.5, 7], [-38, 6.5, 5]]) {
      const pivot = new THREE.Group(); pivot.position.set(x, 13, z); g.add(pivot);
      pivot.userData.dynamic = true;
      m(new THREE.CylinderGeometry(0.04, 0.04, len, 5), M.iron, pivot, [0, -len / 2, 0]);
      const cage = new THREE.Group(); cage.position.set(0, -len - 0.8, 0); pivot.add(cage);
      for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; m(new THREE.CylinderGeometry(0.035, 0.035, 1.6, 4), M.iron, cage, [Math.cos(a) * 0.45, 0, Math.sin(a) * 0.45]); }
      m(new THREE.TorusGeometry(0.45, 0.05, 4, 12), M.iron, cage, [0, 0.8, 0], [Math.PI / 2, 0, 0]);
      m(new THREE.TorusGeometry(0.45, 0.05, 4, 12), M.iron, cage, [0, -0.8, 0], [Math.PI / 2, 0, 0]);
      m(new THREE.ConeGeometry(0.5, 0.5, 8), M.iron, cage, [0, 1.05, 0]);
      // a slumped hollow inside
      m(new THREE.SphereGeometry(0.16, 8, 6), M.bone, cage, [0.1, 0.0, 0]);
      m(new THREE.CylinderGeometry(0.12, 0.2, 0.6, 6), M.silhouette, cage, [0.05, -0.45, 0]);
      this.fgChains.push({ pivot, phase: Math.random() * 6, amp: 0.05 + Math.random() * 0.05 });
    }
  }

  buildFog() {
    this.fogMats = [];
    const mk = (w, h, pos, rotX, color, alpha, scale, speed) => {
      const mat = new THREE.ShaderMaterial({
        vertexShader: FOG_VS, fragmentShader: FOG_FS, transparent: true, depthWrite: false, side: THREE.DoubleSide,
        uniforms: { uTime: { value: 0 }, uNoise: { value: this.maps.noise }, uColor: { value: new THREE.Color(color) }, uAlpha: { value: alpha }, uScale: { value: scale }, uSpeed: { value: speed } },
      });
      const o = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat);
      o.position.set(...pos); o.rotation.x = rotX; o.renderOrder = 5;
      this.group.add(o); this.fogMats.push(mat);
      return o;
    };
    // abyss fog below the bridge
    mk(260, 60, [0, -7, 10], -Math.PI / 2, 0x3a3a40, 0.75, 0.018, 0.004);
    mk(260, 60, [0, -14, 0], -Math.PI / 2, 0x2a2a30, 0.9, 0.012, 0.003);
    // mid-distance curtains
    mk(220, 26, [0, 6, -26], 0, 0x2c2e34, 0.55, 0.02, 0.003);
    mk(300, 40, [0, 10, -60], 0, 0x262830, 0.6, 0.012, 0.002);
    // thin ground mist over the deck
    mk(110, 3, [0, 0.35, -2.5], 0, 0x50505a, 0.22, 0.06, 0.01);
  }

  buildAmbient() {
    // rising embers and drifting ash, as one points cloud each
    const mk = (n, area, color, size, seed, up = false) => {
      const R = rng(seed);
      const p = new Float32Array(n * 3), s = new Float32Array(n);
      for (let i = 0; i < n; i++) { p.set([(R() - 0.5) * area[0], R() * area[1] + area[3], (R() - 0.5) * area[2] + area[4]], i * 3); s[i] = R(); }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(p, 3));
      g.setAttribute('aSeed', new THREE.BufferAttribute(s, 1));
      const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        uniforms: { uTime: { value: 0 }, uMap: { value: this.maps.soft }, uColor: { value: new THREE.Color(color) }, uH: { value: area[1] }, uB: { value: area[3] }, uSize: { value: size }, uDir: { value: up ? 1 : -1 } },
        vertexShader: `attribute float aSeed; uniform float uTime, uH, uB, uSize, uDir; varying float vA;
          void main(){ vec3 p = position; float t = uTime * (0.3 + aSeed * 0.5);
            p.y = uB + mod(p.y - uB + uDir * t * (uDir > 0.0 ? 1.4 : 0.5), uH);
            p.x += sin(t * 1.3 + aSeed * 30.0) * 0.6 + uTime * 0.25 * -uDir; p.z += cos(t + aSeed * 17.0) * 0.4;
            p.x = mod(p.x + 60.0, 120.0) - 60.0;
            vec4 mv = modelViewMatrix * vec4(p, 1.0);
            vA = (0.5 + 0.5 * sin(uTime * 3.0 + aSeed * 50.0)) * smoothstep(0.0, 0.15, (p.y - uB) / uH) * (1.0 - smoothstep(0.7, 1.0, (p.y - uB) / uH));
            gl_PointSize = min(uSize * (0.5 + aSeed) / -mv.z, 14.0); vA *= smoothstep(1.5, 4.0, -mv.z); gl_Position = projectionMatrix * mv; }`,
        fragmentShader: `uniform sampler2D uMap; uniform vec3 uColor; varying float vA; void main(){ float a = texture2D(uMap, gl_PointCoord).a; gl_FragColor = vec4(uColor * 2.5, a * vA); }`,
      });
      const pts = new THREE.Points(g, mat); pts.frustumCulled = false; pts.renderOrder = 23;
      this.group.add(pts);
      return mat;
    };
    const q = this.quality === 'low' ? 0.5 : 1;
    this.emberMat = mk(Math.floor(600 * q), [120, 18, 30, -6, -2], 0xcc3a2e, 40, 3, true);
    this.ashMat = mk(Math.floor(600 * q), [120, 16, 24, -2, 2], 0x8f8682, 26, 9);
    this.petalMat = mk(Math.floor(260 * q), [80, 14, 16, 0, 1], 0x8a1f24, 34, 17);
  }

  // ------------------------------------------------------------ per frame
  update(dt, focusX, excite = 0) {
    this.time += dt;
    const t = this.time;
    this.skyMat.uniforms.uTime.value = t;
    this.flameMat.uniforms.uTime.value = t;
    this.torchMat.uniforms.uTime.value = t;
    this.excite += (excite - this.excite) * Math.min(1, dt * 3);
    this.torchMat.uniforms.uExcite.value = this.excite;
    this.emberMat.uniforms.uTime.value = t; this.ashMat.uniforms.uTime.value = t; this.petalMat.uniforms.uTime.value = t;
    updateReliquary(this, dt);
    for (const f of this.fogMats) f.uniforms.uTime.value = t;
    for (const b of this.braziers) if (b.l) b.l.intensity = b.base * (0.82 + 0.18 * Math.sin(t * 13 + b.seed) * Math.sin(t * 7.3 + b.seed * 2));
    for (const c of this.fgChains) { c.pivot.rotation.z = Math.sin(t * 0.7 + c.phase) * c.amp; c.pivot.rotation.x = Math.cos(t * 0.5 + c.phase) * c.amp * 0.5; }
    // crowd sway (and roar when excited)
    const mt = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler();
    this.crowdData.forEach((d, i) => {
      const bob = this.excite * Math.max(0, Math.sin(t * 8 + d.phase)) * 0.18;
      e.set(Math.sin(t * 0.8 + d.phase) * 0.04, 0, d.lean + Math.sin(t * 0.6 + d.phase) * 0.05);
      q.setFromEuler(e);
      mt.compose(V(d.x, 2.4 + bob, d.z), q, V(d.s, d.s, d.s));
      this.crowd.setMatrixAt(i, mt);
    });
    this.crowd.instanceMatrix.needsUpdate = true;
    // lightning
    this.nextLightning -= dt;
    if (this.nextLightning <= 0) { this.flashT = 1; this.nextLightning = 7 + Math.random() * 12; this.onLightning && this.onLightning(); }
    if (this.flashT > 0) this.flashT = Math.max(0, this.flashT - dt * 2.8);
    const fl = this.flashT > 0 ? this.flashT * (0.6 + 0.4 * Math.sin(this.flashT * 40)) : 0;
    this.skyMat.uniforms.uFlash.value = fl;
    this.moon.intensity = this.baseMoon + fl * 6;
    // keep the shadow frustum on the action
    this.moon.position.set(focusX - 14, 22, -18);
    this.moon.target.position.set(focusX, 0, 0);
    this.moon.target.updateMatrixWorld();
  }

  setFlameBoost(v) { this.flameMat.uniforms.uBoost.value = v; }
}

function mergeGeos(list) {
  // minimal merge for non-indexed + indexed simple geometries
  const parts = list.map(g => g.index ? g.toNonIndexed() : g);
  let count = 0; for (const g of parts) count += g.attributes.position.count;
  const pos = new Float32Array(count * 3), nor = new Float32Array(count * 3), uv = new Float32Array(count * 2);
  let o = 0;
  for (const g of parts) {
    pos.set(g.attributes.position.array, o * 3); nor.set(g.attributes.normal.array, o * 3); uv.set(g.attributes.uv.array, o * 2);
    o += g.attributes.position.count;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  return out;
}
