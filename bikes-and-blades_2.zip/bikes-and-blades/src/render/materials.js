// Shared material library + "inverted hull" ink outlines.
import * as THREE from 'three';
import * as T from './textures.js';

let maps = null;
export function initMaps() {
  if (maps) return maps;
  maps = {
    cobble: T.cobbleMaps(), ashlar: T.ashlarMaps(), iron: T.ironMaps(), paint: T.paintMaps(),
    leather: T.leatherMaps(), cloth: T.clothMaps(), tire: T.tireMaps(), wood: T.woodMaps(),
    soft: T.softSprite(), smoke: T.smokeSprite(), noise: T.noiseTexture(),
  };
  return maps;
}
export function getMaps() { return maps || initMaps(); }

function withRepeat(set, r) {
  const o = {};
  for (const k in set) { const t = set[k].clone(); t.repeat.set(r, r); t.needsUpdate = true; o[k] = t; }
  return o;
}

// A material kit for one rider+bike (cloned so each can flash independently).
export function riderKit(R, rim = { color: 0xeee4cf, strength: 1.2 }) {
  const m = getMaps();
  const kit = {
    metal: new THREE.MeshStandardMaterial({ color: new THREE.Color(R.metal).multiplyScalar(1.5), metalness: 0.62, roughness: 0.42, ...m.iron, normalScale: new THREE.Vector2(0.8, 0.8), envMapIntensity: 1.8 }),
    darkMetal: new THREE.MeshStandardMaterial({ color: 0x55555a, metalness: 0.6, roughness: 0.55, ...m.iron, envMapIntensity: 1.4 }),
    trim: new THREE.MeshStandardMaterial({ color: new THREE.Color(R.trim).multiplyScalar(1.3), metalness: 0.85, roughness: 0.32, ...m.iron, normalScale: new THREE.Vector2(0.4, 0.4), envMapIntensity: 2.0 }),
    paint: new THREE.MeshStandardMaterial({ color: new THREE.Color(R.paint).multiplyScalar(1.6), metalness: 0.3, roughness: 0.5, envMapIntensity: 1.3, map: m.paint.map, normalMap: m.paint.normalMap, roughnessMap: m.paint.roughnessMap }),
    leather: new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0, roughness: 0.75, ...m.leather }),
    cloth: new THREE.MeshStandardMaterial({ color: R.cloth, metalness: 0, roughness: 0.95, map: m.cloth.map, normalMap: m.cloth.normalMap }),
    cape: new THREE.MeshStandardMaterial({ color: R.cape, metalness: 0, roughness: 0.95, map: m.cloth.map, normalMap: m.cloth.normalMap, alphaTest: 0.5, side: THREE.DoubleSide }),
    tire: new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0, roughness: 0.9, ...withRepeat(m.tire, 1) }),
    bone: new THREE.MeshStandardMaterial({ color: 0xd8cdb4, metalness: 0, roughness: 0.7, normalMap: m.ashlar.normalMap }),
    eye: new THREE.MeshBasicMaterial({ color: new THREE.Color(R.eye).multiplyScalar(4) }),
    lamp: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xffd9a0).multiplyScalar(5) }),
    tail: new THREE.MeshBasicMaterial({ color: new THREE.Color(0xff2a10).multiplyScalar(4) }),
    void: new THREE.MeshBasicMaterial({ color: 0x050403 }),
  };
  kit.all = Object.values(kit).filter(x => x.isMeshStandardMaterial);
  // Silhouette rim: a view-angle (fresnel) glow in the side's colour, so the
  // riders always cut out of the dark crimson set. P1 bone, P2 ember.
  kit.rim = { color: { value: new THREE.Color(rim.color) }, strength: { value: rim.strength } };
  for (const mat of kit.all) {
    mat.emissive = new THREE.Color(0x000000);
    mat.fog = false; // riders stay crisp; the set recedes into the fog
    mat.onBeforeCompile = (sh) => {
      sh.uniforms.uRimColor = kit.rim.color; sh.uniforms.uRim = kit.rim.strength;
      sh.fragmentShader = sh.fragmentShader
        .replace('#include <common>', '#include <common>\nuniform vec3 uRimColor; uniform float uRim;')
        .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
          float rimF = 1.0 - clamp(dot(normalize(normal), normalize(vViewPosition)), 0.0, 1.0);
          totalEmissiveRadiance += uRimColor * (pow(rimF, 3.0) * uRim);`);
    };
    mat.customProgramCacheKey = () => 'rim';
  }
  return kit;
}

export function envMaterials() {
  const m = getMaps();
  return {
    cobble: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 1, metalness: 0, ...withRepeat(m.cobble, 1), normalScale: new THREE.Vector2(1.4, 1.4) }),
    stone: new THREE.MeshStandardMaterial({ color: 0xbab4aa, roughness: 1, metalness: 0, ...withRepeat(m.ashlar, 1) }),
    stoneDark: new THREE.MeshStandardMaterial({ color: 0x77736e, roughness: 1, metalness: 0, ...withRepeat(m.ashlar, 1) }),
    iron: new THREE.MeshStandardMaterial({ color: 0x5a5856, roughness: 0.7, metalness: 0.8, ...m.iron }),
    rust: new THREE.MeshStandardMaterial({ color: 0x7a4a30, roughness: 0.85, metalness: 0.5, ...m.iron }),
    wood: new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0, ...m.wood }),
    cloth: new THREE.MeshStandardMaterial({ color: 0x5a1612, roughness: 1, metalness: 0, map: m.cloth.map, normalMap: m.cloth.normalMap, alphaTest: 0.5, side: THREE.DoubleSide }),
    bone: new THREE.MeshStandardMaterial({ color: 0xc8bea6, roughness: 0.8 }),
    silhouette: new THREE.MeshBasicMaterial({ color: 0x0c0d10, fog: true }),
  };
}

// ---------------------------------------------------------------- outlines
const outlineMats = new Map();
export function outlineMaterial(width = 0.018, color = 0x07060a) {
  const key = width + ':' + color;
  if (outlineMats.has(key)) return outlineMats.get(key);
  const mat = new THREE.MeshBasicMaterial({ color, side: THREE.BackSide });
  mat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace('#include <begin_vertex>',
      `#include <begin_vertex>
       transformed += normalize(normal) * ${width.toFixed(4)};`);
  };
  mat.userData.outline = true;
  outlineMats.set(key, mat);
  return mat;
}

// Adds an outline shell to every mesh under root (skips flagged meshes).
export function addOutlines(root, width = 0.018) {
  const list = [];
  root.traverse(o => { if (o.isMesh && !o.userData.noOutline && !o.material.userData?.outline && !o.material.transparent && !o.material.isMeshBasicMaterial) list.push(o); });
  for (const o of list) {
    const shell = new THREE.Mesh(o.geometry, outlineMaterial(width));
    shell.userData.noOutline = true;
    shell.castShadow = false; shell.receiveShadow = false;
    shell.raycast = () => {};
    o.add(shell);
  }
}

export function shadowAll(root, cast = true, receive = true) {
  root.traverse(o => { if (o.isMesh && !o.userData.noOutline) { o.castShadow = cast; o.receiveShadow = receive; } });
}

// ---------------------------------------------------------------- draw-call reduction
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

function prepGeo(g, matrix) {
  let geo = g.index ? g.toNonIndexed() : g.clone();
  for (const k of Object.keys(geo.attributes)) if (!['position', 'normal', 'uv'].includes(k)) geo.deleteAttribute(k);
  if (!geo.attributes.uv) geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(geo.attributes.position.count * 2), 2));
  geo.clearGroups();
  if (matrix) geo.applyMatrix4(matrix);
  return geo;
}

// Merge the direct, childless, single-material mesh children of `parent` that
// share a material into one mesh each (transforms baked relative to parent).
export function mergeChildren(parent) {
  const buckets = new Map();
  for (const o of [...parent.children]) {
    if (!o.isMesh || o.isInstancedMesh || o.children.length || Array.isArray(o.material) || o.userData.keep || o.material.isShaderMaterial) continue;
    const key = o.material.uuid + (o.userData.noOutline ? ':n' : '') + (o.castShadow ? ':c' : '') + (o.receiveShadow ? ':r' : '');
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(o);
  }
  for (const list of buckets.values()) {
    if (list.length < 2) continue;
    const geos = list.map(o => { o.updateMatrix(); return prepGeo(o.geometry, o.matrix); });
    const merged = mergeGeometries(geos, false);
    if (!merged) continue;
    const m = new THREE.Mesh(merged, list[0].material);
    m.userData.noOutline = list[0].userData.noOutline;
    m.castShadow = list[0].castShadow; m.receiveShadow = list[0].receiveShadow;
    for (const o of list) { parent.remove(o); o.geometry.dispose(); }
    geos.forEach(g => g.dispose());
    parent.add(m);
  }
}
export function mergeTree(root) {
  const groups = [];
  root.traverse(o => { if (!o.isMesh) groups.push(o); });
  for (const g of groups) mergeChildren(g);
}

// Bake every static mesh under `root` into world-space meshes, one per material.
export function mergeStatic(root, scene) {
  root.updateMatrixWorld(true);
  const buckets = new Map(), victims = [];
  root.traverse(o => {
    if (!o.isMesh || o.isInstancedMesh || Array.isArray(o.material) || o.material.isShaderMaterial) return;
    for (let p = o; p; p = p.parent) if (p.userData.dynamic) return;
    const key = o.material.uuid + (o.castShadow ? ':c' : '') + (o.receiveShadow ? ':r' : '');
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(o);
  });
  let before = 0, after = 0;
  for (const list of buckets.values()) {
    before += list.length;
    if (list.length < 2) { after++; continue; }
    const geos = list.map(o => prepGeo(o.geometry, o.matrixWorld));
    const merged = mergeGeometries(geos, false);
    geos.forEach(g => g.dispose());
    if (!merged) { after += list.length; continue; }
    const m = new THREE.Mesh(merged, list[0].material);
    m.castShadow = list[0].castShadow; m.receiveShadow = list[0].receiveShadow;
    m.userData.merged = true;
    root.add(m); // root is assumed to sit at the world origin
    victims.push(...list);
    after++;
  }
  for (const o of victims) { o.parent && o.parent.remove(o); o.geometry.dispose(); }
  return { before, after };
}
