// Reliquary set dressing for the Ashen Causeway: the Wheel of the Martyr (a
// rose window shaped like a spoked wheel), the Mourning Saint, candles,
// censers, sigil banners and thorned wreaths. Original iconography built
// around the game's own motif: the wheel as relic, the rider as penitent.
import * as THREE from 'three';
import { LOOK } from './look.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
function m(geo, mat, parent, p, r, s) {
  const o = new THREE.Mesh(geo, mat);
  if (p) o.position.set(...p);
  if (r) o.rotation.set(...r);
  if (s) (typeof s === 'number') ? o.scale.setScalar(s) : o.scale.set(...s);
  parent.add(o); return o;
}
const lathe = (pts, seg = 24) => new THREE.LatheGeometry(pts.map(p => new THREE.Vector2(p[0], p[1])), seg);
function rng(seed) { let a = seed; return () => { a = (a * 1664525 + 1013904223) | 0; return ((a >>> 0) / 4294967296); }; }

// Stained glass for the wheel window: crimson and burgundy panes, bone tracery.
function wheelGlassTexture() {
  const S = 512, c = document.createElement('canvas'); c.width = c.height = S;
  const g = c.getContext('2d'); const R = rng(91);
  g.fillStyle = '#07060a'; g.fillRect(0, 0, S, S);
  g.translate(S / 2, S / 2);
  const panes = ['#ab2629', '#6e1d27', '#cc3a2e', '#3d1018', '#c2b7a2', '#8a1f24'];
  for (let ring = 0; ring < 4; ring++) {
    const r0 = 40 + ring * 52, r1 = r0 + 50, n = 12 * (ring + 1);
    for (let i = 0; i < n; i++) {
      const a0 = i / n * Math.PI * 2, a1 = (i + 1) / n * Math.PI * 2;
      g.beginPath(); g.arc(0, 0, r1, a0, a1); g.arc(0, 0, r0, a1, a0, true); g.closePath();
      g.fillStyle = panes[Math.floor(R() * panes.length)]; g.globalAlpha = 0.7 + R() * 0.3; g.fill();
    }
  }
  g.globalAlpha = 1;
  // the martyr's figure at the hub: a bone-white circle with a dark wound
  g.fillStyle = '#eee4cf'; g.beginPath(); g.arc(0, 0, 36, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#8a1f24'; g.beginPath(); g.arc(0, 0, 14, 0, Math.PI * 2); g.fill();
  // lead came
  g.strokeStyle = '#0e0c10'; g.lineWidth = 5;
  for (let r = 40; r <= 250; r += 52) { g.beginPath(); g.arc(0, 0, r, 0, Math.PI * 2); g.stroke(); }
  for (let i = 0; i < 48; i++) { const a = i / 48 * Math.PI * 2; g.beginPath(); g.moveTo(Math.cos(a) * 40, Math.sin(a) * 40); g.lineTo(Math.cos(a) * 250, Math.sin(a) * 250); g.lineWidth = i % 4 ? 2 : 5; g.stroke(); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

// Burgundy banner with a bone wheel-and-thorn sigil and a ragged hem.
function bannerTexture() {
  const W = 128, H = 384, c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'); const R = rng(7);
  g.fillStyle = '#3d1018'; g.fillRect(0, 0, W, H);
  for (let y = 0; y < H; y += 2) { g.fillStyle = `rgba(0,0,0,${0.08 + R() * 0.1})`; g.fillRect(0, y, W, 1); }
  g.strokeStyle = '#c2b7a2'; g.lineWidth = 5;
  g.strokeRect(10, 10, W - 20, H * 0.72);
  g.save(); g.translate(W / 2, H * 0.32);
  g.beginPath(); g.arc(0, 0, 34, 0, Math.PI * 2); g.stroke();
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; g.beginPath(); g.moveTo(Math.cos(a) * 8, Math.sin(a) * 8); g.lineTo(Math.cos(a) * 34, Math.sin(a) * 34); g.stroke(); }
  g.lineWidth = 3;
  for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2; g.beginPath(); g.moveTo(Math.cos(a) * 38, Math.sin(a) * 38); g.lineTo(Math.cos(a) * 48, Math.sin(a) * 48); g.stroke(); }
  g.restore();
  g.fillStyle = '#8a1f24'; g.fillRect(W / 2 - 3, H * 0.52, 6, H * 0.14);
  // ragged hem through alpha
  const id = g.getImageData(0, 0, W, H);
  for (let x = 0; x < W; x++) {
    const cut = H * (0.8 + 0.12 * Math.abs(Math.sin(x * 0.21)) + R() * 0.06);
    for (let y = Math.floor(cut); y < H; y++) id.data[(y * W + x) * 4 + 3] = 0;
  }
  g.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function dressReliquary(A) {
  const g = A.group, M = A.mats;
  const stone = M.stone, dark = M.stoneDark, iron = M.iron;
  const wax = new THREE.MeshStandardMaterial({ color: 0xd9cdb5, roughness: 0.6, metalness: 0, emissive: new THREE.Color(0x120606) });

  // ---------------------------------------------------------- Wheel of the Martyr
  const W = new THREE.Group(); W.position.set(-9, 17.5, -34); W.scale.setScalar(1.15); g.add(W);
  m(new THREE.BoxGeometry(30, 34, 3), dark, W, [0, -2, -1.6]);                        // facade
  m(new THREE.TorusGeometry(9.2, 0.9, 10, 48, Math.PI), stone, W, [0, 6.5, 0.2]);      // pointed hood arch (stylised)
  m(new THREE.TorusGeometry(7.6, 0.75, 12, 64), stone, W, [0, 0, 0.4]);                // wheel rim
  m(new THREE.TorusGeometry(5.0, 0.32, 8, 48), stone, W, [0, 0, 0.45]);
  for (let i = 0; i < 12; i++) {
    const a = i / 12 * Math.PI * 2;
    const sp = m(new THREE.BoxGeometry(0.42, 6.2, 0.55), stone, W, [Math.cos(a) * 4.35, Math.sin(a) * 4.35, 0.45], [0, 0, a - Math.PI / 2]);
  }
  m(new THREE.CylinderGeometry(1.35, 1.35, 0.9, 24), stone, W, [0, 0, 0.5], [Math.PI / 2, 0, 0]);
  // spikes on the rim: the wheel as an instrument of martyrdom
  for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2; m(new THREE.ConeGeometry(0.35, 1.6, 5), stone, W, [Math.cos(a) * 8.6, Math.sin(a) * 8.6, 0.4], [0, 0, a - Math.PI / 2]); }
  const glassMat = new THREE.MeshBasicMaterial({ map: wheelGlassTexture(), color: new THREE.Color(1, 1, 1).multiplyScalar(2.4), fog: true });
  m(new THREE.CircleGeometry(7.3, 64), glassMat, W, [0, 0, -0.05]);
  // flanking towers with pinnacles
  for (const sx of [-1, 1]) {
    m(new THREE.BoxGeometry(4, 40, 4), dark, W, [sx * 15, -1, 0]);
    m(new THREE.ConeGeometry(3, 12, 6), dark, W, [sx * 15, 25, 0]);
    for (let k = 0; k < 4; k++) m(new THREE.ConeGeometry(0.7, 4, 5), dark, W, [sx * 15 + (k % 2 ? 1.8 : -1.8), 20, k < 2 ? 1.8 : -1.8]);
  }
  A.rayTarget = V(-9, 17.5, -33.5);
  const winLight = new THREE.PointLight(LOOK.window.light, 22, 26, 1.6);
  winLight.position.set(-9, 11, -22); g.add(winLight);
  A.winLight = winLight;

  // ---------------------------------------------------------- the Mourning Saint
  const S = new THREE.Group(); S.position.set(15, -1.5, -42); S.rotation.y = -0.4; g.add(S);
  m(new THREE.BoxGeometry(14, 5, 12), dark, S, [0, 2.5, 0]);
  m(lathe([[6.2, 0], [6.0, 2], [5.0, 7], [4.0, 11], [3.2, 14], [2.6, 16.5], [0, 16.6]], 28), stone, S, [0, 5, 0]); // robe
  const head = new THREE.Group(); head.position.set(0, 22, 0.4); head.rotation.x = 0.42; S.add(head);
  m(lathe([[2.4, -1.2], [2.6, 0.5], [2.4, 2.2], [1.6, 3.4], [0.6, 3.9], [0, 4.0]], 24), stone, head); // veil
  m(new THREE.SphereGeometry(1.7, 16, 12), M.silhouette, head, [0, 1.3, 1.05], null, [1, 1.15, 0.7]); // hidden face
  const tearMat = new THREE.MeshBasicMaterial({ color: new THREE.Color(0xcc3a2e).multiplyScalar(3), fog: true });
  for (const x of [-0.55, 0.55]) {
    m(new THREE.BoxGeometry(0.16, 2.6, 0.12), tearMat, head, [x, 0.2, 2.05], [0.1, 0, 0]);
    m(new THREE.SphereGeometry(0.2, 8, 6), tearMat, head, [x, -1.2, 2.2]);
  }
  // halo of thorns
  const halo = new THREE.Group(); halo.position.set(0, 23.5, -1.6); S.add(halo);
  m(new THREE.TorusGeometry(4.4, 0.28, 8, 48), iron, halo);
  for (let i = 0; i < 28; i++) { const a = i / 28 * Math.PI * 2; m(new THREE.ConeGeometry(0.22, 1.8, 5), iron, halo, [Math.cos(a) * 5.2, Math.sin(a) * 5.2, 0], [0, 0, a - Math.PI / 2]); }
  m(new THREE.TorusGeometry(3.9, 0.09, 6, 64), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xab2629).multiplyScalar(4), fog: true }), halo);
  // arms folded over a spoked wheel relic
  for (const sx of [-1, 1]) m(new THREE.CylinderGeometry(0.9, 1.1, 7, 10), stone, S, [sx * 2.6, 15.5, 1.8], [0.9, 0, sx * -0.5]);
  const relic = new THREE.Group(); relic.position.set(0, 14.2, 3.3); relic.rotation.x = -0.25; S.add(relic);
  m(new THREE.TorusGeometry(2.1, 0.3, 8, 32), iron, relic);
  for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; m(new THREE.BoxGeometry(0.18, 2, 0.18), iron, relic, [Math.cos(a), Math.sin(a), 0], [0, 0, a - Math.PI / 2]); }
  m(new THREE.CylinderGeometry(0.45, 0.45, 0.5, 12), iron, relic, [0, 0, 0], [Math.PI / 2, 0, 0]);
  // wax pooling at her feet, with hundreds of candles
  A.saintCandles = [];
  const RS = rng(5);
  for (let i = 0; i < 60; i++) {
    const a = RS() * Math.PI - 0.1, r = 6.5 + RS() * 4;
    A.saintCandles.push(V(15 + Math.cos(a) * r * 1.1, -1.5 + 5.05, -42 + Math.sin(a) * r * 0.6 + 3));
  }

  // ---------------------------------------------------------- candles (instanced)
  const R = rng(13);
  const spots = [];
  for (let x = -34; x <= 34; x += 1.4) {
    if (R() < 0.35) continue;
    const n = 2 + Math.floor(R() * 4);
    for (let k = 0; k < n; k++) spots.push([x + (R() - 0.5) * 0.9, 1.15, -4.62 - R() * 0.3, 0.07 + R() * 0.16]);   // far parapet top
    if (R() < 0.6) for (let k = 0; k < 3; k++) spots.push([x + (R() - 0.5), 2.4, -6.0 - R() * 0.4, 0.08 + R() * 0.18]); // gallery ledge
  }
  for (const p of A.saintCandles) spots.push([p.x, p.y, p.z, 0.45 + R() * 0.35]);
  const cGeo = new THREE.CylinderGeometry(0.045, 0.05, 1, 6); cGeo.translate(0, 0.5, 0);
  const candles = new THREE.InstancedMesh(cGeo, wax, spots.length);
  const mt = new THREE.Matrix4();
  spots.forEach((p, i) => { const sc = p[3] > 0.4 ? 2.2 : 1; mt.compose(V(p[0], p[1], p[2]), new THREE.Quaternion(), V(sc, p[3] * sc, sc)); candles.setMatrixAt(i, mt); });
  g.add(candles);
  const fg = new THREE.PlaneGeometry(1, 1); fg.translate(0, 0.5, 0);
  const flames = new THREE.InstancedMesh(fg, A.flameMat, spots.length);
  const seeds = new Float32Array(spots.length);
  spots.forEach((p, i) => { const sc = p[3] > 0.4 ? 2.2 : 1; mt.compose(V(p[0], p[1] + p[3] * sc, p[2]), new THREE.Quaternion(), V(0.09 * sc, 0.2 * sc, 1)); flames.setMatrixAt(i, mt); seeds[i] = R(); });
  flames.geometry.setAttribute('aSeed', new THREE.InstancedBufferAttribute(seeds, 1));
  flames.frustumCulled = false; flames.renderOrder = 22;
  g.add(flames);
  // two broad, low candle-glow lights along the far wall
  for (const x of [-16, 16]) { const l = new THREE.PointLight(0xe0482c, 6, 18, 1.4); l.position.set(x, 1.8, -4.2); g.add(l); }

  // ---------------------------------------------------------- sigil banners
  const banTex = bannerTexture();
  const banMat = new THREE.MeshStandardMaterial({ map: banTex, roughness: 1, metalness: 0, alphaTest: 0.5, side: THREE.DoubleSide });
  banMat.onBeforeCompile = (sh) => {
    sh.uniforms.uTime = A.bannerTime = { value: 0 };
    sh.vertexShader = 'uniform float uTime;\n' + sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      float f = (0.5 - uv.y);
      transformed.z += sin(uTime * 1.3 + position.x * 2.0 + position.y * 0.8) * 0.18 * (1.0 - uv.y);`);
  };
  for (let x = -34; x <= 34; x += 8) {
    const b = m(new THREE.PlaneGeometry(1.7, 5.2, 2, 10), banMat, g, [x + 2, 5.6, -8.7]);
    b.userData.dynamic = true; b.castShadow = true;
  }

  // ---------------------------------------------------------- thorned wreaths on the tilt
  for (let x = -35; x <= 35; x += 7.5) {
    const w = new THREE.Group(); w.position.set(x, 0.72, 0); g.add(w);
    m(new THREE.TorusGeometry(0.22, 0.05, 6, 16), iron, w, null, [Math.PI / 2, 0, 0]);
    for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2; m(new THREE.ConeGeometry(0.03, 0.18, 4), iron, w, [Math.cos(a) * 0.24, 0, Math.sin(a) * 0.24], [0, 0, Math.PI / 2 * (i % 2 ? 1 : -1)]); }
  }

  // ---------------------------------------------------------- censers swinging in the foreground
  A.censers = [];
  for (const [x, z, len] of [[-20, 6.4, 7], [4, 7.2, 6], [26, 6.6, 7.5]]) {
    const pivot = new THREE.Group(); pivot.position.set(x, 14, z); pivot.userData.dynamic = true; g.add(pivot);
    m(new THREE.CylinderGeometry(0.035, 0.035, len, 5), iron, pivot, [0, -len / 2, 0]);
    const c = new THREE.Group(); c.position.set(0, -len - 0.5, 0); pivot.add(c);
    m(new THREE.SphereGeometry(0.42, 14, 10), iron, c, null, null, [1, 0.85, 1]);
    m(new THREE.TorusGeometry(0.43, 0.05, 6, 20), M.rust, c, null, [Math.PI / 2, 0, 0]);
    m(new THREE.ConeGeometry(0.3, 0.6, 8), iron, c, [0, 0.55, 0]);
    m(new THREE.SphereGeometry(0.16, 8, 6), new THREE.MeshBasicMaterial({ color: new THREE.Color(0xe6603e).multiplyScalar(4) }), c, [0, -0.05, 0]);
    A.censers.push({ pivot, bowl: c, phase: Math.random() * 6, puffT: 0 });
  }
}

// per-frame: banners, censer swing + incense smoke
export function updateReliquary(A, dt) {
  if (A.bannerTime) A.bannerTime.value = A.time;
  if (A.winLight) A.winLight.intensity = 20 + Math.sin(A.time * 0.7) * 4;
  for (const c of A.censers || []) {
    c.pivot.rotation.z = Math.sin(A.time * 0.9 + c.phase) * 0.16;
    c.pivot.rotation.x = Math.cos(A.time * 0.6 + c.phase) * 0.05;
    c.puffT -= dt;
    if (A.fx && c.puffT <= 0) {
      c.puffT = 0.09;
      const p = c.bowl.getWorldPosition(new THREE.Vector3());
      A.fx.puff(p, V((Math.random() - 0.5) * 0.3, 0.7 + Math.random() * 0.4, (Math.random() - 0.5) * 0.3), 0x8f8682, 0.35, 4.5, 0.18, 3.5, 0.4);
    }
  }
}
