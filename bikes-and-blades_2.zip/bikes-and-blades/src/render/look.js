// "Reliquary" art direction — the single source of truth for the palette and
// the light/fog/FX colours. "Beauty can also be a form of terror."
//
// Five families: charcoal-black, ash-grey, muted bone, burgundy, crimson.
// The pixel pass quantizes every frame to exactly these 24 colours.
export const PALETTE = {
  charcoal: ['#07060a', '#0e0c10', '#16131a', '#1f1b22'],
  ash:      ['#2b2730', '#3a353c', '#4b4549', '#5e5759', '#756d6c', '#8f8682'],
  bone:     ['#a99f90', '#c2b7a2', '#d9cdb5', '#eee4cf', '#f6dcb4'],
  burgundy: ['#2a0b12', '#3d1018', '#55161f', '#6e1d27'],
  crimson:  ['#8a1f24', '#ab2629', '#cc3a2e', '#e6603e', '#f08a4e'],
};
export const PALETTE_LIST = Object.values(PALETTE).flat();

export const LOOK = {
  pixelHeight: 300,        // internal render height in pixel mode
  dither: 0.085,
  fog: { color: 0x15121a, density: 0.0155 },
  hemi: { sky: 0x3c3442, ground: 0x1c0e12, intensity: 0.95 },
  moon: { color: 0xc9c0c4, intensity: 2.7 },          // cold bone rim from behind
  key: { color: 0xd8573c, intensity: 1.35 },          // candle-crimson from the camera side
  brazier: { color: 0xe0482c, intensity: 10 },
  charLight: { color: 0xead8c8, intensity: 6 },
  window: { glass: 0xc42a2c, bone: 0xeadcc0, light: 0xd23a2c },
  fx: {
    spark: 0xf6dcb4, ichor: 0xab2629, parry: 0xeee4cf, sigil: 0xcc3a2e, clash: 0xf6dcb4, ember: 0xe6603e,
  },
  // tell colours per strike line, kept inside the palette but far apart in value/hue
  zone: { over: 0xeee4cf, diag: 0xcc3a2e, horiz: 0xf08a4e, low: 0x8f8682, back: 0x6e1d27 },
};

export function hexToRgb01(h) {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16 & 255) / 255, (n >> 8 & 255) / 255, (n & 255) / 255];
}
