// HDR post pipeline: MSAA scene target → mip-chain bloom → cinematic composite.
import * as THREE from 'three';
import { PALETTE_LIST, hexToRgb01 } from './look.js';

const QUAD_VS = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }`;

const BRIGHT_FS = `
uniform sampler2D tSrc; uniform float uThreshold; uniform vec2 uTexel; varying vec2 vUv;
void main(){
  vec3 c = vec3(0.0);
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2( 1.0,-1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2(-1.0, 1.0)).rgb;
  c += texture2D(tSrc, vUv + uTexel * vec2( 1.0, 1.0)).rgb;
  c *= 0.25;
  float l = max(c.r, max(c.g, c.b));
  float k = max(0.0, l - uThreshold) / max(l, 1e-4);
  gl_FragColor = vec4(min(c * k, vec3(40.0)), 1.0);
}`;
const DOWN_FS = `
uniform sampler2D tSrc; uniform vec2 uTexel; varying vec2 vUv;
void main(){
  vec3 a = texture2D(tSrc, vUv + uTexel * vec2(-2.0, 2.0)).rgb, b = texture2D(tSrc, vUv + uTexel * vec2(0.0, 2.0)).rgb, c = texture2D(tSrc, vUv + uTexel * vec2(2.0, 2.0)).rgb;
  vec3 d = texture2D(tSrc, vUv + uTexel * vec2(-2.0, 0.0)).rgb, e = texture2D(tSrc, vUv).rgb, f = texture2D(tSrc, vUv + uTexel * vec2(2.0, 0.0)).rgb;
  vec3 g = texture2D(tSrc, vUv + uTexel * vec2(-2.0,-2.0)).rgb, h = texture2D(tSrc, vUv + uTexel * vec2(0.0,-2.0)).rgb, i = texture2D(tSrc, vUv + uTexel * vec2(2.0,-2.0)).rgb;
  vec3 j = texture2D(tSrc, vUv + uTexel * vec2(-1.0, 1.0)).rgb, k = texture2D(tSrc, vUv + uTexel * vec2(1.0, 1.0)).rgb;
  vec3 l = texture2D(tSrc, vUv + uTexel * vec2(-1.0,-1.0)).rgb, m = texture2D(tSrc, vUv + uTexel * vec2(1.0,-1.0)).rgb;
  vec3 o = e * 0.125 + (a + c + g + i) * 0.03125 + (b + d + f + h) * 0.0625 + (j + k + l + m) * 0.125;
  gl_FragColor = vec4(o, 1.0);
}`;
const UP_FS = `
uniform sampler2D tSrc; uniform vec2 uTexel; uniform float uRadius; varying vec2 vUv;
void main(){
  vec2 r = uTexel * uRadius;
  vec3 o = texture2D(tSrc, vUv).rgb * 4.0;
  o += (texture2D(tSrc, vUv + vec2(-r.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(r.x, 0.0)).rgb + texture2D(tSrc, vUv + vec2(0.0, -r.y)).rgb + texture2D(tSrc, vUv + vec2(0.0, r.y)).rgb) * 2.0;
  o += texture2D(tSrc, vUv + vec2(-r.x, -r.y)).rgb + texture2D(tSrc, vUv + vec2(r.x, -r.y)).rgb + texture2D(tSrc, vUv + vec2(-r.x, r.y)).rgb + texture2D(tSrc, vUv + vec2(r.x, r.y)).rgb;
  gl_FragColor = vec4(o / 16.0, 1.0);
}`;
const COMPOSITE_FS = `
uniform sampler2D tScene; uniform sampler2D tBloom;
uniform float uBloom, uExposure, uTime, uVignette, uAberration, uZoom, uGrain, uBars, uFlash, uDesat, uRed, uBloomOn;
uniform vec2 uCenter; uniform vec2 uRes; uniform vec2 uLowRes;
uniform float uPixel, uDither;
uniform vec3 uPal[${PALETTE_LIST.length}];
uniform vec2 uRayPos; uniform float uRays;
varying vec2 vUv;
vec3 aces(vec3 x){ const float a=2.51, b=0.03, c=2.43, d=0.59, e=0.14; return clamp((x*(a*x+b))/(x*(c*x+d)+e), 0.0, 1.0); }
float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898,78.233))) * 43758.5453); }
float bayer4(vec2 p){
  // 4x4 ordered dither, 0..1
  vec2 q = mod(floor(p), 4.0);
  int i = int(q.x) + int(q.y) * 4;
  float m[16];
  m[0]=0.0; m[1]=8.0; m[2]=2.0; m[3]=10.0; m[4]=12.0; m[5]=4.0; m[6]=14.0; m[7]=6.0;
  m[8]=3.0; m[9]=11.0; m[10]=1.0; m[11]=9.0; m[12]=15.0; m[13]=7.0; m[14]=13.0; m[15]=5.0;
  float v = 0.0;
  for (int k = 0; k < 16; k++) if (k == i) v = m[k];
  return (v + 0.5) / 16.0;
}
vec3 sampleScene(vec2 uv){
  vec3 c;
  if (uAberration > 0.0005) {
    vec2 d = (uv - 0.5) * uAberration;
    c = vec3(texture2D(tScene, uv + d).r, texture2D(tScene, uv).g, texture2D(tScene, uv - d).b);
  } else c = texture2D(tScene, uv).rgb;
  return c;
}
vec3 toSRGB(vec3 c){ c = clamp(c, 0.0, 1.0); return mix(c * 12.92, 1.055 * pow(c, vec3(1.0/2.4)) - 0.055, step(0.0031308, c)); }
vec3 nearestPal(vec3 c){
  // "redmean" weighted distance, cheap and perceptually decent
  float best = 1e9; vec3 bc = c;
  for (int i = 0; i < ${PALETTE_LIST.length}; i++) {
    vec3 p = uPal[i]; vec3 d = c - p;
    float rm = (c.r + p.r) * 0.5;
    float dist = (2.0 + rm) * d.r * d.r + 4.0 * d.g * d.g + (3.0 - rm) * d.b * d.b;
    if (dist < best) { best = dist; bc = p; }
  }
  return bc;
}
void main(){
  vec2 uv = vUv;
  // in pixel mode every effect works on whole low-res pixels
  vec2 puv = uPixel > 0.5 ? (floor(uv * uLowRes) + 0.5) / uLowRes : uv;
  vec3 col = vec3(0.0);
  if (uZoom > 0.001) {
    vec2 dir = (puv - uCenter);
    float tot = 0.0;
    for (int i = 0; i < 10; i++) { float t = float(i) / 9.0; float w = 1.0 - t * 0.6; col += sampleScene(puv - dir * uZoom * t) * w; tot += w; }
    col /= tot;
  } else col = sampleScene(puv);
  if (uBloomOn > 0.5) col += texture2D(tBloom, puv).rgb * uBloom;
  // god rays: march the bright pass toward the rose window
  if (uRays > 0.001) {
    vec2 d = (uRayPos - puv) / 28.0;
    vec2 p = puv; float decay = 1.0; vec3 acc = vec3(0.0);
    for (int i = 0; i < 28; i++) { p += d; acc += texture2D(tBloom, p).rgb * decay; decay *= 0.95; }
    col += acc * uRays / 28.0;
  }
  col *= uExposure;
  col = aces(col);
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  // split tone: violet-ash shadows, bone highlights, blood in the mids
  vec3 shadowTint = vec3(0.98, 0.9, 1.04), highTint = vec3(1.06, 0.99, 0.9);
  col *= mix(shadowTint, highTint, smoothstep(0.05, 0.7, l));
  col = mix(vec3(l), col, 0.86 - uDesat * 0.7);
  col = mix(col, vec3(l * 1.25, l * 0.32, l * 0.24), uRed);
  vec2 q = uv - 0.5; q.x *= uRes.x / uRes.y;
  col *= mix(1.0, smoothstep(1.05, 0.25, length(q)), uVignette);
  col += uFlash;
  vec3 s = toSRGB(col);
  if (uPixel > 0.5) {
    // ordered dither, then snap to the 25-colour reliquary palette
    float b = bayer4(floor(uv * uLowRes)) - 0.5;
    s = nearestPal(clamp(s + b * uDither, 0.0, 1.0));
  } else {
    s += (hash(uv * uRes + fract(uTime * 7.13) * 100.0) - 0.5) * uGrain;
  }
  float bar = uBars * 0.11;
  if (uv.y < bar || uv.y > 1.0 - bar) s = uPal[0];
  gl_FragColor = vec4(s, 1.0);
}`;

export class Post {
  constructor(renderer, quality = 'high') {
    this.r = renderer;
    this.quality = quality;
    this.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2));
    this.quad.frustumCulled = false;
    this.qscene = new THREE.Scene(); this.qscene.add(this.quad);
    const mk = (fs, uniforms) => new THREE.ShaderMaterial({ vertexShader: QUAD_VS, fragmentShader: fs, uniforms, depthTest: false, depthWrite: false });
    this.mBright = mk(BRIGHT_FS, { tSrc: { value: null }, uThreshold: { value: 1.0 }, uTexel: { value: new THREE.Vector2() } });
    this.mDown = mk(DOWN_FS, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } });
    this.mUp = mk(UP_FS, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uRadius: { value: 1 } });
    this.mUp.blending = THREE.AdditiveBlending; this.mUp.transparent = true;
    this.mComp = mk(COMPOSITE_FS, {
      tScene: { value: null }, tBloom: { value: null }, uBloom: { value: 0.55 }, uExposure: { value: 1.3 }, uTime: { value: 0 },
      uVignette: { value: 0.85 }, uAberration: { value: 0 }, uZoom: { value: 0 }, uGrain: { value: 0.012 }, uBars: { value: 0 },
      uFlash: { value: 0 }, uDesat: { value: 0 }, uRed: { value: 0 }, uCenter: { value: new THREE.Vector2(0.5, 0.5) }, uRes: { value: new THREE.Vector2(1, 1) },
      uBloomOn: { value: 1 }, uLowRes: { value: new THREE.Vector2(1, 1) }, uPixel: { value: 0 }, uDither: { value: 0.085 },
      uPal: { value: PALETTE_LIST.map(h => new THREE.Vector3(...hexToRgb01(h))) }, uRayPos: { value: new THREE.Vector2(0.5, 0.8) }, uRays: { value: 0 },
    });
    this.pixel = false;
    this.rays = 0;
    this.fx = { aberration: 0, zoom: 0, flash: 0, bars: 0, desat: 0, red: 0, center: new THREE.Vector2(0.5, 0.5) };
    this.targets = null;
    this.setQuality(quality);
  }

  setQuality(q) {
    this.quality = q;
    this.mComp.uniforms.uBloomOn.value = q === 'low' ? 0 : 1;
    if (this.size) this.setSize(this.size.x, this.size.y, this.size.dpr);
  }

  // Pixel mode renders the 3D scene at a low internal resolution (about
  // `height` lines) and upscales with nearest filtering; the composite
  // then dithers and snaps every pixel to the palette.
  setPixel(on, palette, height = 300, dither = 0.085) {
    this.pixel = !!on;
    this.pixelHeight = height;
    const U = this.mComp.uniforms;
    U.uPixel.value = on ? 1 : 0; U.uDither.value = dither;
    if (palette) U.uPal.value = palette.map(c => new THREE.Vector3(c[0], c[1], c[2]));
    if (this.size) this.setSize(this.size.x, this.size.y, this.size.dpr);
  }

  setSize(w, h, dpr) {
    this.size = { x: w, y: h, dpr };
    let W = Math.max(1, Math.floor(w * dpr)), H = Math.max(1, Math.floor(h * dpr));
    this.mComp.uniforms.uRes.value.set(W, H);
    if (this.pixel) { const k = Math.max(1, H / (this.pixelHeight || 300)); W = Math.max(1, Math.round(W / k)); H = Math.max(1, Math.round(H / k)); }
    this.mComp.uniforms.uLowRes.value.set(W, H);
    if (this.targets) { this.targets.scene.dispose(); this.targets.mips.forEach(t => t.dispose()); }
    const opts = { type: THREE.HalfFloatType, format: THREE.RGBAFormat, colorSpace: THREE.LinearSRGBColorSpace, depthBuffer: false };
    const scene = new THREE.WebGLRenderTarget(W, H, { type: THREE.HalfFloatType, depthBuffer: true, samples: this.quality === 'high' && !this.pixel ? 4 : 0 });
    if (this.pixel) scene.texture.minFilter = scene.texture.magFilter = THREE.NearestFilter;
    const mips = [];
    let mw = W >> 1, mh = H >> 1;
    for (let i = 0; i < 5; i++) {
      const t = new THREE.WebGLRenderTarget(Math.max(1, mw), Math.max(1, mh), opts);
      t.texture.minFilter = t.texture.magFilter = THREE.LinearFilter;
      mips.push(t); mw >>= 1; mh >>= 1;
    }
    this.targets = { scene, mips };
  }

  pass(mat, target) {
    this.quad.material = mat;
    this.r.setRenderTarget(target);
    this.r.render(this.qscene, this.cam);
  }

  render(scene, camera, dt) {
    const r = this.r, T = this.targets;
    r.setRenderTarget(T.scene);
    r.render(scene, camera);
    const bloomOn = this.mComp.uniforms.uBloomOn.value > 0.5;
    if (bloomOn) {
      const m0 = T.mips[0];
      this.mBright.uniforms.tSrc.value = T.scene.texture;
      this.mBright.uniforms.uTexel.value.set(1 / T.scene.width, 1 / T.scene.height);
      this.pass(this.mBright, m0);
      for (let i = 1; i < T.mips.length; i++) {
        this.mDown.uniforms.tSrc.value = T.mips[i - 1].texture;
        this.mDown.uniforms.uTexel.value.set(1 / T.mips[i - 1].width, 1 / T.mips[i - 1].height);
        this.pass(this.mDown, T.mips[i]);
      }
      r.autoClear = false;
      for (let i = T.mips.length - 1; i > 0; i--) {
        this.mUp.uniforms.tSrc.value = T.mips[i].texture;
        this.mUp.uniforms.uTexel.value.set(1 / T.mips[i].width, 1 / T.mips[i].height);
        this.pass(this.mUp, T.mips[i - 1]);
      }
      r.autoClear = true;
    }
    // decay transient effects
    const F = this.fx, k = Math.min(1, dt * 6);
    F.aberration *= 1 - k; F.zoom *= 1 - Math.min(1, dt * 7); F.flash *= 1 - Math.min(1, dt * 10);
    const U = this.mComp.uniforms;
    U.tScene.value = T.scene.texture; U.tBloom.value = T.mips[0].texture;
    U.uTime.value += dt;
    U.uAberration.value = 0.0015 + F.aberration;
    U.uZoom.value = F.zoom;
    U.uFlash.value = F.flash;
    U.uBars.value += (F.bars - U.uBars.value) * Math.min(1, dt * 5);
    U.uDesat.value += (F.desat - U.uDesat.value) * Math.min(1, dt * 6);
    U.uRed.value += (F.red - U.uRed.value) * Math.min(1, dt * 4);
    U.uCenter.value.copy(F.center);
    U.uRays.value = this.rays;
    if (this.rayPos) U.uRayPos.value.copy(this.rayPos);
    this.pass(this.mComp, null);
  }

  kick({ aberration = 0, zoom = 0, flash = 0, center = null } = {}) {
    const F = this.fx;
    F.aberration = Math.max(F.aberration, aberration);
    F.zoom = Math.max(F.zoom, zoom);
    F.flash = Math.max(F.flash, flash);
    if (center) F.center.copy(center);
  }
}
