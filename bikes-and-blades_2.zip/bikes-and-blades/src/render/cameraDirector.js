// 2.5D fight camera: side-on framing that breathes with the action.
import * as THREE from 'three';
import { ARENA } from '../core/data.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);

export class CameraDirector {
  constructor(camera) {
    this.cam = camera;
    this.pos = V(0, 4, 20); this.look = V(0, 1.2, 0);
    this.posV = V(0, 0, 0); this.lookV = V(0, 0, 0);
    this.fov = 34; this.fovKick = 0;
    this.trauma = 0; this.shakeScale = 1;
    this.mode = 'fight';
    this.t = 0; this.modeT = 0;
    this.koFocus = V(0, 1, 0);
    this.orbitDir = 1;
  }
  setMode(mode, data = {}) {
    if (mode !== this.mode) this.modeT = 0;
    this.mode = mode;
    if (data.focus) this.koFocus.copy(data.focus);
    if (data.dir) this.orbitDir = data.dir;
  }
  shake(amount) { this.trauma = Math.min(1, this.trauma + amount * this.shakeScale); }
  punch(fov) { this.fovKick = Math.min(this.fovKick + fov * 0.7, 4.5); }

  smooth(cur, vel, target, dt, k) {
    // critically damped follow
    const c = 2 * Math.sqrt(k);
    vel.x += (k * (target.x - cur.x) - c * vel.x) * dt;
    vel.y += (k * (target.y - cur.y) - c * vel.y) * dt;
    vel.z += (k * (target.z - cur.z) - c * vel.z) * dt;
    cur.addScaledVector(vel, dt);
  }

  update(dt, riders, phase) {
    this.t += dt; this.modeT += dt;
    const dts = Math.min(dt, 1 / 30);
    let targetPos, targetLook, fov = 34, k = 9;
    const [a, b] = riders;
    if (this.mode === 'intro') {
      // crane down from the colossus onto the riders
      const e = Math.min(1, this.modeT / 2.8);
      const s = e * e * (3 - 2 * e);
      targetPos = V(THREE.MathUtils.lerp(16, 0, s), THREE.MathUtils.lerp(16, 4.2, s), THREE.MathUtils.lerp(34, 23, s));
      targetLook = V(THREE.MathUtils.lerp(10, 0, s), THREE.MathUtils.lerp(14, 1.3, s), THREE.MathUtils.lerp(-30, 0, s));
      fov = 36; k = 30;
    } else if (this.mode === 'select') {
      targetPos = V(0, 2.15, 8.6); targetLook = V(0, 1.55, 0); fov = 30; k = 6;
    } else if (this.mode === 'attract') {
      // slow drifting cinematic for the title screen
      const mid = (a.x + b.x) / 2;
      const dist = Math.min(48, Math.abs(a.x - b.x));
      const sway = Math.sin(this.t * 0.11);
      targetPos = V(mid + sway * 4, 2.8 + Math.sin(this.t * 0.17) * 0.9, 10.5 + dist * 0.4 + Math.cos(this.t * 0.13) * 2);
      targetLook = V(mid + sway * 1.2, 1.5, -1);
      fov = 32; k = 1.5;
    } else if (this.mode === 'ko') {
      // slow orbit around the fallen
      const ang = this.orbitDir * (0.4 + this.modeT * 0.25);
      const r = 7.5 - Math.min(2, this.modeT * 0.8);
      targetPos = V(this.koFocus.x + Math.sin(ang) * r, 1.9 + this.modeT * 0.3, this.koFocus.z + Math.cos(ang) * r + 2);
      targetLook = V(this.koFocus.x, 0.9, this.koFocus.z);
      fov = 34; k = 4;
    } else if (this.mode === 'victory') {
      const w = this.koFocus;
      const ang = this.orbitDir * (0.6 + this.modeT * 0.12);
      targetPos = V(w.x + Math.sin(ang) * 6, 2.3, w.z + Math.cos(ang) * 6 + 1.5);
      targetLook = V(w.x, 1.5, w.z);
      fov = 32; k = 3;
    } else {
      // FIGHT: frame both riders side-on
      // frame where the riders are AND where they will be in half a second,
      // so the camera never trails a bike out of shot after a crossing
      const pa = a.x + a.facing * a.v * 0.5, pb = b.x + b.facing * b.v * 0.5;
      const lo = Math.min(a.x, b.x, pa, pb), hi = Math.max(a.x, b.x, pa, pb);
      // on a long run-up follow the focus rider (the human) with a lead toward the rival,
      // so the riders never shrink to specks
      const MAXD = 22;
      let mid = (lo + hi) / 2, dist = hi - lo;
      if (dist > MAXD && this.focus !== undefined && this.focus >= 0) {
        const f = this.focus === 0 ? a : b, o = this.focus === 0 ? b : a;
        const dir = Math.sign(o.x - f.x) || f.facing;
        mid = f.x + dir * (MAXD / 2 - 3);
        dist = MAXD;
      }
      mid = THREE.MathUtils.clamp(mid, -ARENA.half - ARENA.runoff + 6, ARENA.half + ARENA.runoff - 6);
      // distance that fits both riders (plus margin) for this screen's aspect
      const halfFov = THREE.MathUtils.degToRad(34) / 2;
      const aspect = Math.max(0.5, this.cam.aspect);
      // margin covers the bike length plus the near lane, which sits closer to the camera
      let z = THREE.MathUtils.clamp((dist / 2 + 3.2) / (Math.tan(halfFov) * aspect) + 1.8, 8.6, 58);
      let y = 2.2 + (z - 9) * 0.05;
      // crossing moment: dolly in, drop lower and swing for depth
      const closing = (a.facing * a.v - b.facing * b.v) * Math.sign(b.x - a.x);
      const gap = Math.abs(a.x - b.x);
      const crossing = gap < 9 && closing > 6 ? 1 - gap / 9 : 0;
      this.cross = (this.cross || 0) + (crossing - (this.cross || 0)) * Math.min(1, dt * 6);
      const c = this.cross;
      z = Math.max(8.6, z - c * 1.2); y -= c * 0.5;
      const swing = c * 0.8 * Math.sign((a.facing > 0 ? 1 : -1));
      targetPos = V(mid + swing, y, z);
      // tilt so the deck sits ~20% above the bottom edge, like a fighting-game stage
      const want = 0.27 * THREE.MathUtils.degToRad(34);
      const pitch = Math.atan2(y, z) - want;
      targetLook = V(mid, y - z * Math.tan(pitch), -0.2);
      fov = 34 - c * 2;
      k = 10;
    }
    // fixed substeps: identical at 60 fps, and still converges when frames are slow
    const steps = Math.min(30, Math.ceil(dt / (1 / 120)));
    for (let i = 0; i < steps; i++) {
      this.smooth(this.pos, this.posV, targetPos, dt / steps, k);
      this.smooth(this.look, this.lookV, targetLook, dt / steps, k * 1.2);
    }
    // trauma-based shake
    this.trauma = Math.max(0, this.trauma - dt * 1.6);
    const s = this.trauma * this.trauma;
    const sh = V(
      (noise1(this.t * 31) ) * s * 0.55,
      (noise1(this.t * 29 + 7)) * s * 0.4,
      (noise1(this.t * 27 + 13)) * s * 0.3);
    this.cam.position.copy(this.pos).add(sh);
    this.cam.lookAt(this.look);
    this.cam.rotateZ(noise1(this.t * 23 + 3) * s * 0.035);
    this.fovKick *= Math.exp(-dt * 9);
    this.fov += (fov - this.fov) * Math.min(1, dt * 4);
    this.cam.fov = this.fov - this.fovKick;
    this.cam.updateProjectionMatrix();
  }
}

function noise1(x) {
  const i = Math.floor(x), f = x - i;
  const h = n => { const s = Math.sin(n * 127.1) * 43758.5453; return (s - Math.floor(s)) * 2 - 1; };
  const u = f * f * (3 - 2 * f);
  return h(i) * (1 - u) + h(i + 1) * u;
}
