// Procedural texture factory. Everything is painted at load time into canvases:
// tileable noise, voronoi cobbles, ashlar blocks, hammered iron, leather,
// torn cloth, tyre tread, heraldic shield emblems and particle sprites.
import * as THREE from 'three';

// ---------------------------------------------------------------- noise
function hash2(x, y, seed) {
  let h = (x * 374761393 + y * 668265263 + seed * 2147483647) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}
// periodic value noise: period p (in cells)
function vnoise(x, y, p, seed) {
  const xi = Math.floor(x), yi = Math.floor(y);
  const xf = x - xi, yf = y - yi;
  const u = xf * xf * (3 - 2 * xf), v = yf * yf * (3 - 2 * yf);
  const m = (a) => ((a % p) + p) % p;
  const a = hash2(m(xi), m(yi), seed), b = hash2(m(xi + 1), m(yi), seed);
  const c = hash2(m(xi), m(yi + 1), seed), d = hash2(m(xi + 1), m(yi + 1), seed);
  return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
}
export function fbm(x, y, base, oct, seed) {
  let sum = 0, amp = 0.5, f = 1, norm = 0;
  for (let i = 0; i < oct; i++) {
    sum += amp * vnoise(x * base * f, y * base * f, base * f, seed + i * 17);
    norm += amp; amp *= 0.5; f *= 2;
  }
  return sum / norm;
}
// periodic voronoi: returns [f1, f2, cellId]
function voronoi(x, y, n, seed) {
  const px = x * n, py = y * n;
  const xi = Math.floor(px), yi = Math.floor(py);
  let f1 = 9, f2 = 9, id = 0;
  for (let j = -1; j <= 1; j++) for (let i = -1; i <= 1; i++) {
    const cx = xi + i, cy = yi + j;
    const wx = ((cx % n) + n) % n, wy = ((cy % n) + n) % n;
    const ox = hash2(wx, wy, seed), oy = hash2(wx, wy, seed + 9);
    const dx = cx + 0.15 + ox * 0.7 - px, dy = cy + 0.15 + oy * 0.7 - py;
    const d = Math.sqrt(dx * dx + dy * dy);
    if (d < f1) { f2 = f1; f1 = d; id = hash2(wx, wy, seed + 3); } else if (d < f2) f2 = d;
  }
  return [f1, f2, id];
}

function canvas(w, h = w) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

// Build albedo/normal/rough canvases by evaluating fn(u,v) -> {r,g,b,h,ro}
function paint(size, fn, normalStrength = 2) {
  const alb = canvas(size), nor = canvas(size), rou = canvas(size);
  const A = alb.getContext('2d').createImageData(size, size);
  const N = nor.getContext('2d').createImageData(size, size);
  const R = rou.getContext('2d').createImageData(size, size);
  const H = new Float32Array(size * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const o = fn(x / size, y / size);
    const i = y * size + x;
    H[i] = o.h;
    A.data[i * 4] = clamp255(o.r); A.data[i * 4 + 1] = clamp255(o.g); A.data[i * 4 + 2] = clamp255(o.b); A.data[i * 4 + 3] = o.a === undefined ? 255 : clamp255(o.a);
    const ro = clamp255(o.ro * 255);
    R.data[i * 4] = ro; R.data[i * 4 + 1] = ro; R.data[i * 4 + 2] = ro; R.data[i * 4 + 3] = 255;
  }
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const xl = (x - 1 + size) % size, xr = (x + 1) % size, yu = (y - 1 + size) % size, yd = (y + 1) % size;
    const dx = (H[y * size + xr] - H[y * size + xl]) * normalStrength;
    const dy = (H[yd * size + x] - H[yu * size + x]) * normalStrength;
    const l = Math.hypot(dx, dy, 1);
    const i = (y * size + x) * 4;
    N.data[i] = (-dx / l * 0.5 + 0.5) * 255; N.data[i + 1] = (dy / l * 0.5 + 0.5) * 255; N.data[i + 2] = (1 / l * 0.5 + 0.5) * 255; N.data[i + 3] = 255;
  }
  alb.getContext('2d').putImageData(A, 0, 0);
  nor.getContext('2d').putImageData(N, 0, 0);
  rou.getContext('2d').putImageData(R, 0, 0);
  return { alb, nor, rou };
}
const clamp255 = v => v < 0 ? 0 : v > 255 ? 255 : v;

function toTex(c, srgb, repeat = 1) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(repeat, repeat);
  t.colorSpace = srgb ? THREE.SRGBColorSpace : THREE.NoColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}
function set(p) { return { map: toTex(p.alb, true), normalMap: toTex(p.nor, false), roughnessMap: toTex(p.rou, false) }; }

// ---------------------------------------------------------------- materials' maps

export function cobbleMaps() {
  return set(paint(512, (u, v) => {
    const [f1, f2, id] = voronoi(u, v, 9, 11);
    const edge = f2 - f1;
    const mortar = edge < 0.07 ? 1 - edge / 0.07 : 0;
    const n = fbm(u, v, 8, 5, 3), fine = fbm(u, v, 64, 2, 7);
    const dome = Math.max(0, 1 - f1 * 1.6);
    const h = (1 - mortar) * (0.45 + dome * 0.4 + n * 0.25) + fine * 0.05;
    const tone = 0.55 + id * 0.35 + (n - 0.5) * 0.35;
    const wet = fbm(u, v, 3, 3, 21) > 0.6 ? 0.55 : 1;
    const base = [58, 54, 50].map(c => c * tone);
    const moss = mortar * fbm(u, v, 16, 2, 5);
    return {
      r: base[0] * (1 - mortar * 0.6) + moss * 10, g: base[1] * (1 - mortar * 0.6) + moss * 18, b: base[2] * (1 - mortar * 0.6),
      h, ro: Math.min(1, (0.72 + mortar * 0.25 - dome * 0.1) * wet + 0.05),
    };
  }, 3.2));
}

export function ashlarMaps() {
  return set(paint(512, (u, v) => {
    const rows = 6, row = Math.floor(v * rows);
    const off = (row % 2) * 0.5;
    const cols = 3, cu = u * cols + off;
    const col = Math.floor(cu);
    const fx = cu - col, fy = v * rows - row;
    const gap = 0.035;
    const edgeD = Math.min(fx, 1 - fx, (fy) / 2, (1 - fy) / 2);
    const joint = edgeD < gap ? 1 - edgeD / gap : 0;
    const id = hash2(((col % cols) + cols) % cols, row, 4);
    const n = fbm(u, v, 6, 5, 9), cr = fbm(u, v, 24, 3, 13);
    const chip = Math.max(0, (fbm(u, v, 12, 3, 31) - 0.68) * 4);
    const h = (1 - joint) * (0.6 + n * 0.3 - chip * 0.3) + cr * 0.06;
    const t = 0.62 + id * 0.25 + (n - 0.5) * 0.3 - chip * 0.15;
    const soot = Math.pow(1 - v, 2) * 0.0 + fbm(u, v, 2, 3, 77) * 0.25;
    return { r: 70 * t * (1 - joint * 0.5) * (1 - soot), g: 66 * t * (1 - joint * 0.5) * (1 - soot), b: 60 * t * (1 - joint * 0.5) * (1 - soot), h, ro: 0.82 + joint * 0.15 };
  }, 3));
}

export function ironMaps() {
  return set(paint(256, (u, v) => {
    const n = fbm(u, v, 4, 5, 41);
    const dents = voronoi(u, v, 6, 5)[0];
    const pit = fbm(u, v, 32, 2, 7);
    const scratch = (hash2(Math.floor(u * 256), Math.floor(v * 256), 9) > 0.996) ? 1 : 0;
    const rust = Math.max(0, (fbm(u, v, 5, 5, 61) - 0.58) * 3.0);
    const h = dents * 0.18 + n * 0.12 + pit * 0.05 - rust * 0.12;
    const g = 78 + n * 46 + scratch * 50;
    return {
      r: g * (1 - rust) + rust * 120, g: g * (1 - rust) + rust * 62, b: g * 1.04 * (1 - rust) + rust * 34,
      h, ro: Math.min(1, 0.38 + n * 0.25 + rust * 0.5 - scratch * 0.2),
    };
  }, 1.6));
}

// White-ish paint with chips revealing dark metal underneath; tinted by material color.
export function paintMaps() {
  return set(paint(256, (u, v) => {
    const n = fbm(u, v, 4, 5, 81);
    const chip = fbm(u, v, 10, 4, 83) > 0.64 ? 1 : 0;
    const grime = fbm(u, v, 3, 4, 85);
    const h = chip ? 0.2 : 0.5 + n * 0.1;
    const t = chip ? 55 : 200 - grime * 90;
    return { r: t + (chip ? 10 : 0), g: t, b: t - (chip ? 5 : 0), h, ro: chip ? 0.45 : 0.55 + grime * 0.3 };
  }, 2));
}

export function leatherMaps() {
  return set(paint(256, (u, v) => {
    const [f1, f2] = voronoi(u, v, 40, 7);
    const crease = Math.max(0, 1 - (f2 - f1) * 6);
    const n = fbm(u, v, 5, 4, 91);
    const h = 0.6 - crease * 0.3 + n * 0.1;
    const t = 0.7 + n * 0.5 - crease * 0.2;
    return { r: 92 * t, g: 64 * t, b: 44 * t, h, ro: 0.62 + crease * 0.2 };
  }, 1.5));
}

// Woven cloth with a ragged, torn lower edge in alpha (v=1 is the hem).
export function clothMaps() {
  return set(paint(256, (u, v) => {
    const weave = (Math.sin(u * 256 * Math.PI) * Math.sin(v * 256 * Math.PI)) * 0.5 + 0.5;
    const n = fbm(u, v, 4, 5, 101);
    const tear = fbm(u, 0.3, 12, 4, 103) * 0.35 + fbm(u, v, 6, 3, 105) * 0.15;
    const hole = fbm(u, v, 8, 4, 107) > 0.74 && v > 0.35 ? 1 : 0;
    const alpha = (v > 0.78 + (tear - 0.25)) || hole ? 0 : 255;
    const burn = Math.max(0, (v - 0.6) * 2.2) * (0.5 + tear);
    const t = (0.72 + weave * 0.12 + n * 0.3) * (1 - burn * 0.6);
    return { r: 210 * t, g: 205 * t, b: 195 * t, a: alpha, h: weave * 0.2 + n * 0.3, ro: 0.92 };
  }, 4));
}

export function tireMaps() {
  return set(paint(256, (u, v) => {
    const chev = Math.abs(((u * 18 + Math.abs(v - 0.5) * 3) % 1) - 0.5) < 0.18 ? 1 : 0;
    const n = fbm(u, v, 8, 3, 111);
    const h = chev * 0.6 + n * 0.15;
    const t = 26 + n * 18 + (1 - chev) * 6;
    return { r: t, g: t, b: t * 1.05, h, ro: 0.9 - chev * 0.08 };
  }, 4));
}

export function woodMaps() {
  return set(paint(256, (u, v) => {
    const ring = Math.sin((u * 30 + fbm(u, v, 3, 4, 121) * 6) * Math.PI) * 0.5 + 0.5;
    const n = fbm(u, v, 6, 4, 123);
    const crack = fbm(u * 6, v * 0.5, 4, 3, 125) > 0.7 ? 1 : 0;
    const h = ring * 0.25 + n * 0.25 - crack * 0.4;
    const t = 0.5 + ring * 0.25 + n * 0.3 - crack * 0.3;
    return { r: 82 * t, g: 60 * t, b: 42 * t, h, ro: 0.85 };
  }, 2.5));
}

// Heraldry painted on a heater shield. Returns a texture (sRGB).
const emblemCache = new Map();
export function emblemTexture(kind, fieldHex, trimHex) {
  const key = kind + fieldHex + ':' + trimHex;
  if (!emblemCache.has(key)) emblemCache.set(key, paintEmblem(kind, fieldHex, trimHex));
  return emblemCache.get(key);
}
function paintEmblem(kind, fieldHex, trimHex) {
  const S = 512, c = canvas(S), g = c.getContext('2d');
  const field = '#' + fieldHex.toString(16).padStart(6, '0');
  const trim = '#' + trimHex.toString(16).padStart(6, '0');
  g.fillStyle = field; g.fillRect(0, 0, S, S);
  // grime gradient
  const gr = g.createRadialGradient(S / 2, S * 0.4, S * 0.1, S / 2, S / 2, S * 0.75);
  gr.addColorStop(0, 'rgba(255,240,220,0.08)'); gr.addColorStop(1, 'rgba(0,0,0,0.55)');
  g.fillStyle = gr; g.fillRect(0, 0, S, S);
  g.strokeStyle = trim; g.fillStyle = trim; g.lineWidth = 18; g.lineCap = 'round';
  g.save(); g.translate(S / 2, S * 0.46);
  if (kind === 'sun') {
    // a black sun with a ring of flames
    for (let i = 0; i < 16; i++) {
      g.save(); g.rotate(i / 16 * Math.PI * 2);
      g.beginPath(); g.moveTo(0, -96); g.quadraticCurveTo(14, -130, 0, -168 - (i % 2) * 22); g.quadraticCurveTo(-14, -130, 0, -96); g.fill();
      g.restore();
    }
    g.beginPath(); g.arc(0, 0, 88, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#100c0a'; g.beginPath(); g.arc(0, 0, 70, 0, Math.PI * 2); g.fill();
  } else if (kind === 'road') {
    // a pilgrim's staff crossed over a winding road
    g.lineWidth = 22;
    g.beginPath(); g.moveTo(-120, 150); g.bezierCurveTo(-40, 40, 60, 80, 20, -40); g.bezierCurveTo(0, -100, 60, -130, 80, -170); g.stroke();
    g.lineWidth = 14;
    g.beginPath(); g.moveTo(-90, -150); g.lineTo(100, 150); g.stroke();
    g.beginPath(); g.arc(-96, -160, 20, 0, Math.PI * 2); g.stroke();
  } else if (kind === 'bell') {
    g.beginPath();
    g.moveTo(0, -160); g.bezierCurveTo(70, -160, 80, -60, 90, 40); g.lineTo(120, 90); g.lineTo(-120, 90); g.lineTo(-90, 40);
    g.bezierCurveTo(-80, -60, -70, -160, 0, -160); g.fill();
    g.beginPath(); g.arc(0, 118, 24, 0, Math.PI * 2); g.fill();
    g.fillStyle = field; g.fillRect(-70, 20, 140, 14);
  } else if (kind === 'skull') {
    g.beginPath(); g.ellipse(0, -40, 100, 110, 0, 0, Math.PI * 2); g.fill();
    g.fillRect(-56, 40, 112, 70);
    g.fillStyle = field;
    g.beginPath(); g.ellipse(-40, -30, 28, 34, 0.2, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.ellipse(40, -30, 28, 34, -0.2, 0, Math.PI * 2); g.fill();
    g.beginPath(); g.moveTo(0, 10); g.lineTo(-14, 40); g.lineTo(14, 40); g.fill();
    for (let i = -2; i <= 2; i++) g.fillRect(i * 22 - 4, 70, 8, 40);
  }
  g.restore();
  // border
  g.lineWidth = 26; g.strokeStyle = trim; g.globalAlpha = 0.9;
  g.strokeRect(13, 13, S - 26, S - 26);
  g.globalAlpha = 1;
  // scratches & wear
  const id = g.getImageData(0, 0, S, S), d = id.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const u = x / S, v = y / S, i = (y * S + x) * 4;
    const wear = fbm(u, v, 6, 5, 201);
    const chip = wear > 0.66 ? 0.35 : 1;
    const scr = Math.abs(Math.sin((u * 0.6 - v) * 220 + fbm(u, v, 4, 2, 203) * 30)) > 0.992 ? 1.4 : 1;
    const k = (0.75 + wear * 0.4) * chip * scr;
    d[i] = clamp255(d[i] * k + (chip < 1 ? 30 : 0)); d[i + 1] = clamp255(d[i + 1] * k + (chip < 1 ? 28 : 0)); d[i + 2] = clamp255(d[i + 2] * k + (chip < 1 ? 26 : 0));
  }
  g.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

// ---------------------------------------------------------------- sprites

export function softSprite() {
  const S = 128, c = canvas(S), g = c.getContext('2d');
  const gr = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.55)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, S, S);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function smokeSprite() {
  const S = 128, c = canvas(S), g = c.getContext('2d');
  const id = g.createImageData(S, S), d = id.data;
  for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
    const u = x / S, v = y / S, dx = u - 0.5, dy = v - 0.5;
    const r = Math.sqrt(dx * dx + dy * dy) * 2;
    const n = fbm(u, v, 4, 5, 301);
    const a = Math.max(0, 1 - r * (1.1 + (0.5 - n) * 0.9));
    const i = (y * S + x) * 4;
    d[i] = d[i + 1] = d[i + 2] = 200 + n * 55; d[i + 3] = clamp255(Math.pow(a, 1.4) * 255);
  }
  g.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}

export function noiseTexture(size = 256) {
  const c = canvas(size), g = c.getContext('2d'), id = g.createImageData(size, size), d = id.data;
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const u = x / size, v = y / size, i = (y * size + x) * 4;
    d[i] = fbm(u, v, 4, 5, 401) * 255; d[i + 1] = fbm(u, v, 8, 4, 403) * 255; d[i + 2] = fbm(u, v, 2, 4, 405) * 255; d[i + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.NoColorSpace; return t;
}
