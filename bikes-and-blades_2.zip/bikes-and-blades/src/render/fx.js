// GPU particle systems, weapon trails, debris physics, impact lights.
import * as THREE from 'three';
import { getMaps } from './materials.js';

// ---------------------------------------------------------------- particles
// One instanced quad per particle; motion is evaluated analytically in the
// vertex shader from birth time, so the CPU only writes on spawn.
const PART_VS = `
attribute vec3 aPos; attribute vec3 aVel; attribute vec4 aCol; attribute vec4 aMisc; // misc: birth, life, size, grow
attribute vec2 aSpin; // rotation, drag
uniform float uTime; uniform float uGravity; uniform float uStreak;
varying vec4 vCol; varying vec2 vUv; varying float vAge;
void main(){
  float age = (uTime - aMisc.x) / aMisc.y;
  vAge = age;
  vUv = uv;
  if (age < 0.0 || age > 1.0) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); return; }
  float t = uTime - aMisc.x;
  float k = max(aSpin.y, 0.0001);
  float dr = (1.0 - exp(-k * t)) / k;
  vec3 p = aPos + aVel * dr + vec3(0.0, -0.5 * uGravity * t * t, 0.0);
  vec3 vel = aVel * exp(-k * t) + vec3(0.0, -uGravity * t, 0.0);
  float size = aMisc.z * (1.0 + aMisc.w * age);
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  if (uStreak > 0.5) {
    vec3 vv = (modelViewMatrix * vec4(vel, 0.0)).xyz;
    float sp = length(vv.xy) + 0.0001;
    vec2 dir = vv.xy / sp;
    vec2 nrm = vec2(-dir.y, dir.x);
    float len = clamp(sp * 0.035, 0.05, 1.2) * (1.0 - age * 0.5);
    mv.xy += dir * (position.y) * len + nrm * position.x * size;
  } else {
    float a = aSpin.x + t * aSpin.x * 0.6;
    mat2 R = mat2(cos(a), -sin(a), sin(a), cos(a));
    mv.xy += R * position.xy * size;
  }
  gl_Position = projectionMatrix * mv;
  vCol = aCol;
  vCol.a *= smoothstep(0.8, 2.6, -mv.z);
}`;
const PART_FS = `
uniform sampler2D uMap; uniform float uStreak; uniform float uSoft;
varying vec4 vCol; varying vec2 vUv; varying float vAge;
void main(){
  float a;
  if (uStreak > 0.5) {
    float d = abs(vUv.x - 0.5) * 2.0;
    a = (1.0 - d * d) * smoothstep(0.0, 0.35, vUv.y);
  } else {
    a = texture2D(uMap, vUv).a;
  }
  float fade = uSoft > 0.5 ? smoothstep(0.0, 0.12, vAge) * (1.0 - smoothstep(0.45, 1.0, vAge)) : (1.0 - vAge * vAge);
  gl_FragColor = vec4(vCol.rgb, vCol.a * a * fade);
  if (gl_FragColor.a < 0.003) discard;
}`;

export class ParticleSystem {
  constructor(scene, { capacity = 2000, streak = false, additive = true, soft = false, gravity = 9, map = null } = {}) {
    this.cap = capacity; this.head = 0;
    const base = new THREE.PlaneGeometry(1, 1);
    if (streak) base.translate(0, -0.5, 0);
    const g = new THREE.InstancedBufferGeometry();
    g.index = base.index; g.attributes.position = base.attributes.position; g.attributes.uv = base.attributes.uv;
    const mk = (n) => { const a = new THREE.InstancedBufferAttribute(new Float32Array(capacity * n), n); a.setUsage(THREE.DynamicDrawUsage); return a; };
    this.aPos = mk(3); this.aVel = mk(3); this.aCol = mk(4); this.aMisc = mk(4); this.aSpin = mk(2);
    for (let i = 0; i < capacity; i++) this.aMisc.array[i * 4] = -999;
    g.setAttribute('aPos', this.aPos); g.setAttribute('aVel', this.aVel); g.setAttribute('aCol', this.aCol);
    g.setAttribute('aMisc', this.aMisc); g.setAttribute('aSpin', this.aSpin);
    g.instanceCount = capacity;
    this.mat = new THREE.ShaderMaterial({
      vertexShader: PART_VS, fragmentShader: PART_FS, transparent: true, depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { uTime: { value: 0 }, uGravity: { value: gravity }, uStreak: { value: streak ? 1 : 0 }, uSoft: { value: soft ? 1 : 0 }, uMap: { value: map || getMaps().soft } },
    });
    this.mesh = new THREE.Mesh(g, this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = additive ? 20 : 10;
    scene.add(this.mesh);
    this.time = 0;
    this.dirty = false;
  }
  spawn(p, v, color, life, size, { grow = 0, alpha = 1, rot = 0, drag = 0 } = {}) {
    const i = this.head; this.head = (this.head + 1) % this.cap;
    this.aPos.array.set([p.x, p.y, p.z], i * 3);
    this.aVel.array.set([v.x, v.y, v.z], i * 3);
    this.aCol.array.set([color.r, color.g, color.b, alpha], i * 4);
    this.aMisc.array.set([this.time, life, size, grow], i * 4);
    this.aSpin.array.set([rot, drag], i * 2);
    this.dirty = true;
  }
  update(dt) {
    this.time += dt;
    this.mat.uniforms.uTime.value = this.time;
    if (this.dirty) {
      for (const a of [this.aPos, this.aVel, this.aCol, this.aMisc, this.aSpin]) a.needsUpdate = true;
      this.dirty = false;
    }
  }
}

// ---------------------------------------------------------------- trails
export class Trail {
  constructor(scene, color = new THREE.Color(1, 0.6, 0.3), length = 14) {
    this.n = length;
    this.base = []; this.tip = []; this.age = [];
    const pos = new Float32Array(this.n * 2 * 3), uv = new Float32Array(this.n * 2 * 2), idx = [];
    for (let i = 0; i < this.n - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    for (let i = 0; i < this.n; i++) { uv.set([i / (this.n - 1), 0, i / (this.n - 1), 1], i * 4); }
    this.geo = new THREE.BufferGeometry();
    this.geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    this.geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
    this.geo.setIndex(idx);
    this.mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { uColor: { value: color }, uAlpha: { value: 0 } },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
      fragmentShader: `uniform vec3 uColor; uniform float uAlpha; varying vec2 vUv;
        void main(){ float a = pow(1.0 - vUv.x, 1.6) * smoothstep(0.0, 0.7, vUv.y) * uAlpha;
        vec3 c = mix(uColor, vec3(1.0, 0.95, 0.85), pow(vUv.y, 6.0) * (1.0 - vUv.x));
        gl_FragColor = vec4(c * 1.6, a); }`,
    });
    this.mesh = new THREE.Mesh(this.geo, this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 25;
    scene.add(this.mesh);
    this.alpha = 0; this.target = 0;
  }
  // Points are in the space of whatever the trail mesh is parented to (the rider),
  // and samples expire by age so the arc length is frame-rate independent.
  push(baseW, tipW, now, maxAge = 0.13) {
    this.base.unshift(baseW.clone()); this.tip.unshift(tipW.clone()); this.age.unshift(now);
    while (this.base.length > 2 && (this.base.length > this.n || now - this.age[this.age.length - 1] > maxAge)) { this.base.pop(); this.tip.pop(); this.age.pop(); }
    const p = this.geo.attributes.position.array;
    for (let i = 0; i < this.n; i++) {
      const b = this.base[Math.min(i, this.base.length - 1)], t = this.tip[Math.min(i, this.tip.length - 1)];
      p.set([b.x, b.y, b.z, t.x, t.y, t.z], i * 6);
    }
    this.geo.attributes.position.needsUpdate = true;
  }
  update(dt) {
    this.alpha += (this.target - this.alpha) * Math.min(1, dt * (this.target > this.alpha ? 30 : 8));
    this.mat.uniforms.uAlpha.value = this.alpha;
    this.mesh.visible = this.alpha > 0.01;
  }
}

// ---------------------------------------------------------------- debris
export class Debris {
  constructor(scene) { this.scene = scene; this.list = []; }
  add(obj, vel, ang, life = 6, ground = 0.02) {
    // obj must already be in world space
    this.scene.add(obj);
    this.list.push({ obj, vel: vel.clone(), ang: ang.clone(), life, t: 0, ground, rest: false });
  }
  update(dt) {
    for (const d of this.list) {
      d.t += dt;
      if (!d.rest) {
        d.vel.y -= 14 * dt;
        d.obj.position.addScaledVector(d.vel, dt);
        d.obj.rotation.x += d.ang.x * dt; d.obj.rotation.y += d.ang.y * dt; d.obj.rotation.z += d.ang.z * dt;
        if (d.obj.position.y < d.ground) {
          d.obj.position.y = d.ground;
          d.vel.y *= -0.35; d.vel.x *= 0.6; d.vel.z *= 0.6; d.ang.multiplyScalar(0.55);
          if (Math.abs(d.vel.y) < 0.6) { d.vel.y = 0; if (d.vel.length() < 0.3) d.rest = true; }
          d.onBounce && d.onBounce(d);
        }
        if (Math.abs(d.obj.position.z) > 7 && d.obj.position.y < 1) d.ground = -40; // fell off the bridge
      }
      if (d.t > d.life) {
        const s = Math.max(0, 1 - (d.t - d.life) / 0.6);
        d.obj.scale.setScalar(s);
        if (s <= 0) { this.scene.remove(d.obj); d.dead = true; }
      }
    }
    this.list = this.list.filter(d => !d.dead);
  }
  clear() { for (const d of this.list) this.scene.remove(d.obj); this.list = []; }
}

// ---------------------------------------------------------------- shockwave rings
export class Rings {
  constructor(scene) {
    this.scene = scene; this.list = [];
    this.geo = new THREE.RingGeometry(0.86, 1, 64);
  }
  spawn(pos, color, size = 2.5, life = 0.35, normal = new THREE.Vector3(0, 0, 1)) {
    const mat = new THREE.MeshBasicMaterial({ color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const m = new THREE.Mesh(this.geo, mat);
    m.position.copy(pos);
    m.lookAt(pos.clone().add(normal));
    m.renderOrder = 30;
    this.scene.add(m);
    this.list.push({ m, t: 0, life, size });
  }
  update(dt) {
    for (const r of this.list) {
      r.t += dt;
      const k = r.t / r.life;
      const e = 1 - Math.pow(1 - k, 3);
      r.m.scale.setScalar(0.1 + e * r.size);
      r.m.material.opacity = Math.max(0, 1 - k) * 1.4;
      if (k >= 1) { this.scene.remove(r.m); r.m.material.dispose(); r.dead = true; }
    }
    this.list = this.list.filter(r => !r.dead);
  }
}

// ---------------------------------------------------------------- impact lights
export class FlashLights {
  constructor(scene, n = 3) {
    this.lights = [];
    for (let i = 0; i < n; i++) {
      const l = new THREE.PointLight(0xffaa66, 0, 9, 2);
      l.userData.t = 1; l.userData.life = 1; l.userData.peak = 0;
      scene.add(l); this.lights.push(l);
    }
    this.i = 0;
  }
  flash(pos, color, intensity = 40, life = 0.25, dist = 9) {
    const l = this.lights[this.i]; this.i = (this.i + 1) % this.lights.length;
    l.position.copy(pos); l.color.set(color); l.distance = dist;
    l.userData.t = 0; l.userData.life = life; l.userData.peak = intensity * 0.45;
  }
  update(dt) {
    for (const l of this.lights) {
      l.userData.t += dt;
      const k = Math.min(1, l.userData.t / l.userData.life);
      l.intensity = l.userData.peak * Math.pow(1 - k, 2);
    }
  }
}

// ---------------------------------------------------------------- facade
export class FX {
  constructor(scene) {
    const maps = getMaps();
    this.scene = scene;
    this.sparks = new ParticleSystem(scene, { capacity: 2500, streak: true, additive: true, gravity: 11 });
    this.glow = new ParticleSystem(scene, { capacity: 800, additive: true, gravity: 0, soft: true, map: maps.soft });
    this.smoke = new ParticleSystem(scene, { capacity: 1600, additive: false, gravity: -0.6, soft: true, map: maps.smoke });
    this.embers = new ParticleSystem(scene, { capacity: 1200, additive: true, gravity: -0.7, soft: true, map: maps.soft });
    this.debris = new Debris(scene);
    this.rings = new Rings(scene);
    this.lights = new FlashLights(scene, 4);
    this.sigils = null; this.pillars = null; // created lazily (classes are defined below)
    this.tmpV = new THREE.Vector3(); this.tmpP = new THREE.Vector3();
    this.c = new THREE.Color();
  }
  update(dt) {
    this.sparks.update(dt); this.glow.update(dt); this.smoke.update(dt); this.embers.update(dt);
    this.debris.update(dt); this.rings.update(dt); this.lights.update(dt);
    if (!this.sigils) { this.sigils = new Sigils(this.scene); this.pillars = new Pillars(this.scene); }
    this.sigils.update(dt); this.pillars.update(dt);
  }

  burstSparks(pos, n, speed, color = 0xffb060, spread = 1, dirBias = null, life = 0.5) {
    const c = this.c.set(color);
    for (let i = 0; i < n; i++) {
      const v = this.tmpV.set(Math.random() - 0.5, Math.random() * 0.9 - 0.2, Math.random() - 0.5).normalize().multiplyScalar(speed * (0.35 + Math.random()));
      if (dirBias) v.addScaledVector(dirBias, speed * 0.6);
      v.multiplyScalar(spread);
      this.sparks.spawn(pos, v, c, life * (0.5 + Math.random()), 0.018 + Math.random() * 0.02, { drag: 1.2 });
    }
  }
  flare(pos, color, size, life = 0.18, alpha = 1) {
    this.glow.spawn(pos, this.tmpV.set(0, 0, 0), this.c.set(color), life, size, { grow: 0.6, alpha });
  }
  puff(pos, vel, color, size, life, alpha = 0.6, grow = 2.5, drag = 2) {
    this.smoke.spawn(pos, vel, this.c.set(color), life, size, { grow, alpha, rot: (Math.random() - 0.5) * 2, drag });
  }
  ember(pos, vel, color, size, life) {
    this.embers.spawn(pos, vel, this.c.set(color), life, size, { drag: 0.4, grow: -0.5 });
  }
}

// ---------------------------------------------------------------- ritual sigils
// Spinning, expanding circles of runes and spokes: the "miracle" language of
// the Reliquary look (parries, clashes, perfect shifts, KOs).
function sigilTexture() {
  const S = 256, c = document.createElement('canvas'); c.width = c.height = S;
  const g = c.getContext('2d'); g.translate(S / 2, S / 2);
  g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.lineCap = 'round';
  g.lineWidth = 6; g.beginPath(); g.arc(0, 0, 118, 0, Math.PI * 2); g.stroke();
  g.lineWidth = 3; g.beginPath(); g.arc(0, 0, 100, 0, Math.PI * 2); g.stroke();
  g.beginPath(); g.arc(0, 0, 46, 0, Math.PI * 2); g.stroke();
  for (let i = 0; i < 12; i++) {
    const a = i / 12 * Math.PI * 2;
    g.lineWidth = 3; g.beginPath(); g.moveTo(Math.cos(a) * 46, Math.sin(a) * 46); g.lineTo(Math.cos(a) * 100, Math.sin(a) * 100); g.stroke();
    // a glyph between rings: little crossed strokes
    g.save(); g.rotate(a + Math.PI / 12); g.translate(0, -109); g.lineWidth = 2.5;
    g.beginPath(); g.moveTo(-5, -5); g.lineTo(5, 5); g.moveTo(5, -5); g.lineTo(0, 0); g.moveTo(0, -7); g.lineTo(0, 7); g.stroke();
    g.restore();
  }
  g.beginPath(); g.arc(0, 0, 12, 0, Math.PI * 2); g.fill();
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t;
}
export class Sigils {
  constructor(scene) { this.scene = scene; this.list = []; this.tex = sigilTexture(); this.geo = new THREE.PlaneGeometry(1, 1); }
  spawn(pos, color, size = 2.5, life = 0.6, { normal = new THREE.Vector3(0, 0, 1), spin = 2.5, intensity = 2.2 } = {}) {
    const mat = new THREE.MeshBasicMaterial({ map: this.tex, color: new THREE.Color(color).multiplyScalar(intensity), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide });
    const mesh = new THREE.Mesh(this.geo, mat);
    mesh.position.copy(pos); mesh.lookAt(pos.clone().add(normal)); mesh.renderOrder = 31;
    this.scene.add(mesh);
    this.list.push({ mesh, t: 0, life, size, spin });
  }
  update(dt) {
    for (const s of this.list) {
      s.t += dt; const k = s.t / s.life;
      const e = 1 - Math.pow(1 - Math.min(1, k), 3);
      s.mesh.scale.setScalar(0.3 * s.size + e * s.size);
      s.mesh.rotateZ(s.spin * dt);
      s.mesh.material.opacity = Math.max(0, 1 - k * k);
      if (k >= 1) { this.scene.remove(s.mesh); s.mesh.material.dispose(); s.dead = true; }
    }
    this.list = this.list.filter(s => !s.dead);
  }
}

// A column of light falling on the fallen.
export class Pillars {
  constructor(scene) {
    this.scene = scene; this.list = [];
    const g = new THREE.CylinderGeometry(0.9, 1.4, 30, 24, 1, true); g.translate(0, 15, 0);
    this.geo = g;
  }
  spawn(pos, color = 0xeee4cf, life = 3.2) {
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { uColor: { value: new THREE.Color(color) }, uA: { value: 0 } },
      vertexShader: 'varying vec2 vUv; varying vec3 vN; varying vec3 vV; void main(){ vUv = uv; vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }',
      fragmentShader: 'uniform vec3 uColor; uniform float uA; varying vec2 vUv; varying vec3 vN; varying vec3 vV; void main(){ float edge = pow(abs(dot(vN, vV)), 2.0); float fall = smoothstep(0.0, 0.08, vUv.y) * (1.0 - vUv.y * 0.85); gl_FragColor = vec4(uColor * 1.6 * edge * fall * uA, 1.0); }',
    });
    const m = new THREE.Mesh(this.geo, mat); m.position.copy(pos); m.renderOrder = 18;
    this.scene.add(m); this.list.push({ m, t: 0, life });
  }
  update(dt) {
    for (const p of this.list) {
      p.t += dt; const k = p.t / p.life;
      p.m.material.uniforms.uA.value = Math.min(1, p.t * 3) * Math.max(0, 1 - k * k);
      p.m.scale.x = p.m.scale.z = 1 - k * 0.5;
      if (k >= 1) { this.scene.remove(p.m); p.m.material.dispose(); p.dead = true; }
    }
    this.list = this.list.filter(p => !p.dead);
  }
}
