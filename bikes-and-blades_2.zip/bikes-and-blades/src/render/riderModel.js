// Procedural chibi knight + armoured motorbike, with a spring/IK animation rig.
// Local space of the bike: +x forward, +y up, +z = weapon side (toward the tilt barrier).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { riderKit, addOutlines, shadowAll, getMaps, mergeTree } from './materials.js';
import { emblemTexture } from './textures.js';
import { RIDER, ARENA, turnEase } from '../core/data.js';

const V = (x, y, z) => new THREE.Vector3(x, y, z);
const UP = V(0, 1, 0);

function mesh(geo, mat, parent, pos, rot, scl) {
  const m = new THREE.Mesh(geo, mat);
  if (pos) m.position.set(pos[0], pos[1], pos[2]);
  if (rot) m.rotation.set(rot[0], rot[1], rot[2]);
  if (scl) (typeof scl === 'number') ? m.scale.setScalar(scl) : m.scale.set(scl[0], scl[1], scl[2]);
  if (parent) parent.add(m);
  return m;
}
const rbox = (w, h, d, r = 0.03, s = 2) => new RoundedBoxGeometry(w, h, d, s, Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001));
const lathe = (pts, seg = 24) => new THREE.LatheGeometry(pts.map(p => new THREE.Vector2(p[0], p[1])), seg);

// Cylinder between two points (static).
function strut(a, b, r, mat, parent, seg = 10) {
  const d = b.clone().sub(a), len = d.length();
  const m = mesh(new THREE.CylinderGeometry(r, r, len, seg), mat, parent);
  m.position.copy(a).addScaledVector(d, 0.5);
  m.quaternion.setFromUnitVectors(UP, d.normalize());
  return m;
}
function tube(points, r, mat, parent, seg = 24) {
  const curve = new THREE.CatmullRomCurve3(points.map(p => V(...p)));
  return mesh(new THREE.TubeGeometry(curve, seg, r, 8, false), mat, parent);
}

// Critically-under-damped spring for snappy, slightly overshooting motion.
class Spring3 {
  constructor(v, k = 260, zeta = 0.62) { this.v = v.clone(); this.vel = V(0, 0, 0); this.k = k; this.c = 2 * zeta * Math.sqrt(k); }
  update(target, dt, kMul = 1) {
    const k = this.k * kMul, c = this.c * Math.sqrt(kMul);
    const steps = Math.ceil(dt / (1 / 120));
    const h = dt / steps;
    for (let i = 0; i < steps; i++) {
      this.vel.x += (k * (target.x - this.v.x) - c * this.vel.x) * h;
      this.vel.y += (k * (target.y - this.v.y) - c * this.vel.y) * h;
      this.vel.z += (k * (target.z - this.v.z) - c * this.vel.z) * h;
      this.v.addScaledVector(this.vel, h);
    }
    return this.v;
  }
  snap(v) { this.v.copy(v); this.vel.set(0, 0, 0); }
}
class Spring1 {
  constructor(v = 0, k = 120, zeta = 0.5) { this.v = v; this.vel = 0; this.k = k; this.c = 2 * zeta * Math.sqrt(k); }
  update(t, dt) {
    const steps = Math.ceil(dt / (1 / 120)), h = dt / steps;
    for (let i = 0; i < steps; i++) { this.vel += (this.k * (t - this.v) - this.c * this.vel) * h; this.v += this.vel * h; }
    return this.v;
  }
}

// ---------------------------------------------------------------- poses
// Hand target (bike-local), blade direction, torso lean/twist — per strike line.
const ZP = {
  ride: { h: [0.2, 1.45, 0.5], d: [0.8, -0.2, 0.42], lean: 0.12, twist: 0 },
  staggered: { h: [-0.1, 1.95, 0.75], d: [-0.4, 0.8, 0.5], lean: -0.45, twist: -0.2 },
  windup: {
    horiz: { h: [-0.36, 1.72, 0.55], d: [-0.92, 0.12, 0.3], lean: 0.0, twist: -0.6 },
    diag:  { h: [-0.24, 2.25, 0.45], d: [-0.5, 0.82, 0.2], lean: -0.08, twist: -0.5 },
    over:  { h: [0.0, 2.45, 0.32], d: [-0.25, 0.97, 0.0], lean: -0.15, twist: -0.1 },
    low:   { h: [-0.38, 1.04, 0.6], d: [-0.6, -0.76, 0.2], lean: 0.05, twist: -0.45 },
    back:  { h: [0.45, 1.72, 0.55], d: [0.9, 0.22, 0.3], lean: 0.12, twist: 0.5 },
  },
  active: {
    horiz: { h: [0.56, 1.72, 0.6], d: [0.92, 0.04, 0.38], lean: 0.32, twist: 0.55 },
    diag:  { h: [0.56, 1.45, 0.6], d: [0.74, -0.62, 0.28], lean: 0.42, twist: 0.5 },
    over:  { h: [0.5, 1.62, 0.45], d: [0.52, -0.82, 0.22], lean: 0.5, twist: 0.2 },
    low:   { h: [0.55, 1.0, 0.65], d: [0.85, -0.45, 0.35], lean: 0.5, twist: 0.45 },
    back:  { h: [-0.5, 1.62, 0.55], d: [-0.96, 0.0, 0.28], lean: -0.15, twist: -0.75 },
  },
};
// Shield positions (hand target + face normal), one per guard zone.
const ZS = {
  ride:  { h: [0.48, 1.36, -0.3], f: [0.1, 0.0, -1.0] },
  over:  { h: [0.22, 2.28, 0.25], f: [0.25, 0.94, 0.25] },
  diag:  { h: [0.42, 2.0, 0.38],  f: [0.55, 0.45, 0.7] },
  horiz: { h: [0.42, 1.62, 0.42], f: [0.45, 0.0, 0.9] },
  low:   { h: [0.36, 1.05, 0.5],  f: [0.5, -0.3, 0.8] },
  back:  { h: [-0.5, 1.62, 0.36], f: [-0.85, 0.1, 0.5] },
};
const GRIP = V(0.5, 1.38, 0.44);              // right handlebar grip (throttle)
const SCAB = { p: V(-0.18, 1.02, 0.36), d: V(-0.82, -0.5, 0.1).normalize() }; // sword in its scabbard

// ---------------------------------------------------------------- the view
export class RiderView {
  constructor(scene, fx, riderDef, weaponId, index) {
    this.scene = scene; this.fx = fx; this.def = riderDef; this.weaponId = weaponId === 'lance' ? 'lance' : 'sword'; this.i = index;
    this.kit = riderKit(riderDef, index === 1 ? { color: 0xf08a4e, strength: 1.0 } : { color: 0xeee4cf, strength: 0.85 });
    this.flash = 0;
    this.wheelAngle = 0;
    this.t = 0;
    this.prevV = 0;
    this.build();
    this.resetRound();
  }

  // -------------------------------------------------------------- build
  build() {
    const K = this.kit;
    this.root = new THREE.Group();     // world position + facing
    this.flip = new THREE.Group();     // mirror so the weapon faces the barrier
    this.bike = new THREE.Group();     // pitch / bounce / lean
    this.root.add(this.flip); this.flip.add(this.bike);
    this.scene.add(this.root);

    this.buildBike(K);
    this.rider = new THREE.Group();
    this.bike.add(this.rider);
    this.rider.scale.setScalar(1.06);
    this.buildRider(K);
    this.buildWeapon(K);
    this.buildShield(K);

    mergeTree(this.bike);
    addOutlines(this.bike, 0.038); // a heavy ink line, ~1.5 px at the pixel-art internal resolution
    shadowAll(this.bike, true, true);
    this.buildCape(K);
    this.buildLights();
  }

  buildBike(K) {
    const b = this.bike;
    const m = getMaps();
    // wheels
    this.wheels = [];
    for (const [x, big] of [[-0.8, 1], [0.84, 0.94]]) {
      const w = new THREE.Group(); w.position.set(x, 0.43 * big, 0); b.add(w);
      const tireGeo = new THREE.TorusGeometry(0.31 * big, 0.12 * big, 14, 40);
      mesh(tireGeo, K.tire, w);
      mesh(new THREE.CylinderGeometry(0.24 * big, 0.24 * big, 0.06, 28), K.darkMetal, w, [0, 0, 0], [Math.PI / 2, 0, 0]);
      mesh(new THREE.CylinderGeometry(0.09, 0.09, 0.2, 12), K.trim, w, [0, 0, 0], [Math.PI / 2, 0, 0]);
      for (let i = 0; i < 5; i++) {
        const a = i / 5 * Math.PI * 2;
        const sp = mesh(rbox(0.05, 0.2 * big, 0.08, 0.015), K.metal, w, [Math.cos(a) * 0.13 * big, Math.sin(a) * 0.13 * big, 0], [0, 0, a + Math.PI / 2]);
      }
      // studs on the tyre wall
      for (let i = 0; i < 10; i++) {
        const a = i / 10 * Math.PI * 2;
        mesh(new THREE.ConeGeometry(0.03, 0.07, 6), K.trim, w, [Math.cos(a) * 0.31 * big, Math.sin(a) * 0.31 * big, 0.12], [Math.PI / 2, 0, 0]);
      }
      w.userData.r = 0.43 * big;
      this.wheels.push(w);
    }
    // frame
    const frame = K.darkMetal;
    strut(V(-0.8, 0.43, 0.13), V(-0.05, 0.62, 0.12), 0.04, frame, b);
    strut(V(-0.8, 0.43, -0.13), V(-0.05, 0.62, -0.12), 0.04, frame, b);
    strut(V(0.52, 1.22, 0), V(-0.05, 0.62, 0), 0.05, frame, b);
    strut(V(0.52, 1.22, 0), V(-0.5, 0.98, 0), 0.04, frame, b);
    strut(V(-0.5, 0.98, 0), V(-0.8, 0.43, 0), 0.035, frame, b);
    // forks
    for (const z of [0.15, -0.15]) {
      strut(V(0.56, 1.3, z), V(0.84, 0.42, z), 0.045, K.metal, b);
      mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.22, 10), K.trim, b, [0.62, 1.1, z], [0, 0, -0.31]);
    }
    // engine block + V-twin cylinders with cooling fins
    mesh(rbox(0.62, 0.38, 0.36, 0.07), K.darkMetal, b, [0.02, 0.58, 0]);
    this.engineGroup = new THREE.Group(); this.engineGroup.position.set(0.02, 0.72, 0); b.add(this.engineGroup);
    for (const [ang, ox] of [[0.5, 0.12], [-0.5, -0.12]]) {
      const cyl = new THREE.Group(); cyl.position.set(ox, 0.05, 0); cyl.rotation.z = -ang; this.engineGroup.add(cyl);
      for (let i = 0; i < 5; i++) mesh(new THREE.CylinderGeometry(0.13 - i * 0.004, 0.13 - i * 0.004, 0.025, 16), K.metal, cyl, [0, 0.04 + i * 0.05, 0]);
      mesh(new THREE.CylinderGeometry(0.1, 0.11, 0.3, 14), K.darkMetal, cyl, [0, 0.14, 0]);
      mesh(rbox(0.16, 0.06, 0.16, 0.02), K.trim, cyl, [0, 0.3, 0]);
    }
    mesh(new THREE.CylinderGeometry(0.16, 0.16, 0.1, 20), K.trim, b, [0.05, 0.56, 0.2], [Math.PI / 2, 0, 0]);
    // exhausts
    this.exhaustTips = [];
    for (const z of [0.22, -0.22]) {
      tube([[0.18, 0.6, z * 0.6], [0.0, 0.42, z], [-0.5, 0.45, z * 1.15], [-1.05, 0.66, z * 1.2]], 0.05, K.metal, b);
      const tip = mesh(new THREE.CylinderGeometry(0.1, 0.06, 0.26, 14, 1, true), K.darkMetal, b, [-1.12, 0.69, z * 1.2], [0, 0, Math.PI / 2 + 0.35]);
      tip.material = K.darkMetal;
      const anchor = new THREE.Object3D(); anchor.position.set(-1.26, 0.74, z * 1.2); b.add(anchor);
      this.exhaustTips.push(anchor);
    }
    // tank (painted, worn) with a trim stripe and filler cap
    mesh(new THREE.SphereGeometry(0.3, 24, 16), K.paint, b, [0.18, 1.08, 0], [0, 0, -0.12], [1.55, 0.72, 0.95]);
    mesh(new THREE.TorusGeometry(0.28, 0.018, 6, 30, Math.PI), K.trim, b, [0.18, 1.08, 0], [0, 0, -0.12], [1.55, 0.95, 1.0]);
    mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.05, 12), K.trim, b, [0.22, 1.3, 0]);
    // seat
    mesh(rbox(0.6, 0.12, 0.32, 0.05), K.leather, b, [-0.36, 1.0, 0], [0, 0, 0.06]);
    mesh(rbox(0.12, 0.2, 0.3, 0.04), K.leather, b, [-0.68, 1.1, 0], [0, 0, 0.2]);
    // rear fender with spikes
    const fender = mesh(new THREE.TorusGeometry(0.47, 0.1, 6, 20, Math.PI * 0.8), K.paint, b, [-0.8, 0.43, 0], [0, 0, Math.PI * 0.12], [1, 1, 1.9]);
    for (let i = 0; i < 4; i++) {
      const a = Math.PI * (0.25 + i * 0.16);
      mesh(new THREE.ConeGeometry(0.035, 0.18, 6), K.metal, b, [-0.8 + Math.cos(a) * 0.55, 0.43 + Math.sin(a) * 0.55, 0], [0, 0, a - Math.PI / 2]);
    }
    // handlebars with horn grips
    tube([[0.52, 1.36, -0.42], [0.5, 1.32, -0.2], [0.56, 1.3, 0], [0.5, 1.32, 0.2], [0.52, 1.36, 0.42]], 0.028, K.metal, b, 20);
    for (const z of [0.44, -0.44]) mesh(new THREE.CylinderGeometry(0.04, 0.04, 0.14, 10), K.leather, b, [0.5, 1.37, z], [Math.PI / 2, 0, 0]);
    // headlight
    mesh(new THREE.CylinderGeometry(0.13, 0.15, 0.14, 20), K.darkMetal, b, [0.82, 1.16, 0], [0, 0, Math.PI / 2]);
    const lens = mesh(new THREE.CircleGeometry(0.11, 20), K.lamp, b, [0.9, 1.16, 0], [0, Math.PI / 2, 0]);
    lens.userData.noOutline = true;
    // skull ornament on the front fender
    const skull = new THREE.Group(); skull.position.set(0.98, 0.84, 0); b.add(skull);
    mesh(new THREE.SphereGeometry(0.085, 14, 10), K.bone, skull, [0, 0, 0], null, [1, 0.9, 0.85]);
    mesh(new THREE.SphereGeometry(0.025, 8, 6), K.void, skull, [0.07, 0.01, 0.03]);
    mesh(new THREE.SphereGeometry(0.025, 8, 6), K.void, skull, [0.07, 0.01, -0.03]);
    mesh(new THREE.TorusGeometry(0.52, 0.06, 6, 16, Math.PI * 0.5), K.paint, b, [0.84, 0.42, 0], [0, 0, Math.PI * 0.2], [1, 1, 2.4]);
    // tail lamp
    mesh(rbox(0.05, 0.06, 0.12, 0.02), K.tail, b, [-1.03, 1.0, 0]);

    // ---------------- breakable fairing: centre plate + two cheeks
    this.fairing = [];
    const plateShape = new THREE.Shape();
    plateShape.moveTo(-0.3, 0.32); plateShape.lineTo(0.3, 0.32); plateShape.quadraticCurveTo(0.32, -0.1, 0, -0.36); plateShape.quadraticCurveTo(-0.32, -0.1, -0.3, 0.32);
    const plateGeo = new THREE.ExtrudeGeometry(plateShape, { depth: 0.04, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02, bevelSegments: 2 });
    const centre = new THREE.Group(); centre.position.set(0.93, 1.04, 0); centre.rotation.set(0, Math.PI / 2, 0); b.add(centre);
    const cp = mesh(plateGeo, [K.paint, K.trim], centre, [0, 0, 0], [-0.35, 0, 0]);
    for (const [x, y] of [[-0.22, 0.24], [0.22, 0.24], [0, -0.24], [-0.18, -0.02], [0.18, -0.02]]) mesh(new THREE.SphereGeometry(0.025, 8, 6), K.trim, cp, [x, y, 0.06]);
    mesh(rbox(0.04, 0.5, 0.05, 0.01), K.trim, cp, [0, 0, 0.065]);
    const cheekGeo = rbox(0.5, 0.34, 0.04, 0.02);
    const cheekR = new THREE.Group(); cheekR.position.set(0.68, 0.9, 0.24); cheekR.rotation.set(0, 0.25, -0.3); b.add(cheekR);
    mesh(cheekGeo, K.paint, cheekR);
    for (let i = 0; i < 3; i++) mesh(new THREE.ConeGeometry(0.03, 0.12, 6), K.metal, cheekR, [-0.15 + i * 0.15, 0.1, 0.06], [Math.PI / 2, 0, 0]);
    const cheekL = new THREE.Group(); cheekL.position.set(0.68, 0.9, -0.24); cheekL.rotation.set(0, -0.25, -0.3); b.add(cheekL);
    mesh(cheekGeo, K.paint, cheekL);
    for (let i = 0; i < 3; i++) mesh(new THREE.ConeGeometry(0.03, 0.12, 6), K.metal, cheekL, [-0.15 + i * 0.15, 0.1, -0.06], [-Math.PI / 2, 0, 0]);
    // order of detachment: right cheek (weapon side), left cheek, centre
    this.fairing = [cheekR, cheekL, centre];
    this.fairingHome = this.fairing.map(g => ({ p: g.position.clone(), r: g.rotation.clone() }));

    // banner pole with the rider's colours
    strut(V(-0.92, 0.95, -0.1), V(-1.02, 2.5, -0.1), 0.02, K.darkMetal, b);
    mesh(new THREE.ConeGeometry(0.04, 0.16, 6), K.trim, b, [-1.03, 2.58, -0.1]);
    const banGeo = new THREE.PlaneGeometry(0.6, 0.85, 8, 8);
    banGeo.translate(-0.3, -0.42, 0);
    const banMat = this.kit.cape.clone();
    banMat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = this.bannerTime = { value: 0 };
      sh.uniforms.uSpeed = this.bannerSpeed = { value: 0 };
      sh.vertexShader = 'uniform float uTime; uniform float uSpeed;\n' + sh.vertexShader.replace('#include <begin_vertex>', `
        #include <begin_vertex>
        float f = -position.x / 0.6;
        float amp = 0.06 + uSpeed * 0.012;
        transformed.z += sin(f * 7.0 - uTime * (5.0 + uSpeed * 0.6) + position.y * 3.0) * amp * f;
        transformed.y += f * f * (0.05 + uSpeed * 0.012) - (1.0 - min(uSpeed, 16.0) / 16.0) * f * f * 0.35;
        transformed.x *= 1.0 - (1.0 - min(uSpeed, 16.0) / 16.0) * f * 0.25;`);
    };
    banMat.side = THREE.DoubleSide;
    this.banner = mesh(banGeo, banMat, b, [-1.0, 2.45, -0.1]);
    this.banner.userData.keep = true;
    this.banner.userData.noOutline = true;
  }

  buildRider(K) {
    const R = this.rider, D = this.def;
    this.hip = new THREE.Group(); this.hip.position.set(-0.32, 1.12, 0); R.add(this.hip);
    mesh(rbox(0.36, 0.22, 0.42, 0.08), K.leather, this.hip);
    mesh(new THREE.TorusGeometry(0.2, 0.035, 8, 24), K.trim, this.hip, [0, 0.1, 0], [Math.PI / 2, 0, 0], [1, 1.12, 1]);
    // legs (static on the pegs)
    this.legsSeat = new THREE.Group(); R.add(this.legsSeat);
    for (const z of [0.17, -0.17]) {
      const s = Math.sign(z);
      strut(V(-0.3, 1.08, z), V(0.12, 1.0, z + s * 0.08), 0.1, K.cloth, this.legsSeat);
      strut(V(0.12, 1.0, z + s * 0.08), V(0.05, 0.62, z + s * 0.12), 0.085, K.metal, this.legsSeat);
      mesh(new THREE.SphereGeometry(0.09, 12, 10), K.trim, this.legsSeat, [0.13, 1.0, z + s * 0.08]);
      mesh(rbox(0.26, 0.14, 0.15, 0.05), K.leather, this.legsSeat, [0.12, 0.56, z + s * 0.12]);
    }
    // walking legs, for the walk back to the bike after a fall (hip → knee → boot)
    this.legsWalk = new THREE.Group(); this.legsWalk.visible = false; R.add(this.legsWalk);
    this.walkLegs = [0.17, -0.17].map(z => {
      const hipJ = new THREE.Group(); hipJ.position.set(-0.3, 1.04, z); this.legsWalk.add(hipJ);
      mesh(new THREE.CapsuleGeometry(0.1, 0.22, 4, 10), K.cloth, hipJ, [0, -0.2, 0]);
      const knee = new THREE.Group(); knee.position.set(0, -0.4, 0); hipJ.add(knee);
      mesh(new THREE.SphereGeometry(0.09, 12, 10), K.trim, knee);
      mesh(new THREE.CapsuleGeometry(0.085, 0.2, 4, 10), K.metal, knee, [0, -0.18, 0]);
      mesh(rbox(0.26, 0.12, 0.15, 0.05), K.leather, knee, [0.05, -0.38, 0]);
      return { hipJ, knee };
    });
    // torso
    this.spine = new THREE.Group(); this.spine.position.set(0, 0.1, 0); this.hip.add(this.spine);
    const chest = mesh(new THREE.SphereGeometry(0.3, 24, 18), K.metal, this.spine, [0.02, 0.27, 0], null, [0.92, 1.0, 1.0]);
    mesh(new THREE.CylinderGeometry(0.22, 0.2, 0.18, 18), K.cloth, this.spine, [0, 0.06, 0]);
    mesh(new THREE.TorusGeometry(0.3, 0.025, 6, 28, Math.PI), K.trim, this.spine, [0.02, 0.3, 0], [0, -Math.PI / 2, 0], [1, 1.05, 1]);
    // tabard
    const tab = mesh(new THREE.PlaneGeometry(0.3, 0.42), K.cape, this.spine, [0.25, 0.0, 0], [0, Math.PI / 2, 0.15]);
    tab.userData.noOutline = true;
    // gorget
    mesh(new THREE.CylinderGeometry(0.15, 0.2, 0.1, 18), K.darkMetal, this.spine, [0.02, 0.55, 0]);
    // shoulders & pauldrons (oversized, chibi)
    this.shoulderR = new THREE.Object3D(); this.shoulderR.position.set(0.0, 0.42, 0.3); this.spine.add(this.shoulderR);
    this.shoulderL = new THREE.Object3D(); this.shoulderL.position.set(0.0, 0.42, -0.3); this.spine.add(this.shoulderL);
    for (const [z, s] of [[0.32, 1], [-0.32, -1]]) {
      const p = new THREE.Group(); p.position.set(0, 0.47, z); p.rotation.x = s * -0.35; this.spine.add(p);
      mesh(new THREE.SphereGeometry(0.19, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.55), K.metal, p, [0, 0, 0], null, [1.15, 0.9, 1.1]);
      mesh(new THREE.SphereGeometry(0.2, 18, 12, 0, Math.PI * 2, Math.PI * 0.42, Math.PI * 0.14), K.trim, p, [0, 0.02, 0], null, [1.16, 0.9, 1.1]);
      mesh(new THREE.SphereGeometry(0.17, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.5), K.metal, p, [0, -0.08, s * 0.04], null, [1.1, 0.8, 1.05]);
    }
    // arms (oriented every frame by IK)
    const mkArm = (shoulder) => {
      const upper = mesh(new THREE.CapsuleGeometry(0.1, 0.12, 4, 10), K.cloth, this.rider);
      const fore = mesh(new THREE.CapsuleGeometry(0.105, 0.1, 4, 10), K.metal, this.rider);
      const gaunt = mesh(new THREE.CylinderGeometry(0.135, 0.11, 0.13, 12), K.metal, fore, [0, -0.06, 0]);
      const hand = new THREE.Group(); this.rider.add(hand);
      mesh(new THREE.SphereGeometry(0.11, 12, 10), K.darkMetal, hand);
      const elbowCap = mesh(new THREE.SphereGeometry(0.11, 10, 8), K.trim, this.rider);
      return { shoulder, upper, fore, hand, elbowCap, la: 0.3, lb: 0.3 };
    };
    this.armR = mkArm(this.shoulderR);
    this.armL = mkArm(this.shoulderL);
    // head
    this.neck = new THREE.Group(); this.neck.position.set(0.03, 0.6, 0); this.spine.add(this.neck);
    this.head = new THREE.Group(); this.neck.add(this.head);
    this.head.scale.setScalar(1.38); // Pocket-Fighter proportions: the helm is half the rider
    this.helm = new THREE.Group(); this.head.add(this.helm);
    this.buildHelm(K, D.helm);
    // what's left when the helm is knocked away: a hollow, ember-eyed face
    this.bare = new THREE.Group(); this.head.add(this.bare); this.bare.visible = false;
    mesh(new THREE.SphereGeometry(0.22, 18, 14), K.leather, this.bare, [0, 0.24, 0], null, [1, 1.08, 0.95]);
    mesh(new THREE.SphereGeometry(0.2, 14, 10, 0, Math.PI * 2, 0, Math.PI * 0.45), K.cloth, this.bare, [-0.03, 0.27, 0], null, [1.05, 1.1, 1.0]);
    for (const z of [0.07, -0.07]) { const e = mesh(new THREE.SphereGeometry(0.03, 8, 6), K.eye, this.bare, [0.2, 0.26, z], null, [0.6, 0.8, 1.2]); e.userData.noOutline = true; }
  }

  buildHelm(K, kind) {
    const H = this.helm;
    const eyes = (y, x, sep, r = 0.03) => {
      for (const z of [sep, -sep]) {
        const e = mesh(new THREE.SphereGeometry(r, 8, 6), K.eye, H, [x, y, z], null, [0.6, 0.7, 1.4]);
        e.userData.noOutline = true;
      }
    };
    if (kind === 'great') {
      mesh(lathe([[0, 0], [0.27, 0], [0.3, 0.06], [0.31, 0.3], [0.3, 0.44], [0.24, 0.52], [0.12, 0.55], [0, 0.56]]), K.metal, H);
      mesh(rbox(0.06, 0.035, 0.42, 0.01), K.void, H, [0.29, 0.33, 0], null);
      mesh(rbox(0.04, 0.035, 0.42, 0.01), K.void, H, [0.285, 0.26, 0]).scale.set(1, 1, 0.08);
      eyes(0.33, 0.25, 0.09, 0.028);
      mesh(rbox(0.04, 0.42, 0.06, 0.01), K.trim, H, [0.305, 0.25, 0]);
      mesh(rbox(0.04, 0.04, 0.4, 0.01), K.trim, H, [0.305, 0.4, 0]);
      for (let i = 0; i < 5; i++) mesh(new THREE.CircleGeometry(0.012, 6), K.void, H, [0.305, 0.12 + (i % 2) * 0.04, 0.06 + i * 0.035], [0, Math.PI / 2, 0]);
      // crown of short spikes
      for (let i = 0; i < 7; i++) { const a = i / 7 * Math.PI * 2; mesh(new THREE.ConeGeometry(0.03, 0.1, 6), K.trim, H, [Math.cos(a) * 0.2, 0.58, Math.sin(a) * 0.2]); }
    } else if (kind === 'pilgrim') {
      mesh(lathe([[0, 0], [0.25, 0], [0.28, 0.08], [0.29, 0.32], [0.24, 0.42], [0, 0.44]]), K.metal, H);
      mesh(rbox(0.05, 0.05, 0.38, 0.015), K.void, H, [0.27, 0.27, 0]);
      eyes(0.27, 0.23, 0.08, 0.026);
      for (let i = 0; i < 6; i++) mesh(new THREE.CircleGeometry(0.014, 6), K.void, H, [0.285, 0.14, -0.1 + i * 0.04], [0, Math.PI / 2, 0]);
      // wide-brimmed pilgrim's hat, slightly bent
      const hat = new THREE.Group(); hat.position.set(-0.02, 0.4, 0); hat.rotation.z = 0.12; H.add(hat);
      mesh(new THREE.CylinderGeometry(0.56, 0.6, 0.035, 32), K.leather, hat);
      mesh(lathe([[0.3, 0], [0.27, 0.12], [0.2, 0.26], [0.08, 0.32], [0, 0.33]]), K.leather, hat);
      mesh(new THREE.TorusGeometry(0.29, 0.025, 6, 28), K.cloth, hat, [0, 0.03, 0], [Math.PI / 2, 0, 0]);
      mesh(new THREE.SphereGeometry(0.05, 10, 8), K.bone, hat, [0.1, 0.06, 0.29], null, [1, 1, 0.4]);
    } else if (kind === 'bell') {
      mesh(new THREE.SphereGeometry(0.3, 24, 18, 0, Math.PI * 2, 0, Math.PI * 0.62), K.metal, H, [0, 0.22, 0]);
      mesh(lathe([[0.25, -0.02], [0.29, 0.06], [0.3, 0.25], [0.29, 0.3]]), K.metal, H);
      // face mask with a cross of slits
      mesh(rbox(0.05, 0.3, 0.04, 0.01), K.void, H, [0.285, 0.2, 0]);
      mesh(rbox(0.05, 0.04, 0.3, 0.01), K.void, H, [0.285, 0.26, 0]);
      eyes(0.26, 0.24, 0.07, 0.026);
      // bell crest
      const yoke = new THREE.Group(); yoke.position.set(0, 0.5, 0); H.add(yoke);
      mesh(new THREE.TorusGeometry(0.11, 0.022, 6, 16, Math.PI), K.darkMetal, yoke, [0, 0.02, 0], [0, Math.PI / 2, 0]);
      const bell = new THREE.Group(); bell.position.set(0, 0.12, 0); yoke.add(bell);
      mesh(lathe([[0, 0.0], [0.035, -0.005], [0.055, -0.04], [0.065, -0.1], [0.09, -0.15], [0.0, -0.15]], 18), K.trim, bell);
      mesh(new THREE.SphereGeometry(0.022, 8, 6), K.darkMetal, bell, [0, -0.16, 0]);
      this.bellCrest = bell;
      // curled horns
      for (const s of [1, -1]) tube([[0, 0.38, s * 0.24], [0.05, 0.5, s * 0.38], [0.15, 0.56, s * 0.44], [0.24, 0.5, s * 0.42]], 0.035, K.bone, H, 16);
    } else if (kind === 'hood') {
      mesh(lathe([[0.36, -0.06], [0.34, 0.12], [0.3, 0.3], [0.23, 0.46], [0.13, 0.56], [0.05, 0.6], [0, 0.6]], 24), K.cloth, H, [-0.03, 0, 0]);
      const peak = mesh(new THREE.ConeGeometry(0.14, 0.42, 12), K.cloth, H, [-0.17, 0.62, 0], [0, 0, 0.95]);
      // ragged mantle over the shoulders
      for (let i = 0; i < 9; i++) { const a = (i / 8 - 0.5) * Math.PI * 1.3 + Math.PI; mesh(new THREE.ConeGeometry(0.07, 0.24, 4), K.cloth, H, [Math.cos(a) * 0.33, -0.12, Math.sin(a) * 0.33], [Math.PI, 0, 0]); }
      // dark opening
      mesh(new THREE.SphereGeometry(0.25, 16, 12), K.void, H, [0.1, 0.25, 0], null, [0.9, 1.0, 0.95]);
      // bone mask
      const mask = new THREE.Group(); mask.position.set(0.2, 0.24, 0); H.add(mask);
      mesh(new THREE.SphereGeometry(0.17, 18, 12, 0, Math.PI), K.bone, mask, [0, 0, 0], [0, Math.PI / 2, 0], [1, 1.12, 0.55]);
      for (const z of [0.065, -0.065]) mesh(new THREE.SphereGeometry(0.04, 10, 8), K.void, mask, [0.06, 0.03, z], null, [0.6, 1, 1]);
      eyes(0.27, 0.27, 0.065, 0.024);
      mesh(new THREE.ConeGeometry(0.025, 0.06, 4), K.void, mask, [0.085, -0.04, 0], [0, 0, -Math.PI / 2]);
      // a lantern of names hangs from the hood's peak
      const lan = new THREE.Group(); lan.position.set(-0.12, 0.62, 0); H.add(lan);
      mesh(new THREE.CylinderGeometry(0.05, 0.06, 0.09, 6), K.darkMetal, lan, [0, -0.06, 0]);
      const glow = mesh(new THREE.SphereGeometry(0.04, 8, 6), K.eye, lan, [0, -0.06, 0]); glow.userData.noOutline = true;
      mesh(new THREE.ConeGeometry(0.06, 0.06, 6), K.darkMetal, lan, [0, 0.0, 0]);
    }
  }

  buildWeapon(K) {
    const g = new THREE.Group(); // grip at origin, blade points +y
    this.weapon = g; this.rider.add(g);
    this.tipMarker = new THREE.Object3D(); this.baseMarker = new THREE.Object3D();
    g.add(this.tipMarker); g.add(this.baseMarker);
    this.bladeMat = K.metal.clone(); this.bladeMat.emissive = new THREE.Color(0); this.kit.all.push(this.bladeMat);
    if (this.weaponId === 'lance') return this.buildLance(K, g);
    // hilt: leather grip, faceted pommel, wide crossguard with drooping quillons
    mesh(new THREE.CylinderGeometry(0.032, 0.036, 0.26, 10), K.leather, g, [0, -0.02, 0]);
    mesh(new THREE.OctahedronGeometry(0.06, 0), K.trim, g, [0, -0.18, 0], null, [1, 1.2, 0.7]);
    tube([[0, 0.13, -0.24], [0, 0.15, -0.1], [0, 0.155, 0], [0, 0.15, 0.1], [0, 0.13, 0.24]], 0.024, K.trim, g, 12);
    mesh(new THREE.SphereGeometry(0.04, 8, 6), K.trim, g, [0, 0.15, 0]);
    // blade in its own group so it can be shortened when it breaks
    this.blade = new THREE.Group(); this.blade.position.set(0, 0.16, 0); g.add(this.blade);
    const L = 1.1;
    const sh = new THREE.Shape(); sh.moveTo(-0.05, 0); sh.lineTo(0.05, 0); sh.lineTo(0.042, L - 0.16); sh.lineTo(0, L); sh.lineTo(-0.042, L - 0.16); sh.closePath();
    mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.016, bevelEnabled: true, bevelThickness: 0.01, bevelSize: 0.012, bevelSegments: 1 }), this.bladeMat, this.blade, [0, 0, -0.008], [0, Math.PI / 2, 0]);
    mesh(rbox(0.012, L * 0.72, 0.026, 0.004), K.void, this.blade, [0, L * 0.4, 0]); // fuller
    this.bladeLen = L;
    this.baseMarker.position.set(0, 0.3, 0); this.tipMarker.position.set(0, 0.16 + L, 0);
    // scabbard on the right flank of the bike (rider-space, static)
    const sc = new THREE.Group(); this.rider.add(sc);
    sc.position.copy(SCAB.p).addScaledVector(SCAB.d, 0.62);
    sc.quaternion.setFromUnitVectors(UP, SCAB.d);
    mesh(new THREE.CylinderGeometry(0.055, 0.04, 1.08, 8), K.leather, sc);
    mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.08, 8), K.trim, sc, [0, -0.5, 0]);
    mesh(new THREE.CylinderGeometry(0.065, 0.065, 0.06, 8), K.trim, sc, [0, 0.5, 0]);
  }

  // The jousting lance: a long painted shaft, a vamplate guarding the hand and a
  // three-pronged coronel at the tip. Grip at the origin; the butt runs behind it.
  buildLance(K, g) {
    const L = 3.5;
    this.blade = new THREE.Group(); g.add(this.blade);
    // pale ash wood with painted bands, so the lance reads against the dark lists
    this.shaftMat = new THREE.MeshStandardMaterial({ color: 0xcdb894, roughness: 0.7, metalness: 0 });
    this.shaftMat.emissive = new THREE.Color(0); this.kit.all.push(this.shaftMat);
    const shaft = mesh(new THREE.CylinderGeometry(0.045, 0.09, L, 10), this.shaftMat, this.blade, [0, L / 2 - 0.15, 0]);
    shaft.userData.keep = true;
    mesh(new THREE.CylinderGeometry(0.07, 0.05, 0.7, 10), K.leather, g, [0, -0.5, 0]);             // butt and grip
    for (let k = 0; k < 6; k++) mesh(new THREE.CylinderGeometry(0.086 - k * 0.007, 0.09 - k * 0.007, 0.16, 10), K.paint, this.blade, [0, 0.55 + k * 0.45, 0]); // painted bands
    const vamp = mesh(new THREE.ConeGeometry(0.3, 0.46, 14, 1, true), K.trim, g, [0, 0.28, 0]);   // vamplate
    vamp.material = K.trim; vamp.userData.keep = true;
    this.coronel = new THREE.Group(); this.coronel.position.set(0, L - 0.15, 0); this.blade.add(this.coronel);
    mesh(new THREE.CylinderGeometry(0.05, 0.035, 0.12, 8), K.trim, this.coronel, [0, 0.04, 0]);
    for (let k = 0; k < 3; k++) {
      const a = k / 3 * Math.PI * 2;
      mesh(new THREE.ConeGeometry(0.022, 0.12, 5), K.trim, this.coronel, [Math.cos(a) * 0.04, 0.15, Math.sin(a) * 0.04]);
    }
    this.bladeLen = L; this.lanceLen = L;
    this.baseMarker.position.set(0, 0.6, 0); this.tipMarker.position.set(0, L - 0.05, 0);
  }

  // A clean hit breaks the lance: the shaft snaps and splinters fly.
  breakLance(r) {
    if (this.weaponId !== 'lance' || this.lanceBroken) return;
    this.lanceBroken = true;
    const tip = this.tipMarker.getWorldPosition(new THREE.Vector3());
    this.blade.scale.set(1, 0.34, 1);
    this.tipMarker.position.set(0, this.lanceLen * 0.34, 0);
    for (let i = 0; i < 9; i++) {
      const sp = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.25 + Math.random() * 0.5, 0.035), i % 3 ? this.shaftMat : this.kit.leather);
      sp.position.copy(tip).add(V((Math.random() - 0.5) * 0.6, (Math.random() - 0.5) * 0.4, (Math.random() - 0.5) * 0.4));
      this.fx.debris.add(sp, V((Math.random() - 0.5) * 7 - (r ? r.facing * 2 : 0), 3 + Math.random() * 4, (Math.random() - 0.5) * 5), V(Math.random() * 20, Math.random() * 20, Math.random() * 20), 4);
    }
    this.fx.burstSparks(tip, 40, 8, 0xe8d6b0);
  }
  freshLance() {
    if (this.weaponId !== 'lance') return;
    this.lanceBroken = false;
    this.blade.scale.set(1, 1, 1);
    this.tipMarker.position.set(0, this.lanceLen - 0.05, 0);
  }

  buildShield(K) {
    const s = new THREE.Shape();
    s.moveTo(-0.3, 0.3); s.lineTo(0.3, 0.3); s.quadraticCurveTo(0.33, -0.18, 0, -0.52); s.quadraticCurveTo(-0.33, -0.18, -0.3, 0.3);
    const geo = new THREE.ExtrudeGeometry(s, { depth: 0.05, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.03, bevelSegments: 2, curveSegments: 16 });
    const tex = emblemTexture(this.def.emblem, this.def.paint, this.def.trim);
    this.shieldTex = tex;
    tex.repeat.set(1 / 0.66, 1 / 0.88); tex.offset.set(0.33 / 0.66, 0.55 / 0.88);
    tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
    const face = new THREE.MeshStandardMaterial({ map: tex, metalness: 0.3, roughness: 0.6, normalMap: getMaps().paint.normalMap });
    face.emissive = new THREE.Color(0); this.kit.all.push(face);
    this.shieldFace = face; this.shieldTexes = [tex];
    this.shield = new THREE.Group(); this.rider.add(this.shield);
    const sm = mesh(geo, [face, this.kit.trim], this.shield, [0, 0, 0.04]);
    sm.scale.set(1.08, 1.08, 1);
    mesh(new THREE.SphereGeometry(0.06, 10, 8), this.kit.trim, this.shield, [0, 0.02, 0.13], null, [1, 1, 0.6]);
    this.shieldHome = { pos: V(0, 0, 0) };
  }

  buildCape(K) {
    // Verlet cloth hanging from the shoulders; simulated in world space.
    const cols = 6, rows = 7, W = 0.62, Hh = 0.95;
    this.cape = { cols, rows, W, Hh, pts: [], prev: [], rest: Hh / (rows - 1), restX: W / (cols - 1) };
    const geo = new THREE.PlaneGeometry(W, Hh, cols - 1, rows - 1);
    this.capeMesh = new THREE.Mesh(geo, K.cape);
    this.capeMesh.frustumCulled = false;
    this.capeMesh.castShadow = true;
    this.scene.add(this.capeMesh);
    this.capeAnchor = [new THREE.Object3D(), new THREE.Object3D()];
    this.capeAnchor[0].position.set(-0.18, 0.5, 0.26); this.capeAnchor[1].position.set(-0.18, 0.5, -0.26);
    this.spine.add(this.capeAnchor[0]); this.spine.add(this.capeAnchor[1]);
    this.capeInit = false;
  }

  buildLights() {
    this.headLight = new THREE.PointLight(0xffd6a0, 6, 7, 2);
    this.headLight.position.set(1.3, 1.1, 0);
    this.bike.add(this.headLight);
    // fake volumetric beam
    const beamGeo = new THREE.ConeGeometry(0.7, 3.2, 24, 1, true);
    beamGeo.translate(0, -1.6, 0); beamGeo.rotateZ(Math.PI / 2);
    const beamMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
      uniforms: { uI: { value: 0.09 } },
      vertexShader: `varying vec3 vP; varying vec3 vN; varying vec3 vV; void main(){ vP = position; vN = normalize(normalMatrix*normal); vec4 mv = modelViewMatrix*vec4(position,1.0); vV = normalize(-mv.xyz); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `uniform float uI; varying vec3 vP; varying vec3 vN; varying vec3 vV; void main(){ float along = clamp(vP.x/3.2, 0.0, 1.0); float edge = pow(abs(dot(vN, vV)), 1.5); gl_FragColor = vec4(vec3(1.0,0.82,0.55) * uI * (1.0-along) * (1.0-along) * edge, 1.0); }`,
    });
    this.beam = new THREE.Mesh(beamGeo, beamMat);
    this.beam.userData.keep = true;
    this.beam.position.set(0.92, 1.16, 0);
    this.beam.rotation.z = -0.12;
    this.beam.renderOrder = 15;
    this.bike.add(this.beam);
    // fighting-game "character light": a soft warm fill from the camera side
    this.charLight = new THREE.PointLight(0xffd8b8, 7, 9, 1.2);
    this.scene.add(this.charLight);
    this.exhaustLight = new THREE.PointLight(0xff6a20, 0, 4, 2);
    this.exhaustLight.position.set(-1.35, 0.75, 0);
    this.bike.add(this.exhaustLight);
  }

  // -------------------------------------------------------------- round reset
  resetRound() {
    // reattach rider and fairing, clear damage
    if (this.rag) this.remount();
    this.rider.visible = true;
    this.fairing.forEach((g, i) => {
      if (g.parent !== this.bike) { g.parent && g.parent.remove(g); this.bike.add(g); }
      g.position.copy(this.fairingHome[i].p); g.rotation.copy(this.fairingHome[i].r); g.scale.setScalar(1); g.visible = true;
    });
    this.fx.debris.list = this.fx.debris.list.filter(d => !this.fairing.includes(d.obj));
    this.fairingLost = 0;
    this.bikeDown = 0; this.bikeFallDir = 1;
    this.bike.rotation.set(0, 0, 0); this.bike.position.set(0, 0, 0);
    this.engineGroup.visible = true;
    const p = ZP.ride;
    this.resetEquipment();
    this.handS = new Spring3(V(...p.h), 300, 0.6);
    this.dirS = new Spring3(V(...p.d).normalize(), 300, 0.6);
    this.shS = new Spring3(V(...ZS.ride.h), 340, 0.65);
    this.shF = new Spring3(V(...ZS.ride.f), 340, 0.65);
    this.lean = new Spring1(0, 140, 0.55); this.twist = new Spring1(0, 140, 0.55);
    this.pitch = new Spring1(0, 90, 0.4); this.bounce = new Spring1(0, 200, 0.35);
    this.squash = new Spring1(1, 260, 0.3);
    this.roll = new Spring1(0, 80, 0.5);
    this.capeInit = false;
    this.lastAct = 'free';
    this.flash = 0;
    this.smokeT = 0;
  }

  // -------------------------------------------------------------- per frame
  update(dt, r, op, ctx) {
    this.t += dt;
    const facing = r.facing;
    const lane = r.lane;
    // --- placement & facing (mirroring keeps the weapon toward the barrier)
    this.root.position.set(r.x, 0, lane);
    this.charLight.position.set(r.x + 0.6, 3.4, lane + 4.2);
    const mirrored = (facing > 0) !== (lane < 0);
    let yaw = facing > 0 ? 0 : Math.PI, sx = 1, flipZ = mirrored ? -1 : 1, roll = 0;
    const turning = r.act === 'turn' || r.act === 'skid' || r.act === 'wide';
    if (turning) {
      // A real U-turn: the bike swings out away from the tilt on an arc and yaws through 180°,
      // leaning into the bend. The weapon side swaps at mid-turn, when the bike is seen end-on.
      const k = Math.min(1, r.actT / Math.max(0.2, r.actDur || 1));
      const skidding = r.act === 'skid';
      // a skid snaps the rear round early (fast yaw, then settle); a plain turn is a smooth arc
      const wide = r.act === 'wide';
      const e = turnEase(r.act, k); // the same curve the simulation moves the bike along
      const out = lane > 0 ? 1 : -1;                  // outward, away from the tilt
      const dir = -out * facing;                      // yaw sense that heads the nose outward
      yaw += dir * e * Math.PI;
      if (e >= 0.5) flipZ = -flipZ;
      this.root.position.z = lane + out * Math.sin(Math.PI * Math.min(1, k * 1.05)) * (wide ? 2.2 : skidding ? 0.8 : 1.3);
      roll = Math.sin(Math.PI * k) * (wide ? 0.5 : skidding ? 0.42 : 0.3) * -out;
      if (wide && Math.random() < 0.6) this.fx.burstSparks(V(r.x, 0.1, this.root.position.z), 1, 3, 0xffa860, 0.7);
      if (!this.turnDust || r.actT < this.lastTurnT) this.turnDust = 0;
      this.lastTurnT = r.actT;
      this.turnDust -= dt;
      if (this.turnDust <= 0) { this.turnDust = skidding ? 0.016 : 0.05; this.dust(r, skidding ? 5 : 2, skidding ? 1.9 : 1.0); }
      if (skidding && k < 0.6 && Math.random() < 0.5) this.fx.burstSparks(V(r.x, 0.1, this.root.position.z), 2, 3, 0xffa860, 0.8);
    }
    this.root.rotation.order = 'YXZ';
    this.root.rotation.y = yaw;
    this.root.rotation.x = roll;
    this.flip.scale.set(sx, 1, flipZ);

    // --- bike dynamics
    const accel = (r.v - this.prevV) / Math.max(dt, 1e-4);
    this.prevV = r.v;
    const boosting = r.perfectT > 0;
    const pitchT = r.act === 'down' ? 0 : THREE.MathUtils.clamp(accel * 0.006, -0.12, 0.1) + (boosting ? 0.1 : 0);
    const bump = (Math.sin(this.t * 31 + this.i) * 0.5 + Math.sin(this.t * 17.3) * 0.5) * Math.min(r.v, 20) * 0.0012;
    this.bike.rotation.z = this.pitch.update(pitchT, dt);
    this.bike.position.y = this.bounce.update(bump, dt);
    for (const w of this.wheels) {
      this.wheelAngle -= (r.v * dt / w.userData.r) * 0.5;
      w.rotation.z = this.wheelAngle;
    }

    // engine damage feedback
    const eng = r.engine / RIDER.engine;
    this.smokeT -= dt;
    if (eng < 0.6 && this.smokeT <= 0 && r.act !== 'down') {
      this.smokeT = eng < 0.3 ? 0.035 : 0.08;
      const p = this.engineGroup.getWorldPosition(this.fx.tmpP);
      p.y += 0.25;
      this.fx.puff(p, V((Math.random() - 0.5) * 0.4 - facing * r.v * 0.25, 1.2 + Math.random(), (Math.random() - 0.5) * 0.4), eng < 0.3 ? 0x111010 : 0x4a4644, 0.25, 1.6, eng < 0.3 ? 0.7 : 0.45, 3);
      if (eng < 0.3 && Math.random() < 0.3) this.fx.burstSparks(p, 2, 3, 0xff8a3a);
    }
    // fairing detaches in three stages
    const fr = r.fairing / RIDER.fairing;
    const lostTarget = fr <= 0 ? 3 : fr < 0.34 ? 2 : fr < 0.67 ? 1 : 0;
    while (this.fairingLost < lostTarget) this.detachFairing(this.fairingLost++, r);

    // exhaust flames
    const thr = r.act === 'down' ? 0 : Math.max(0, r.throttle) + (boosting ? 2.2 : 0);
    for (const tip of this.exhaustTips) {
      if (Math.random() < 0.25 + thr * 0.35) {
        const p = tip.getWorldPosition(this.fx.tmpP);
        const back = -facing;
        this.fx.flare(p, boosting ? 0x6ab8ff : 0xff7a2a, 0.16 + thr * 0.12, 0.08 + thr * 0.03, 0.9);
        if (Math.random() < 0.4) this.fx.puff(p, V(back * (1.5 + r.v * 0.2), 0.3, (Math.random() - 0.5) * 0.3), 0x2a2624, 0.14, 0.9, 0.25, 4);
        if (boosting) this.fx.burstSparks(p, 1, 4, 0x8ac8ff, 1, V(back, 0, 0));
      }
    }
    this.exhaustLight.intensity = (thr * 3 + Math.random() * 2) * (boosting ? 3 : 1);
    this.exhaustLight.color.set(boosting ? 0x6ab8ff : 0xff6a20);
    if (r.v > 6 && Math.random() < r.v * 0.02 && r.act !== 'down') this.dust(r, 1, 0.6);

    if (this.bannerTime) { this.bannerTime.value = this.t; this.bannerSpeed.value = r.v; }

    // --- rider animation
    const recovering = r.act === 'getup' || r.act === 'walk' || r.act === 'mount';
    if (r.act === 'down') this.updateDown(dt, r);
    else if (recovering) this.updateRecover(dt, r);
    else { if (this.rag) this.remount(); this.animateRider(dt, r, op, ctx); }

    // hit flash + squash
    // hit flash runs on wall-clock time so slow motion never freezes it white
    const since = (performance.now() - (this.flashAt || -1e9)) / 120;
    const fc = since < 1 ? (1 - since) * (1 - since) : 0;
    if (fc > 0 || this.lastFc > 0) for (const m of this.kit.all) m.emissive.setRGB(fc * 0.32, fc * 0.22, fc * 0.14);
    this.lastFc = fc;
    const sq = this.squash.update(1, dt);
    this.bike.scale.set(1 + (1 - sq) * 0.5, sq, 1 + (1 - sq) * 0.5);

    this.updateCape(dt, r);
    const off = r.act === 'down' || recovering;
    this.headLight.intensity = off ? 0 : 6;
    this.beam.visible = !off;
    this.lastAct = r.act;
  }

  animateRider(dt, r, op, ctx) {
    const act = r.act, atk = r.atk || 'thrust';
    const lance = this.weaponId === 'lance';
    // rest pose from the aim: hand height and tip angle, in bike space (+x forward, +z toward the tilt)
    const aimH = r.aimH || 0, aimA = r.aimA || 0;
    const h = V(lance ? 0.3 : 0.38, 1.38 + aimH * 0.34, lance ? 0.36 : 0.5);
    let ang = lance ? aimA * 0.62 : 0.55 + aimA * 0.9;
    let dz = lance ? 0.16 : 0.22, lean = 0.12, twist = 0, kMul = 1;
    const ph = r.actDur > 0 ? Math.min(1, r.actT / r.actDur) : 1;
    if (act === 'windup') {
      kMul = 1.6;
      if (atk === 'thrust') { h.x -= 0.28; lean = 0.02; twist = -0.25; }
      else if (atk === 'smash') { h.y += 0.38; h.x -= 0.1; ang += 0.9; lean = -0.12; twist = -0.1; }
      else if (atk === 'cut') { h.y -= 0.28; ang -= 0.7; twist = -0.35; }
      else if (atk === 'slash') { h.z -= 0.35; dz = -0.55; twist = -0.6; }
    } else if (act === 'active' || (act === 'recover' && r.actT < 0.1)) {
      kMul = 3.4;
      if (atk === 'thrust') { h.x += 0.38; lean = 0.38; twist = 0.25; }
      else if (atk === 'smash') { h.y -= 0.05; h.x += 0.2; ang -= 0.55; lean = 0.45; }
      else if (atk === 'cut') { h.y += 0.18; h.x += 0.15; ang += 0.6; lean = 0.25; twist = 0.3; }
      else if (atk === 'slash') { h.z += 0.25; h.x += 0.1; dz = 0.95; twist = 0.7; lean = 0.3; }
    } else if (act === 'stagger' || act === 'down') {
      const p = ZP.staggered; h.set(...p.h); ang = 1.1; lean = p.lean; twist = p.twist; kMul = 1.8;
    } else if (act === 'turn' || act === 'skid') {
      h.y += 0.25; ang = lance ? 1.25 : 1.2; kMul = 1.2; // the weapon goes up out of the way through the turn
    }
    const d = V(Math.cos(ang), Math.sin(ang), dz).normalize();
    // during the blow, bend the weapon toward the rival so contact reads
    if (act === 'active' && op && atk !== 'slash') {
      const target = this.worldToBike(V(op.x, r.tipY || 1.6, op.lane));
      d.lerp(target.sub(h).normalize(), lance ? 0.25 : 0.4).normalize();
    }
    this.handS.update(h, dt, kMul);
    this.dirS.update(d, dt, kMul);
    this.lean.update(lean + (r.throttle > 0 ? 0.1 : 0), dt);
    this.twist.update(twist, dt);
    this.drewSword = false;
    void ph;

    // shield (left hand) — on the left grip unless guarding
    const up = r.shieldUp && r.shield > 0;
    const sp = up ? ZS.horiz : ZS.ride;
    const sk = up ? 2.6 : 1;
    this.shS.update(V(...sp.h), dt, sk);
    this.shF.update(V(...sp.f), dt, sk);

    // torso
    const stagger = act === 'stagger' ? Math.sin(r.actT * 30) * 0.05 * Math.max(0, 1 - r.actT * 2) : 0;
    this.spine.rotation.set(0, this.twist.v * 0.5, -this.lean.v + stagger);
    this.hip.position.y = 1.12 + Math.abs(Math.sin(this.t * 14)) * Math.min(r.v, 18) * 0.0016;
    if (op) {
      const look = this.worldToBike(V(op.x, 1.8, op.lane));
      const yaw = Math.atan2(look.z, Math.max(0.3, look.x + 1)) * 0.45;
      this.head.rotation.y = THREE.MathUtils.lerp(this.head.rotation.y, THREE.MathUtils.clamp(-yaw, -0.6, 0.6), Math.min(1, dt * 6));
    }
    this.head.rotation.z = THREE.MathUtils.lerp(this.head.rotation.z, this.lean.v * 0.4 - 0.05 + this.helmTilt, Math.min(1, dt * 8));
    if (this.bellCrest) this.bellCrest.rotation.x = Math.sin(this.t * 9) * 0.1 * Math.min(1, r.v / 10);

    this.root.updateMatrixWorld(true);
    this.solveArm(this.armR, this.handS.v, V(-0.4, -0.6, 0.6));
    this.solveArm(this.armL, this.shS.v, V(-0.3, -0.7, -0.6));
    this.weapon.position.copy(this.armR.hand.position);
    this.weapon.quaternion.setFromUnitVectors(UP, this.dirS.v.clone().normalize());
    // shield orientation: face normal = +z of shield group
    if (this.shield.parent !== this.rider) return; // shattered and gone
    this.shield.position.copy(this.armL.hand.position).addScaledVector(this.shF.v.clone().normalize(), 0.08);
    const m = new THREE.Matrix4();
    const zf = this.shF.v.clone().normalize();
    const xf = new THREE.Vector3().crossVectors(Math.abs(zf.y) > 0.9 ? V(1, 0, 0) : UP, zf).normalize();
    const yf = new THREE.Vector3().crossVectors(zf, xf).normalize();
    m.makeBasis(xf, yf, zf);
    this.shield.quaternion.setFromRotationMatrix(m);
    this.shield.scale.setScalar(up ? 1.12 : 1);
  }

  // -------------------------------------------------------------- equipment damage
  resetEquipment() {
    if (!this.helm) return;
    if (this.helm.parent !== this.head) { this.helm.parent && this.helm.parent.remove(this.helm); this.head.add(this.helm); }
    this.helm.position.set(0, 0, 0); this.helm.rotation.set(0, 0, 0); this.helm.scale.set(1, 1, 1); this.helm.visible = true;
    this.bare.visible = false;
    this.helmTilt = 0;
    if (this.shield.parent !== this.rider) { this.shield.parent && this.shield.parent.remove(this.shield); this.rider.add(this.shield); }
    this.shield.visible = true;
    this.shieldFace.map = this.shieldTexes[0]; this.shieldFace.needsUpdate = true;
    this.blade.scale.set(1, 1, 1);
    this.tipMarker.position.set(0, this.weaponId === 'lance' ? this.lanceLen - 0.05 : 0.16 + this.bladeLen, 0);
    this.lanceBroken = false;
    this.bladeMat.color.copy(this.kit.metal.color);
    this.fx.debris.list = this.fx.debris.list.filter(d => d.obj !== this.helm && d.obj !== this.shield);
  }

  // e: { item: helmet|shield|sword, lvl } for dents, or a break when type === 'equipBreak'
  onEquip(e, r) {
    const broke = e.type === 'equipBreak';
    if (e.item === 'helmet') {
      if (!broke) {
        // dents: the helm buckles and sits crooked
        const k = e.lvl;
        this.helm.scale.set(1 + 0.04 * k, 1 - 0.07 * k, 1 + 0.05 * k);
        this.helm.rotation.x = 0.07 * k * (this.i ? -1 : 1);
        this.helmTilt = 0.08 * k;
        const p = this.head.getWorldPosition(new THREE.Vector3()).add(V(0, 0.4, 0));
        this.fx.burstSparks(p, 30 + 20 * k, 7, 0xfff0c0);
      } else {
        this.throwPiece(this.helm, r, 7);
        this.bare.visible = true;
      }
    } else if (e.item === 'shield') {
      if (!broke) {
        this.shieldFace.map = this.crackedShield(e.lvl); this.shieldFace.needsUpdate = true;
        this.fx.burstSparks(this.shield.getWorldPosition(new THREE.Vector3()), 24, 6, 0xd8c8a8);
      } else {
        const p = this.shield.getWorldPosition(new THREE.Vector3());
        this.throwPiece(this.shield, r, 5);
        for (let i = 0; i < 14; i++) this.fx.puff(p, V((Math.random() - 0.5) * 4, Math.random() * 3, (Math.random() - 0.5) * 4), 0x3a3028, 0.15, 0.9, 0.6, 2);
        this.fx.burstSparks(p, 60, 8, 0xd8c8a8);
      }
    } else if (e.item === 'sword') {
      if (!broke) {
        this.bladeMat.color.copy(this.kit.metal.color).multiplyScalar(e.lvl === 1 ? 0.75 : 0.55);
        this.fx.burstSparks(this.tipMarker.getWorldPosition(new THREE.Vector3()), 20, 6, 0xffe0b0);
      } else {
        const tip = this.tipMarker.getWorldPosition(new THREE.Vector3());
        this.blade.scale.set(1, 0.42, 1);
        this.tipMarker.position.set(0, 0.16 + this.bladeLen * 0.42, 0);
        const shard = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.5, 4), this.bladeMat);
        shard.position.copy(tip);
        this.fx.debris.add(shard, V((Math.random() - 0.5) * 4, 5, (Math.random() - 0.5) * 3), V(14, 3, 9), 4);
        this.fx.burstSparks(tip, 70, 10, 0xfff0c0);
        this.fx.flare(tip, 0xffffff, 1.6, 0.18);
      }
    }
  }

  throwPiece(obj, r, up) {
    obj.updateMatrixWorld(true);
    const wp = new THREE.Vector3(), wq = new THREE.Quaternion(), ws = new THREE.Vector3();
    obj.matrixWorld.decompose(wp, wq, ws);
    obj.parent.remove(obj);
    obj.position.copy(wp); obj.quaternion.copy(wq); obj.scale.copy(ws);
    const side = r.lane > 0 ? 1 : -1;
    this.fx.debris.add(obj, V(-r.facing * r.v * 0.4 + (Math.random() - 0.5) * 2, up, side * (1.5 + Math.random() * 2)), V(Math.random() * 12, Math.random() * 12, Math.random() * 12), 6, 0.15);
  }

  crackedShield(lvl) {
    if (this.shieldTexes[lvl]) return this.shieldTexes[lvl];
    const src = this.shieldTexes[0].image;
    const c = document.createElement('canvas'); c.width = src.width; c.height = src.height;
    const g = c.getContext('2d'); g.drawImage(src, 0, 0);
    g.strokeStyle = 'rgba(8,6,5,0.92)'; g.lineCap = 'round';
    let seed = 17 + lvl * 31 + this.i * 7;
    const R = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
    const cracks = lvl * 4;
    for (let k = 0; k < cracks; k++) {
      let x = c.width * (0.3 + R() * 0.4), y = c.height * (0.25 + R() * 0.4);
      g.lineWidth = 7 - k * 0.6;
      g.beginPath(); g.moveTo(x, y);
      for (let j = 0; j < 7; j++) { x += (R() - 0.5) * 120; y += (R() - 0.3) * 90; g.lineTo(x, y); g.lineWidth *= 0.8; }
      g.stroke();
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace; t.repeat.copy(this.shieldTexes[0].repeat); t.offset.copy(this.shieldTexes[0].offset);
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping;
    this.shieldTexes[lvl] = t;
    return t;
  }

  // Two-bone IK. Positions are in rider-group space (== bike space).
  solveArm(arm, target, pole) {
    const s = arm.shoulder.getWorldPosition(new THREE.Vector3());
    this.rider.worldToLocal(s);
    const la = arm.la, lb = arm.lb;
    const toT = target.clone().sub(s);
    let dist = toT.length();
    const maxD = (la + lb) * 0.999;
    const dir = toT.clone().normalize();
    if (dist > maxD) dist = maxD;
    const hand = s.clone().addScaledVector(dir, dist);
    const a = (la * la - lb * lb + dist * dist) / (2 * dist);
    const hgt = Math.sqrt(Math.max(0, la * la - a * a));
    const poleDir = pole.clone().sub(dir.clone().multiplyScalar(pole.dot(dir))).normalize();
    const elbow = s.clone().addScaledVector(dir, a).addScaledVector(poleDir, hgt);
    place(arm.upper, s, elbow);
    place(arm.fore, elbow, hand);
    arm.elbowCap.position.copy(elbow);
    arm.hand.position.copy(hand);
    function place(m, p0, p1) {
      m.position.copy(p0).add(p1).multiplyScalar(0.5);
      m.quaternion.setFromUnitVectors(UP, p1.clone().sub(p0).normalize());
    }
  }

  worldToBike(v) {
    this.root.updateMatrixWorld(true);
    return this.rider.worldToLocal(v);
  }

  weaponPoints(base, tip) {
    this.baseMarker.getWorldPosition(base);
    this.tipMarker.getWorldPosition(tip);
  }

  // -------------------------------------------------------------- cape
  updateCape(dt, r) {
    const C = this.cape;
    const pos = this.capeMesh.geometry.attributes.position;
    const a0 = this.capeAnchor[0].getWorldPosition(new THREE.Vector3());
    const a1 = this.capeAnchor[1].getWorldPosition(new THREE.Vector3());
    if (!this.capeInit) {
      C.pts = []; C.prev = [];
      for (let j = 0; j < C.rows; j++) for (let i = 0; i < C.cols; i++) {
        const top = a0.clone().lerp(a1, i / (C.cols - 1));
        const p = top.clone().add(V(-r.facing * 0.05 * j, -j * C.rest, 0));
        C.pts.push(p); C.prev.push(p.clone());
      }
      this.capeInit = true;
    }
    const wind = V(-r.facing * r.v * 0.9 + Math.sin(this.t * 1.3) * 1.5, 0.3, Math.sin(this.t * 2.1 + this.i) * 0.8);
    const h = Math.min(dt, 1 / 30);
    for (let j = 1; j < C.rows; j++) for (let i = 0; i < C.cols; i++) {
      const k = j * C.cols + i, p = C.pts[k], q = C.prev[k];
      const vx = (p.x - q.x) * 0.97, vy = (p.y - q.y) * 0.97, vz = (p.z - q.z) * 0.97;
      q.copy(p);
      p.x += vx + wind.x * h * h * 3; p.y += vy - 9.8 * h * h; p.z += vz + wind.z * h * h * 3;
      if (p.y < 0.05) p.y = 0.05;
    }
    for (let i = 0; i < C.cols; i++) { const p = a0.clone().lerp(a1, i / (C.cols - 1)); C.pts[i].copy(p); C.prev[i].copy(p); }
    const tmp = new THREE.Vector3();
    for (let it = 0; it < 4; it++) {
      for (let j = 0; j < C.rows; j++) for (let i = 0; i < C.cols; i++) {
        const k = j * C.cols + i;
        if (i < C.cols - 1) constrain(k, k + 1, C.restX);
        if (j < C.rows - 1) constrain(k, k + C.cols, C.rest);
      }
      for (let i = 0; i < C.cols; i++) { C.pts[i].copy(a0.clone().lerp(a1, i / (C.cols - 1))); }
    }
    function constrain(a, b, rest) {
      const pa = C.pts[a], pb = C.pts[b];
      tmp.subVectors(pb, pa);
      const d = tmp.length() || 1e-5;
      const diff = (d - rest) / d * 0.5;
      const ja = a < C.cols ? 0 : 1, jb = b < C.cols ? 0 : 1;
      if (ja && jb) { pa.addScaledVector(tmp, diff); pb.addScaledVector(tmp, -diff); }
      else if (jb) pb.addScaledVector(tmp, -diff * 2);
      else if (ja) pa.addScaledVector(tmp, diff * 2);
    }
    for (let k = 0; k < C.pts.length; k++) pos.setXYZ(k, C.pts[k].x, C.pts[k].y, C.pts[k].z);
    pos.needsUpdate = true;
    this.capeMesh.geometry.computeVertexNormals();
    this.capeMesh.geometry.computeBoundingSphere();
    this.capeMesh.visible = this.rider.visible;
  }

  // -------------------------------------------------------------- damage & KO
  onHit(e, isVictim) {
    if (isVictim) { this.flashAt = performance.now(); this.squash.vel = -6; this.lastHit = { at: performance.now(), dmg: e.dmg || 10, y: e.y || 1.6, dir: e.dir || 0 }; }
  }

  detachFairing(idx, r) {
    const g = this.fairing[idx];
    if (!g || g.parent !== this.bike) return;
    g.updateMatrixWorld(true);
    const wp = new THREE.Vector3(), wq = new THREE.Quaternion(), ws = new THREE.Vector3();
    g.matrixWorld.decompose(wp, wq, ws);
    this.bike.remove(g);
    g.position.copy(wp); g.quaternion.copy(wq); g.scale.copy(ws);
    const out = this.i === 0 ? 1 : -1; // toward camera-ish/barrier
    this.fx.debris.add(g, V(-r.facing * r.v * 0.3 + (Math.random() - 0.5) * 3, 3.5 + Math.random() * 2, out * (1.5 + Math.random() * 2)), V(Math.random() * 10, Math.random() * 10, Math.random() * 10), 5);
    this.fx.burstSparks(wp, 40, 9, 0xffc070);
    this.fx.flare(wp, 0xffa050, 1.4, 0.2);
  }

  // ------------------------------------------------------------ ragdoll
  // Unhorsed riders become a Verlet ragdoll: the armoured torso and legs are one
  // rigid cluster of particles, the head swings on the neck, the hands fly free on
  // their arms (IK follows them), and the weapon tumbles as its own stick. It
  // starts with the bike's real speed plus the impulse of the blow, under normal
  // gravity, and slides, bounces and rolls on the stones until it comes to rest.
  knockOff(e, r) {
    const R = this.rider;
    this.root.updateMatrixWorld(true);
    const W = p => R.localToWorld(p.clone());
    const hipW = this.hip.getWorldPosition(new THREE.Vector3());
    const chestW = this.spine.localToWorld(V(0.02, 0.35, 0));
    const headW = this.head.localToWorld(V(0, 0.24, 0));
    const pts = {
      chest: chestW, hipL: W(V(-0.32, 1.08, -0.2)), hipR: W(V(-0.32, 1.08, 0.2)),
      footL: W(V(0.12, 0.56, -0.29)), footR: W(V(0.12, 0.56, 0.29)),
      shL: this.shoulderL.getWorldPosition(new THREE.Vector3()), shR: this.shoulderR.getWorldPosition(new THREE.Vector3()),
      head: headW,
      handL: this.armL.hand.getWorldPosition(new THREE.Vector3()), handR: this.armR.hand.getWorldPosition(new THREE.Vector3()),
      wBase: this.baseMarker.getWorldPosition(new THREE.Vector3()), wTip: this.tipMarker.getWorldPosition(new THREE.Vector3()),
    };
    const rad = { chest: 0.32, hipL: 0.17, hipR: 0.17, footL: 0.12, footR: 0.12, shL: 0.2, shR: 0.2, head: 0.3, handL: 0.1, handR: 0.1, wBase: 0.05, wTip: 0.05 };
    // starting velocity: the bike's own speed, a little lift, and the blow's push
    const base = V(r.facing * r.v, 1.1, 0);
    const P = {};
    const dt0 = 1 / 120;
    for (const k in pts) P[k] = { p: pts[k].clone(), q: pts[k].clone().addScaledVector(base, -dt0), r: rad[k] };
    const h = this.lastHit && performance.now() - this.lastHit.at < 1500 ? this.lastHit : null;
    if (h) {
      // the blow pushes along the attacker's line, hardest where it landed
      const push = Math.min(3.2, 0.6 + h.dmg * 0.045);
      const at = h.y > 1.95 ? ['head', 'chest'] : h.y > 1.2 ? ['chest', 'shL', 'shR'] : ['hipL', 'hipR'];
      for (const k of at) P[k].q.x -= h.dir * push * dt0 * (k === at[0] ? 1.6 : 1);
      P.head.q.y += 0.3 * dt0;
    }
    // constraints: rigid body (all pairs), neck, arms (max length), weapon stick
    const rigid = ['chest', 'hipL', 'hipR', 'footL', 'footR', 'shL', 'shR'];
    const C = [];
    for (let i = 0; i < rigid.length; i++) for (let j = i + 1; j < rigid.length; j++) C.push([rigid[i], rigid[j], pts[rigid[i]].distanceTo(pts[rigid[j]]), 1]);
    C.push(['chest', 'head', pts.chest.distanceTo(pts.head), 1]);
    C.push(['hipL', 'head', pts.hipL.distanceTo(pts.head) * 0.92, 2]);     // the neck can't fold the head into the hips
    C.push(['hipR', 'head', pts.hipR.distanceTo(pts.head) * 0.92, 2]);
    C.push(['shL', 'handL', 0.62, 3]); C.push(['shR', 'handR', 0.62, 3]); // arms: rope (max length)
    C.push(['wBase', 'wTip', pts.wBase.distanceTo(pts.wTip), 1]);
    // the frame of the rigid body at the moment of the fall, to carry the model with it
    const B0 = this.ragFrame(P);
    R.updateMatrixWorld(true);
    const M0 = R.matrixWorld.clone();
    const W0 = this.weapon.matrixWorld.clone();
    const wFrame0 = this.stickFrame(P.wBase.p, P.wTip.p);
    // detach the rider and the weapon into world space
    this.scene.attach(R);
    this.scene.attach(this.weapon);
    this.rag = { P, C, B0inv: B0.clone().invert(), M0, W0, wFrame0inv: wFrame0.clone().invert(), still: 0, sleep: false, acc: 0, wHeld: true };
    const dirZ = r.lane > 0 ? 1 : -1;
    this.bikeFallDir = -dirZ;
    if (this.shield.parent === this.rider) this.throwPiece(this.shield, r, 2.5);
  }

  ragFrame(P) {
    const o = P.hipL.p.clone().add(P.hipR.p).multiplyScalar(0.5);
    const u = P.chest.p.clone().sub(o).normalize();
    const sd = P.hipR.p.clone().sub(P.hipL.p);
    sd.addScaledVector(u, -sd.dot(u)).normalize();
    const f = new THREE.Vector3().crossVectors(u, sd).normalize();
    return new THREE.Matrix4().makeBasis(f, u, sd).setPosition(o);
  }
  stickFrame(a, b) {
    const d = b.clone().sub(a).normalize();
    const q = new THREE.Quaternion().setFromUnitVectors(UP, d);
    return new THREE.Matrix4().compose(a, q, V(1, 1, 1));
  }

  stepRag(dt) {
    const G = this.rag; if (!G || G.sleep) return;
    const H = 1 / 120;
    G.acc = Math.min(G.acc + dt, 0.1);
    while (G.acc >= H) {
      G.acc -= H;
      // integrate (Verlet), real gravity, light air drag
      for (const k in G.P) {
        const n = G.P[k];
        const vx = (n.p.x - n.q.x) * 0.999, vy = (n.p.y - n.q.y) * 0.999, vz = (n.p.z - n.q.z) * 0.999;
        n.q.copy(n.p);
        n.p.x += vx; n.p.y += vy - 9.81 * H * H; n.p.z += vz;
      }
      for (let it = 0; it < 6; it++) {
        for (const [a, b, len, kind] of G.C) {
          const A = G.P[a].p, B = G.P[b].p;
          const dx = B.x - A.x, dy = B.y - A.y, dz = B.z - A.z;
          const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1e-6;
          if (kind === 3 && d <= len) continue;   // rope: only stops stretching
          if (kind === 2 && d >= len) continue;   // strut: only stops collapsing
          const k = (d - len) / d * 0.5 * (kind === 1 ? 1 : 0.8);
          A.x += dx * k; A.y += dy * k; A.z += dz * k;
          B.x -= dx * k; B.y -= dy * k; B.z -= dz * k;
        }
        // the stones, the tilt and the end barriers
        for (const kk in G.P) {
          const n = G.P[kk], p = n.p;
          if (p.y < n.r) {
            const vy = p.y - n.q.y;
            p.y = n.r;
            n.q.y = p.y + vy * 0.3;                            // a dull, armoured bounce
            n.q.x += (p.x - n.q.x) * 0.06; n.q.z += (p.z - n.q.z) * 0.06; // friction on the stones
          }
          if (Math.abs(p.x) < ARENA.endZone + 1 && p.y < 1.05 + n.r && Math.abs(p.z) < 0.18 + n.r) {
            const sgn = Math.sign(n.q.z || p.z || 1);
            p.z = sgn * (0.18 + n.r); n.q.z = p.z + (p.z - n.q.z) * -0.2;
          }
          const lim = ARENA.half + ARENA.runoff + 1;
          if (Math.abs(p.x) > lim) { p.x = Math.sign(p.x) * lim; n.q.x = p.x; }
        }
      }
    }
    // sleep once it has come to rest
    let e = 0; for (const k in G.P) e += G.P[k].p.distanceToSquared(G.P[k].q);
    G.still = e < 2e-6 ? G.still + dt : 0;
    if (G.still > 1.2) G.sleep = true;
  }

  updateDown(dt, r) {
    if (!this.rag) this.knockOff(null, r);
    const G = this.rag;
    const prevY = G.P.chest.p.y;
    this.stepRag(dt);
    // impacts: dust and a scrape of sparks when armour meets stone
    const cv = G.P.chest.p.clone().sub(G.P.chest.q).length() * 120;
    if (G.P.chest.p.y <= G.P.chest.r + 0.02 && prevY > G.P.chest.r + 0.05) {
      this.dust({ x: G.P.chest.p.x, lane: G.P.chest.p.z, facing: 1, v: 4 }, 8, 2.2, G.P.chest.p.clone().setY(0.1));
      this.fx.burstSparks(G.P.chest.p.clone().setY(0.1), 12, 5, 0xffb070);
    } else if (cv > 3 && G.P.chest.p.y < 0.4 && Math.random() < 0.5) {
      this.fx.burstSparks(G.P.chest.p.clone().setY(0.08), 2, 3, 0xffa860, 0.8);
      if (Math.random() < 0.3) this.dust({ x: G.P.chest.p.x, lane: G.P.chest.p.z, facing: 1, v: cv }, 1, 1.2, G.P.chest.p.clone().setY(0.1));
    }
    // carry the model: rigid body frame × the rest pose captured at the fall
    const R = this.rider;
    const M = this.ragFrame(G.P).multiply(G.B0inv).multiply(G.M0);
    M.decompose(R.position, R.quaternion, R.scale);
    R.updateMatrixWorld(true);
    // head: turn the neck toward where the head particle swings
    const hl = R.worldToLocal(G.P.head.p.clone());
    const nl = this.neck.getWorldPosition(new THREE.Vector3()); R.worldToLocal(nl);
    const want = hl.sub(nl).normalize();
    const qn = new THREE.Quaternion().setFromUnitVectors(V(0, 1, 0), want);
    const spineQ = new THREE.Quaternion(); this.spine.getWorldQuaternion(spineQ);
    const rq = new THREE.Quaternion(); R.getWorldQuaternion(rq);
    // neck rotation expressed in the spine's frame
    const local = spineQ.clone().invert().multiply(rq).multiply(qn);
    this.neck.quaternion.slerp(local, Math.min(1, dt * 20));
    // arms reach for the hand particles
    this.solveArm(this.armR, R.worldToLocal(G.P.handR.p.clone()), V(0, -1, 0.5));
    this.solveArm(this.armL, R.worldToLocal(G.P.handL.p.clone()), V(0, -1, -0.5));
    // the weapon tumbles on its own stick
    const Wm = this.stickFrame(G.P.wBase.p, G.P.wTip.p).multiply(G.wFrame0inv).multiply(G.W0);
    Wm.decompose(this.weapon.position, this.weapon.quaternion, this.weapon.scale);
    // bike falls over and skids
    this.bikeDown = Math.min(1, this.bikeDown + dt * 2.5);
    const e = this.bikeDown * this.bikeDown;
    this.bike.rotation.x = this.bikeFallDir * 1.35 * e;
    this.bike.position.y = 0.15 * e;
    if (r.v > 0.5 && Math.random() < 0.8) {
      const p = this.root.position.clone(); p.y = 0.1;
      this.fx.burstSparks(p, 3, 4, 0xffa860, 1, V(-r.facing, 0.4, 0));
      if (Math.random() < 0.4) this.dust(r, 1, 1.2);
    }
  }

  // ------------------------------------------------------------ getting back up
  // getup: from where the ragdoll came to rest, rise to standing; walk: back to the
  // bike (the simulation moves the body); mount: lift the bike upright and get on.
  updateRecover(dt, r) {
    if (!this.rag) return;
    const R = this.rider, G = this.rag;
    const walkDir = Math.sign(r.x - (r.bodyX ?? r.x)) || r.facing;
    const out = r.lane > 0 ? 1 : -1;
    const standQ = new THREE.Quaternion().setFromEuler(new THREE.Euler(0, walkDir > 0 ? 0 : Math.PI, 0));
    const mirror = (walkDir > 0) !== (r.lane < 0) ? -1 : 1;
    const stand = V(r.bodyX ?? r.x, -0.19, r.lane + out * 0.7);
    if (r.act === 'getup') {
      if (!G.up) {
        G.up = { p: R.position.clone(), q: R.quaternion.clone() };
        this.legsSeat.visible = false; this.legsWalk.visible = true;
      }
      const k = Math.min(1, r.actT / (r.actDur || 1));
      const e = k * k * (3 - 2 * k);
      R.position.lerpVectors(G.up.p, stand, e);
      R.position.y += Math.sin(Math.PI * k) * 0.35;          // push up off the ground
      R.quaternion.slerpQuaternions(G.up.q, standQ, e);
      R.scale.set(1.06, 1.06, 1.06 * mirror);
      this.neck.quaternion.slerp(new THREE.Quaternion(), Math.min(1, dt * 6));
      this.walkPose(Math.sin(k * 3) * 0.2, 0.9 * (1 - e));    // knees bent while rising
      this.limpArms(dt, 0.4 + 0.4 * e);
    } else if (r.act === 'walk') {
      G.walkT = (G.walkT || 0) + dt;
      R.position.set(stand.x, stand.y + Math.abs(Math.sin(G.walkT * 6.5)) * 0.06, stand.z);
      R.quaternion.slerp(standQ, Math.min(1, dt * 8));
      R.scale.set(1.06, 1.06, 1.06 * mirror);
      this.neck.quaternion.slerp(new THREE.Quaternion(), Math.min(1, dt * 6));
      this.walkPose(Math.sin(G.walkT * 6.5) * 0.55, 0);
      this.limpArms(dt, 1, Math.sin(G.walkT * 6.5));
    } else if (r.act === 'mount') {
      const k = Math.min(1, r.actT / (r.actDur || 1));
      // lift the bike back up over the first half, then swing a leg over
      const lift = Math.min(1, k / 0.55), le = lift * lift * (3 - 2 * lift);
      this.bikeDown = 1 - le;
      this.bike.rotation.x = this.bikeFallDir * 1.35 * this.bikeDown * this.bikeDown;
      this.bike.position.y = 0.15 * this.bikeDown * this.bikeDown;
      R.position.set(stand.x, stand.y, stand.z);
      this.walkPose(0, 0.3 * le);
      this.limpArms(dt, 1);
      if (k >= 0.7) this.remount();
    }
  }

  walkPose(swing, bend) {
    this.walkLegs.forEach((L, i) => {
      const s = i ? -swing : swing;
      L.hipJ.rotation.z = s + bend * 0.9;
      L.knee.rotation.z = -Math.max(0, s) * 0.9 - bend * 1.6;
    });
  }
  limpArms(dt, up, swing = 0) {
    this.rider.updateMatrixWorld(true);
    const hR = V(0.1 + swing * 0.18, 0.95 + 0.15 * up, 0.42), hL = V(0.1 - swing * 0.18, 0.95 + 0.15 * up, -0.42);
    this.handS.update(hR, dt); this.shS.update(hL, dt);
    this.solveArm(this.armR, this.handS.v, V(0, -1, 0.5));
    this.solveArm(this.armL, this.shS.v, V(0, -1, -0.5));
  }

  // back in the saddle: undo the ragdoll and return weapon and shield to the hands
  remount() {
    const R = this.rider;
    this.bike.add(R); R.position.set(0, 0, 0); R.quaternion.identity(); R.scale.setScalar(1.06);
    this.legsSeat.visible = true; this.legsWalk.visible = false;
    this.neck.quaternion.identity();
    if (this.weapon.parent !== R) { this.weapon.parent && this.weapon.parent.remove(this.weapon); R.add(this.weapon); this.weapon.scale.set(1, 1, 1); }
    if (this.shield.parent !== R) {
      this.shield.parent && this.shield.parent.remove(this.shield);
      this.fx.debris.list = this.fx.debris.list.filter(d => d.obj !== this.shield);
      R.add(this.shield); this.shield.scale.setScalar(1); this.shield.visible = true;
    }
    this.bike.rotation.x = 0; this.bike.position.y = 0; this.bikeDown = 0;
    this.rag = null;
  }

  dust(r, n, size, at) {
    const p = at || new THREE.Vector3(r.x - r.facing * 0.8, 0.12, r.lane);
    for (let i = 0; i < n; i++) {
      this.fx.puff(p.clone().add(V((Math.random() - 0.5) * 0.6, 0, (Math.random() - 0.5) * 0.6)),
        V(-r.facing * (0.5 + Math.random()), 0.4 + Math.random() * 0.6, (Math.random() - 0.5) * 1.2), 0x4a4038, size * (0.3 + Math.random() * 0.3), 1.2 + Math.random(), 0.35, 2.2, 1.6);
    }
  }

  dispose() {
    this.scene.remove(this.root); this.scene.remove(this.capeMesh); this.scene.remove(this.charLight);
    if (this.pivot) this.scene.remove(this.pivot);
    this.fairing.forEach(g => g.parent && g.parent.remove(g));
    // free GPU memory: geometry, per-rider materials and their unique textures
    const geos = new Set(), mats = new Set();
    const collect = (root) => root.traverse(o => {
      if (!o.isMesh && !o.isPoints) return;
      if (o.geometry) geos.add(o.geometry);
      for (const m of [].concat(o.material)) if (m && !m.userData.outline) mats.add(m);
    });
    collect(this.root); collect(this.rider); collect(this.capeMesh); this.fairing.forEach(collect);
    geos.forEach(g => g.dispose());
    mats.forEach(m => { if (m.map && m.map.userData && m.map.userData.unique) m.map.dispose(); m.dispose(); });
    this.charLight.dispose && this.charLight.dispose();
  }
}
