// Bikes & Blades — entry point and game flow.
import * as THREE from 'three';
import { TICK, RIDERS, RIDER_ORDER, BOT_LEVELS, ROMAN, ARENA, FEATURES, WEAPONS, WEAPON_ORDER, ATTACKS, ATTACK_NAME, laneOffset } from './core/data.js';
document.documentElement.classList.toggle('no-dirs', !FEATURES.directions);
document.documentElement.classList.toggle('auto-gears', !FEATURES.manualGears);
import { createMatch, step, EMPTY_INPUT, tipHeight, bandOf, lateralGap } from './core/sim.js';
import { createBot, botThink } from './core/ai.js';
import { Input, connectedPads } from './core/input.js';
import { initMaps } from './render/materials.js';
import { Arena } from './render/arena.js';
import { FX } from './render/fx.js';
import { RiderView } from './render/riderModel.js';
import { Trail } from './render/fx.js';
import { CameraDirector } from './render/cameraDirector.js';
import { Post } from './render/post.js';
import { LOOK, PALETTE_LIST, hexToRgb01 } from './render/look.js';
import { Sfx } from './audio/sfx.js';
import { Hud } from './ui/hud.js';
import { encodeSnapshot, applySnapshot, smoothMirror, roomAvailable, RoomTransport, WsTransport, makeCode, roomName } from './net/net.js';

const $ = (s, r = document) => r.querySelector(s);
// each strike line has its own tell colour (glint at the tip on wind-up, and the trail)
const ZONE_COLOR = LOOK.zone;
const ATTACK_HELP = {
  thrust: 'Flick toward the rival, or just click. The couched point: quickest with the lance, and it gains most from speed.',
  smash: 'Flick down from a raised arm. Heavy and slow with the lance; the best blow on the helm.',
  cut: 'Flick up from a low guard. A rising blow from under the shield.',
  slash: 'Flick back toward yourself: a sweep across the tilt. Too low and it strikes the tilt (a foul).',
};
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const V = (x, y, z) => new THREE.Vector3(x, y, z);

// ------------------------------------------------------------------ settings
const SETTINGS_KEY = 'bikes-blades-settings-v1';
const settings = { master: 80, sfx: 90, quality: 'high', shake: 1, hints: 1, level: 1, p1: { rider: 'aldric', weapon: 'lance' }, p2: { rider: 'vorn', weapon: 'lance' }, relay: '', pixel: 1 };
try { Object.assign(settings, JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}')); } catch {}
function saveSettings() { try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch {} }
const params = new URLSearchParams(location.search);
if (params.get('quality')) settings.quality = params.get('quality');

// ------------------------------------------------------------------ engine setup
const canvas = $('#gl');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance', preserveDrawingBuffer: params.has('test') });
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.NoToneMapping;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(34, 16 / 9, 0.1, 900);
camera.position.set(0, 4, 20);
const director = new CameraDirector(camera);
const input = new Input();
const sfx = new Sfx();
const hud = new Hud();
let post, arena, fx;

function pixelRatio() { return Math.min(window.devicePixelRatio || 1, settings.quality === 'low' ? 1 : 1.75) * (settings.quality === 'low' ? 0.8 : 1); }
function resize() {
  const w = window.innerWidth, h = window.innerHeight;
  renderer.setPixelRatio(pixelRatio());
  renderer.setSize(w, h, false);
  camera.aspect = w / h; camera.updateProjectionMatrix();
  post && post.setSize(w, h, pixelRatio());
}
window.addEventListener('resize', resize);

// ------------------------------------------------------------------ app state
const app = {
  screen: 'loading', mode: null, state: null, views: [], bots: [], trails: [],
  lastEv: 0, acc: 0, paused: false, humans: [false, false], labels: ['', ''],
  attract: null, select: null, net: null, endT: 0, resultsShown: false,
  timeScale: +(params.get('speed') || 1), testBotP1: params.has('autoplay'),
};
window.__bb = app; // debug / test handle
app.renderer = renderer; app.scene = scene; app.camera = camera; app.director = director; app.hud = hud;
app.THREE = THREE; Object.defineProperty(app, 'fx', { get: () => fx });
app.emit = (e) => { e.id = 1e9 + Math.random(); handleEvent(e, app.state, true); }; // test/lookdev: fire an event's feedback
if (params.has('test')) renderer.debug.onShaderError = (gl, prog, vs, fs) => {
  const src = gl.getShaderSource(fs) || '';
  const name = (src.match(/#define SHADER_NAME (.*)/) || [])[1] || 'custom';
  const samplers = (src.match(/uniform sampler\w+ \w+/g) || []).join(', ');
  console.error('SHADER-FAIL VS=' + (gl.getShaderInfoLog(vs)||'').slice(0,300) + ' SRC=' + (gl.getShaderSource(vs)||'').split('\n').filter(l=>!l.startsWith('#')&&!l.startsWith('uniform')&&!l.startsWith('attribute')&&l.trim()).slice(-25).join(' / ').slice(0,900) + ' ' + name + ' | ' + gl.getProgramInfoLog(prog) + ' | ' + samplers.slice(0, 400) + ' | ' + (src.match(/#define NUM_\w+ \d+/g) || []).join(' '));
};

// ------------------------------------------------------------------ screens
const screens = ['loading', 'title', 'menu', 'select', 'lobby', 'howto', 'settings', 'pause', 'results'];
let backStack = [];
function show(name, push = false) {
  if (push && app.screen) backStack.push(app.screen); else if (!push) backStack = [];
  for (const s of screens) { const el = $('#s-' + s); if (el) el.hidden = s !== name; }
  app.screen = name;
  const el = $('#s-' + name);
  const first = el && (el.querySelector('.item') || el.querySelector('.cta') || el.querySelector('input, select, button'));
  if (first && name !== 'loading' && name !== 'title') { try { first.focus({ preventScroll: true }); } catch {} }
}
function back() {
  const prev = backStack.pop();
  sfx.play('ui');
  if (prev) { for (const s of screens) { const el = $('#s-' + s); if (el) el.hidden = s !== prev; } app.screen = prev; const f = $('#s-' + prev + ' .item, #s-' + prev + ' button'); f && f.focus(); }
  else show('menu');
}
function toast(msg, ms = 2600) {
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toast.h); toast.h = setTimeout(() => t.hidden = true, ms);
}

// ------------------------------------------------------------------ boot
async function boot() {
  const msg = $('#load-msg'), fill = $('#load-fill');
  const stage = async (text, pct, fn) => { msg.textContent = text; fill.style.width = pct + '%'; await new Promise(r => setTimeout(r, 16)); fn && fn(); };
  await stage('Forging iron and stone…', 10, () => initMaps());
  await stage('Raising the causeway…', 45, () => { arena = new Arena(scene, settings.quality); fx = new FX(scene); });
  await stage('Lighting the candles…', 75, () => {
    post = new Post(renderer, settings.quality);
    post.setPixel(!!settings.pixel, PALETTE_LIST.map(hexToRgb01), LOOK.pixelHeight, LOOK.dither);
    arena.buildEnvironment(renderer); arena.fx = fx; resize();
  });
  await stage('Summoning riders…', 90, () => startAttract());
  arena.onLightning = () => setTimeout(() => sfx.play('thunder'), 300 + Math.random() * 900);
  applySettings();
  fill.style.width = '100%';
  buildMenus();
  // compile shaders up front so the first frame doesn't hitch
  renderer.compile(scene, camera);
  if (app.touch) $('#s-title .press').textContent = 'Tap to begin';
  show('title');
  requestAnimationFrame(loop);
  if (params.has('autostart')) quickStart({ mode: 'bot' });
}

// ------------------------------------------------------------------ menus
function buildMenus() {
  // title: any key / click
  const goMenu = () => { if (app.screen !== 'title') return; sfx.unlock(); applySettings(); sfx.play('uiOk'); show('menu'); };
  $('#s-title').addEventListener('pointerdown', goMenu);
  // swallow the key so it doesn't also "click" the menu item that just got focus
  input.onKey((code, e) => { if (app.screen === 'title') { e.preventDefault(); goMenu(); } });

  $$('#s-menu .item').forEach(b => b.addEventListener('click', () => {
    sfx.unlock(); sfx.play('uiOk');
    const a = b.dataset.act;
    if (a === 'bot' || a === 'local' || a === 'online') openSelect(a);
    else if (a === 'howto') show('howto', true);
    else if (a === 'settings') show('settings', true);
  }));
  // how to: weapon list
  $('#howto-weapons').innerHTML = ATTACKS.map(z => `<li><b>${ATTACK_NAME[z]}.</b> ${ATTACK_HELP[z]}</li>`).join('');
  $('#ht-back').onclick = back; $('#st-back').onclick = () => { saveSettings(); back(); };
  // settings
  const bind = (id, key, num) => {
    const el = $('#' + id); el.value = String(settings[key]);
    el.addEventListener('input', () => { settings[key] = num ? +el.value : el.value; applySettings(); saveSettings(); });
  };
  bind('st-pixel', 'pixel', true);
  bind('st-master', 'master', true); bind('st-sfx', 'sfx', true); bind('st-quality', 'quality', false); bind('st-shake', 'shake', true); bind('st-hints', 'hints', true);
  // pause
  $$('#s-pause .item').forEach(b => b.addEventListener('click', () => {
    sfx.play('uiOk');
    const a = b.dataset.act;
    if (a === 'resume') setPaused(false);
    else if (a === 'howto') show('howto', true);
    else if (a === 'settings') show('settings', true);
    else if (a === 'quit') { setPaused(false); endMatch(); toMenu(); }
  }));
  // results
  $$('#s-results .item').forEach(b => b.addEventListener('click', () => {
    sfx.play('uiOk');
    const a = b.dataset.act;
    if (a === 'rematch') rematch();
    else if (a === 'reselect') { const m = app.mode; endMatch(); if (m === 'online-host' || m === 'online-guest') { leaveNet(); openSelect('online'); } else openSelect(m); }
    else { endMatch(); leaveNet(); toMenu(); }
  }));
  setupSelect();
  setupLobby();
}

function applySettings() {
  sfx.setVolumes(settings.master / 100, settings.sfx / 100);
  director.shakeScale = settings.shake;
  hud.showHints(!!settings.hints);
  if (post && post.quality !== settings.quality) { post.setQuality(settings.quality); renderer.shadowMap.enabled = true; resize(); }
  if (post && post.pixel !== !!settings.pixel) { post.setPixel(!!settings.pixel, null, LOOK.pixelHeight, LOOK.dither); resize(); }
}

function toMenu() {
  hud.show(false); hud.hideBanner();
  post && (post.fx.bars = 0, post.fx.desat = 0, post.fx.red = 0);
  if (!app.attract) startAttract();
  show('menu');
}

// keyboard / pad navigation for menus
function navMove(dir) {
  const el = $('#s-' + app.screen);
  if (!el || el.hidden) return;
  const items = $$('.item, .cta, .ghostbtn, .arrow, .seg button, input, select, summary', el).filter(b => b.offsetParent !== null && !b.disabled);
  if (!items.length) return;
  let i = items.indexOf(document.activeElement);
  i = i < 0 ? 0 : (i + dir + items.length) % items.length;
  items[i].focus(); sfx.play('ui');
}
input.onKey((code, e) => {
  if (app.screen === 'loading' || app.screen === 'title') return;
  const typing = document.activeElement && document.activeElement.tagName === 'INPUT' && document.activeElement.type !== 'range';
  if (app.screen === 'select' && !typing) { if (selectKey(code)) { e.preventDefault(); return; } }
  if (code === 'Escape' || (code === 'KeyP' && !typing)) {
    if (app.mode && !app.resultsShown && (app.screen === 'pause' || app.screen === null || app.screen === 'match')) { setPaused(!app.paused); return; }
    if (app.screen === 'howto' || app.screen === 'settings') { saveSettings(); back(); return; }
    if (app.screen === 'select' || app.screen === 'lobby') { leaveNet(); toMenu(); sfx.play('ui'); return; }
    return;
  }
  if (typing) return;
  if (['ArrowDown', 'KeyS'].includes(code) && app.screen !== 'match') { navMove(1); e.preventDefault(); }
  if (['ArrowUp', 'KeyW'].includes(code) && app.screen !== 'match') { navMove(-1); e.preventDefault(); }
});

// ------------------------------------------------------------------ select screen
function setupSelect() {
  const cards = [$('#sel-p1'), $('#sel-p2')];
  cards.forEach((card, i) => {
    $$('.rider .arrow', card).forEach(b => b.onclick = () => cycle(i, 'rider', +b.dataset.d));
    $$('.weapon .arrow', card).forEach(b => b.onclick = () => cycle(i, 'weapon', +b.dataset.d));
  });
  $$('#sel-diff button').forEach(b => b.onclick = () => { settings.level = +b.dataset.lvl; saveSettings(); renderSelect(); sfx.play('ui'); });
  $('#sel-go').onclick = () => selectGo();
  $('#sel-back').onclick = () => { leaveNet(); toMenu(); sfx.play('ui'); };
}
function cycle(i, what, d) {
  const S = app.select; if (!S) return;
  const p = S.picks[i];
  if (what === 'rider') { const k = RIDER_ORDER.indexOf(p.rider); p.rider = RIDER_ORDER[(k + d + RIDER_ORDER.length) % RIDER_ORDER.length]; }
  if (what === 'weapon') { const k = WEAPON_ORDER.indexOf(p.weapon || 'lance'); p.weapon = WEAPON_ORDER[(k + d + WEAPON_ORDER.length) % WEAPON_ORDER.length]; }
  S.ready[i] = false;
  sfx.play('ui');
  renderSelect(); rebuildPreview(i);
}
function openSelect(kind) {
  stopAttract();
  app.select = {
    kind, ready: [false, false],
    picks: [{ weapon: 'lance', ...settings.p1 }, { weapon: 'lance', ...(kind === 'bot' ? { rider: RIDER_ORDER[(RIDER_ORDER.indexOf(settings.p1.rider) + 2) % 4], weapon: settings.p2.weapon || 'lance' } : settings.p2) }],
    views: [null, null],
  };
  const S = app.select;
  $('#sel-title').textContent = kind === 'local' ? 'Two riders take the causeway' : 'Choose your rider';
  $('#sel-sub').textContent = kind === 'bot' ? 'Against the Hollow' : kind === 'online' ? 'Online duel' : 'Local duel';
  $('#sel-diff').hidden = kind !== 'bot';
  $('#sel-p2').hidden = kind === 'online';
  $('#sel-p2').classList.toggle('cpu', kind === 'bot');
  $('#sel-p2 .who').textContent = kind === 'bot' ? 'The Hollow' : 'Player Two';
  $('#sel-go').textContent = kind === 'online' ? 'Continue' : 'Ride';
  $('#sel-help').innerHTML = kind === 'local'
    ? 'Player one: <kbd>A</kbd><kbd>D</kbd> rider, <kbd>W</kbd><kbd>S</kbd> weapon, <kbd>Space</kbd> ready.<br>Player two: <kbd>←</kbd><kbd>→</kbd> rider, <kbd>↑</kbd><kbd>↓</kbd> weapon, <kbd>O</kbd> ready.'
    : '<kbd>A</kbd><kbd>D</kbd> rider · <kbd>W</kbd><kbd>S</kbd> weapon · <kbd>Enter</kbd> to ride.';
  rebuildPreview(0); rebuildPreview(1);
  director.setMode('select');
  renderSelect();
  show('select');
  $('#sel-go').focus({ preventScroll: true });
}
function renderSelect() {
  const S = app.select; if (!S) return;
  [$('#sel-p1'), $('#sel-p2')].forEach((card, i) => {
    const p = S.picks[i], R = RIDERS[p.rider];
    $('.rname', card).textContent = R.name; $('.rtitle', card).textContent = R.title; $('.rlore', card).textContent = R.lore;
    const Wp = WEAPONS[p.weapon || 'lance'];
    $('.wname', card).textContent = Wp.name;
    $('.wblurb', card).textContent = Wp.id === 'lance' ? 'Heavy and long. One attack per course; it breaks on a clean hit.' : 'Light and short. Two strokes per course; ride close to the tilt.';
    card.classList.toggle('ready', S.kind === 'local' && S.ready[i]);
  });
  $$('#sel-diff button').forEach(b => b.setAttribute('aria-checked', String(+b.dataset.lvl === settings.level)));
}
function rebuildPreview(i) {
  const S = app.select; if (!S) return;
  if (S.views[i]) S.views[i].dispose();
  if (S.kind === 'online' && i === 1) { S.views[1] = null; return; }
  const p = S.picks[i];
  const v = new RiderView(scene, fx, RIDERS[p.rider], p.weapon || 'lance', i);
  S.views[i] = v;
  S.fake = S.fake || [0, 1].map(k => ({ x: k ? 1.45 : -1.45, v: 0, facing: k ? -1 : 1, lane: ARENA.lanes[k], act: 'free', actT: 0, throttle: 0, perfectT: 0, engine: 75, fairing: 45, zone: 'horiz', drawn: 1, shield: 100, helmet: 100, sword: 100 }));
}
function selectKey(code) {
  const S = app.select; if (!S) return false;
  if (S.kind === 'local') {
    const map = { KeyA: [0, 'rider', -1], KeyD: [0, 'rider', 1], KeyW: [0, 'weapon', -1], KeyS: [0, 'weapon', 1], ArrowLeft: [1, 'rider', -1], ArrowRight: [1, 'rider', 1], ArrowUp: [1, 'weapon', -1], ArrowDown: [1, 'weapon', 1] };
    if (map[code]) { cycle(...map[code]); return true; }
    if (code === 'Space') { S.ready[0] = !S.ready[0]; sfx.play('uiOk'); renderSelect(); if (S.ready[0] && S.ready[1]) selectGo(); return true; }
    if (code === 'KeyO') { S.ready[1] = !S.ready[1]; sfx.play('uiOk'); renderSelect(); if (S.ready[0] && S.ready[1]) selectGo(); return true; }
    if (code === 'Enter') { selectGo(); return true; }
    return false;
  }
  const focusInCard = document.activeElement && document.activeElement.closest && document.activeElement.closest('.seg');
  if (focusInCard) return false;
  const map = { KeyA: ['rider', -1], KeyD: ['rider', 1], ArrowLeft: ['rider', -1], ArrowRight: ['rider', 1], KeyW: ['weapon', -1], KeyS: ['weapon', 1], ArrowUp: ['weapon', -1], ArrowDown: ['weapon', 1] };
  if (map[code]) { cycle(0, ...map[code]); return true; }
  if (code === 'Enter' || code === 'Space') {
    const a = document.activeElement;
    if (a && (a.id === 'sel-back' || (a.closest && a.closest('.seg')))) return false; // let the focused control act
    selectGo(); return true;
  }
  return false;
}
function selectGo() {
  const S = app.select; if (!S) return;
  sfx.unlock(); sfx.play('uiOk');
  settings.p1 = { ...S.picks[0] };
  if (S.kind === 'local' || S.kind === 'bot') settings.p2 = { ...settings.p2, weapon: S.picks[1].weapon };
  if (S.kind === 'local') settings.p2 = { ...S.picks[1] };
  saveSettings();
  clearPreview();
  if (S.kind === 'online') { show('lobby'); return; }
  startMatch({ mode: S.kind, riders: [S.picks[0].rider, S.picks[1].rider], weapons: [S.picks[0].weapon || 'lance', S.picks[1].weapon || 'lance'], level: settings.level });
}
function clearPreview() {
  const S = app.select; if (!S) return;
  S.views.forEach(v => v && v.dispose()); S.views = [null, null];
}

// ------------------------------------------------------------------ attract mode (title / menu backdrop)
function startAttract() {
  stopMatchViews();
  const rs = [...RIDER_ORDER].sort(() => Math.random() - 0.5);
  const st = createMatch({ riders: [rs[0], rs[1]], mode: 'attract', weapons: [Math.random() < 0.75 ? 'lance' : 'sword', Math.random() < 0.75 ? 'lance' : 'sword'] });
  st.phase = 'fight'; st.coursesMax = 99;
  st.riders[0].x = -12; st.riders[1].x = 12; // meet right behind the logo
  app.attract = { state: st, bots: [createBot(0, 2, Math.random() * 1e6 | 0), createBot(1, 2, Math.random() * 1e6 | 0)], lastEv: 0 };
  app.views = st.riders.map((r, i) => new RiderView(scene, fx, RIDERS[r.id], r.weapon, i));
  app.trails = makeTrails(st);
  app.state = st; app.lastEv = 0;
  director.focus = -1;
  director.setMode('attract');
}
function stopAttract() {
  if (!app.attract) return;
  app.attract = null;
  stopMatchViews();
}
function stopMatchViews() {
  app.views.forEach(v => v.dispose()); app.views = [];
  app.trails.forEach(t => t.mesh.parent && t.mesh.parent.remove(t.mesh)); app.trails = [];
  fx && fx.debris.clear();
  sfx.silenceEngines();
}
function makeTrails(st) {
  return st.riders.map(r => new Trail(scene, new THREE.Color(0xff8a40), 14));
}

// ------------------------------------------------------------------ match lifecycle
function startMatch(cfg) {
  stopAttract(); stopMatchViews();
  app.mode = cfg.mode;
  app.cfg = cfg;
  const st = createMatch({ riders: cfg.riders, weapons: cfg.weapons || ['lance', 'lance'], mode: cfg.mode });
  input.setCapture(true);
  app.state = st; app.lastEv = 0; app.acc = 0; app.resultsShown = false; app.endT = 0;
  app.bots = [];
  if (cfg.mode === 'bot') app.bots[1] = createBot(1, cfg.level ?? 1, (Math.random() * 1e6) | 0);
  if (app.testBotP1 && cfg.mode === 'bot') app.bots[0] = createBot(0, 2, 77);
  app.humans = cfg.mode === 'bot' ? [true, false] : cfg.mode === 'local' ? [true, true] : cfg.mode === 'online-host' ? [true, false] : cfg.mode === 'online-guest' ? [false, true] : [false, false];
  app.labels = cfg.mode === 'bot' ? ['You', BOT_LEVELS[cfg.level ?? 1].name] : cfg.mode === 'local' ? ['P1', 'P2'] : cfg.mode === 'online-host' ? ['You', 'Rival'] : ['Rival', 'You'];
  app.views = st.riders.map((r, i) => new RiderView(scene, fx, RIDERS[r.id], r.weapon, i));
  app.trails = makeTrails(st);
  director.focus = app.humans[0] && !app.humans[1] ? 0 : app.humans[1] && !app.humans[0] ? 1 : -1;
  hud.setup(st, app.labels, app.humans, app.touch ? '' : hintFor(cfg.mode));
  hud.show(true); hud.hideBanner();
  $('#touch').hidden = !app.touch;
  hud.setNet(cfg.mode.startsWith('online') ? 'Online' : '');
  post.fx.bars = params.has('board') ? 0 : 1; post.fx.desat = 0; post.fx.red = 0;
  director.setMode('intro');
  for (const s of screens) { const el = $('#s-' + s); if (el) el.hidden = true; }
  app.screen = 'match';
  sfx.play('toll', 0, 0.75);
  document.activeElement && document.activeElement.blur && document.activeElement.blur();
}
// The strike gate and the aim mark. The gate is a band of light on the rival's
// lane: release the attack as the rival rides into it and the blow lands at the
// edge of reach. The aim mark sits on the rival at the height your weapon tip
// will reach, coloured by what that height scores (helm, body, saddle, foul).
const BAND_COLOR = { tilt: 0xab2629, horse: 0xab2629, saddle: 0xe6603e, body: 0xeee4cf, helm: 0xf6dcb4, over: 0x5e5759 };
let cueMeshes = null;
function updateStrikeCues(st) {
  if (!cueMeshes) {
    cueMeshes = [0, 1].map(() => {
      const g = new THREE.Group();
      const mat = new THREE.MeshBasicMaterial({ color: 0xeee4cf, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
      const bar = new THREE.Mesh(new THREE.PlaneGeometry(0.28, 2.4), mat); bar.rotation.x = -Math.PI / 2; bar.position.y = 0.04; g.add(bar);
      const post = new THREE.Mesh(new THREE.PlaneGeometry(0.1, 2.6), mat); post.position.set(0, 1.3, 1.25); g.add(post);
      const post2 = post.clone(); post2.position.z = -1.25; g.add(post2);
      g.userData.mat = mat; g.visible = false; scene.add(g);
      const amat = new THREE.MeshBasicMaterial({ color: 0xeee4cf, transparent: true, opacity: 0.9, depthTest: false, depthWrite: false, fog: false });
      const aim = new THREE.Group(); aim.visible = false; scene.add(aim);
      const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.2, 0), amat); gem.renderOrder = 20; aim.add(gem);
      const ring = new THREE.Mesh(new THREE.RingGeometry(0.34, 0.44, 24), amat); ring.renderOrder = 20; aim.add(ring);
      aim.material = amat;
      g.userData.aim = aim;
      return g;
    });
  }
  st.riders.forEach((r, i) => {
    const g = cueMeshes[i], o = st.riders[1 - i], aim = g.userData.aim;
    r.cue = ''; r.cueBand = '';
    const approaching = (o.x - r.x) * r.facing > 0 && (r.x - o.x) * o.facing > 0;
    const Wp = WEAPONS[r.weapon];
    const armed = r.attacksLeft > 0 && !(r.weapon === 'lance' && r.lanceBroken);
    const show = !!app.mode && app.humans[i] && st.phase === 'fight' && approaching && !['down', 'getup', 'walk', 'mount'].includes(r.act) && !app.camOverride;
    if (!show) { g.visible = false; aim.visible = false; return; }
    const gap = Math.abs(o.x - r.x);
    // aim mark: where the tip will land on the rival for the attack being drawn (or a thrust)
    const atk = input.pendingGesture(r.facing) || 'thrust';
    const y = tipHeight(r, atk);
    let band = bandOf(y);
    if (band === 'helm' && y >= 2.12 && y <= 2.26) band = 'sight';
    r.cueBand = band;
    const reachOk = lateralGap(r, o) <= Wp.reach;
    aim.visible = gap < 30;
    aim.position.set(o.x, y, o.lane + Math.sign(o.lane || 1) * -0.4);
    aim.children[1].rotation.z = performance.now() / 600;
    aim.material.color.setHex(reachOk ? (BAND_COLOR[band === 'sight' ? 'helm' : band]) : 0x5e5759);
    aim.scale.setScalar(band === 'sight' ? 1.25 : 1);
    if (!reachOk) r.cueBand = 'reach';
    // the gate
    if (!armed) { g.visible = false; return; }
    const closing = r.v + o.v;
    const a = Wp.attacks[atk];
    const markDist = Wp.fwd * 0.6 + closing * (a.windup + Wp.active * 0.3);
    if (gap > markDist + 16) { g.visible = false; return; }
    const busy = r.act === 'windup' || r.act === 'active';
    const inWindow = gap <= markDist && gap > markDist - Math.max(1.6, closing * 0.12);
    r.cue = busy ? '' : inWindow ? 'now' : gap < markDist ? 'late' : 'ready';
    g.visible = true;
    g.position.set(r.x + r.facing * markDist, 0, o.lane);
    const m = g.userData.mat;
    m.color.setHex(r.cue === 'now' ? 0xe6603e : 0xeee4cf);
    m.opacity = busy ? 0.25 : r.cue === 'now' ? 0.95 : r.cue === 'late' ? 0.15 : 0.35 + 0.15 * Math.sin(performance.now() / 120);
    g.scale.setScalar(r.cue === 'now' ? 1.15 : 1);
  });
}

function hintFor(mode) {
  const k = (s) => s.split(' ').map(x => `<kbd>${x}</kbd>`).join('');
  if (mode === 'local') return `P1 ${k('W')} gas · ${k('S')} brake / turn · ${k('A')}${k('D')} line · mouse aim · hold click + flick = attack · right click shield  ·  P2 ${k('↑ ↓ ← →')} · ${k('I J K L')} aim · ${k('U')} attack · ${k('O')} shield`;
  return `${k('W')} gas · ${k('S')} brake, then turn at the end · ${k('A')}${k('D')} line to the tilt · mouse = lance height and angle · hold click, flick, release = attack · right click = shield (on impact = parry) · ${k('Esc')}`;
}
function endMatch() {
  app.mode = null; app.state = null; app.bots = [];
  input.setCapture(false);
  $('#touch').hidden = true;
  stopMatchViews();
  hud.show(false); hud.hideBanner();
  post.fx.bars = 0; post.fx.desat = 0; post.fx.red = 0;
}
function rematch() {
  const cfg = app.cfg;
  if (app.mode === 'online-host' && app.net) { netHostStart(); return; }
  if (app.mode === 'online-guest') { toast('Waiting for the host to call a rematch…'); return; }
  endMatch(); startMatch(cfg);
}
function setPaused(p) {
  if (!app.mode) return;
  if (app.mode.startsWith('online')) {
    // online duels never pause; the menu is only a way out
    if (p) { show('pause'); app.screen = 'pause'; } else { $('#s-pause').hidden = true; app.screen = 'match'; }
    app.paused = false;
    return;
  }
  app.paused = p;
  if (p) { show('pause'); sfx.silenceEngines(); } else { for (const s of screens) { const el = $('#s-' + s); if (el) el.hidden = true; } app.screen = 'match'; }
}
function quickStart(o = {}) {
  startMatch({ mode: o.mode || 'bot', riders: o.riders || ['aldric', 'vorn'], weapons: o.weapons || ['lance', 'lance'], level: o.level ?? 1 });
}
app.quickStart = quickStart;

// ------------------------------------------------------------------ online
function setupLobby() {
  $('#lb-relay').value = settings.relay || '';
  $('#lb-relay').addEventListener('change', () => { settings.relay = $('#lb-relay').value.trim(); saveSettings(); });
  $('#lb-input').addEventListener('input', e => { e.target.value = e.target.value.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 4); });
  $('#lb-input').addEventListener('keydown', e => { if (e.key === 'Enter') $('#lb-join').click(); });
  $('#lb-back').onclick = () => { leaveNet(); toMenu(); sfx.play('ui'); };
  $('#lb-host').onclick = async () => {
    sfx.play('uiOk');
    const code = makeCode();
    const t = await openTransport(code);
    if (!t) return;
    $('#lb-code').hidden = false; $('#lb-code').textContent = code;
    status(`Share the code ${code}. Waiting for a challenger…`);
    app.net = { role: 'host', t, code, guest: null, guestInput: { ...EMPTY_INPUT }, match: 0 };
    const sel = settings.p1;
    t.send({ role: 'host', rider: sel.rider, phase: 'wait', s: null });
    t.onPeer((id, st) => {
      if (!app.net || st.role !== 'guest') return;
      if (!app.net.guest) {
        app.net.guest = { id, rider: st.rider, weapon: st.weapon || 'lance' };
        status('A challenger arrives…');
        setTimeout(() => netHostStart(), 600);
      }
      if (id === app.net.guest.id && st.i) app.net.guestInput = st.i;
    });
    t.onLeave((id) => {
      if (!app.net || (app.net.guest && id !== app.net.guest.id && id !== '*')) return;
      if (app.mode === 'online-host') { toast('Your rival has left the causeway.'); endMatch(); leaveNet(); toMenu(); }
      else if (app.net) { app.net.guest = null; status('Waiting for a challenger…'); }
    });
  };
  $('#lb-join').onclick = async () => {
    sfx.play('uiOk');
    const code = $('#lb-input').value.trim().toUpperCase();
    if (code.length !== 4) { status('Enter the four-letter code from the host.'); return; }
    const t = await openTransport(code);
    if (!t) return;
    status('Looking for the host…');
    app.net = { role: 'guest', t, code, match: 0, host: null };
    const sel = settings.p1;
    const sendInput = (i) => t.send({ role: 'guest', rider: sel.rider, weapon: sel.weapon || 'lance', i });
    sendInput({ ...EMPTY_INPUT });
    app.net.sendInput = sendInput;
    t.onPeer((id, st) => {
      if (!app.net || st.role !== 'host') return;
      app.net.host = id;
      if (st.phase === 'play' && st.m && st.m !== app.net.match && st.cfg) {
        app.net.match = st.m;
        startMatch({ mode: 'online-guest', riders: st.cfg.riders, weapons: st.cfg.weapons });
        app.state.phase = 'intro';
      } else if (st.phase === 'wait') status('Host found. Waiting for the duel to begin…');
      if (st.s && app.mode === 'online-guest' && st.m === app.net.match) { applySnapshot(app.state, st.s); app.net.lastSnap = performance.now(); }
    });
    t.onLeave((id) => {
      if (!app.net) return;
      if (id === app.net.host || id === '*') { toast('The host has left the causeway.'); if (app.mode) endMatch(); leaveNet(); toMenu(); }
    });
    setTimeout(() => { if (app.net && app.net.role === 'guest' && !app.net.host) status(`No duel found for ${code} yet. Check the code, or wait for the host.`); }, 6000);
  };
}
function status(s) { $('#lb-status').textContent = s; }
async function openTransport(code) {
  leaveNet();
  status('Connecting…');
  const room = await roomAvailable();
  try {
    if (room) return await RoomTransport.open(room, roomName(code));
    const url = settings.relay || (location.protocol.startsWith('http') && location.hostname ? (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host : '');
    if (!url) { status('Online duels need the shared Claude artifact or the bundled relay server (npm run serve). See Self-hosted relay below.'); return null; }
    return await WsTransport.open(url, roomName(code));
  } catch (e) {
    status((e && e.message) || 'Could not connect.');
    return null;
  }
}
function netHostStart() {
  const N = app.net; if (!N || !N.guest) return;
  N.match = (N.match || 0) + 1;
  N.lastSent = 0;
  const cfg = { mode: 'online-host', riders: [settings.p1.rider, N.guest.rider], weapons: [settings.p1.weapon || 'lance', N.guest.weapon || 'lance'] };
  if (app.mode) endMatch();
  startMatch(cfg);
  N.t.send({ role: 'host', phase: 'play', m: N.match, cfg: { riders: cfg.riders, weapons: cfg.weapons }, s: encodeSnapshot(app.state, 0) });
}
function leaveNet() {
  if (app.net) { try { app.net.t.close(); } catch {} app.net = null; }
  $('#lb-code').hidden = true; status('');
}

// ------------------------------------------------------------------ events → feel
const tmpV = new THREE.Vector3();
function hitPoint(e, st) {
  const d = st.riders[e.d ?? 0];
  return V(e.x, e.y, d ? d.lane * 0.35 : 0);
}
function screenPos(p) { const v = p.clone().project(camera); return new THREE.Vector2(v.x * 0.5 + 0.5, v.y * 0.5 + 0.5); }
function panOf(x) { const v = V(x, 1, 0).project(camera); return v.x; }

function handleEvent(e, st, live) {
  const quiet = !live; // attract mode: lighter feedback
  switch (e.type) {
    case 'swing': {
      sfx.play(e.z === 'over' || e.c > 0.3 ? 'swingHeavy' : 'swing', panOf(st.riders[e.r].x));
      if (e.c > 0.3) { director.punch(1.5); }
      break;
    }
    case 'windup': {
      // a glint telegraphs the line of the coming blow: ember high, ice low
      const v = app.views[e.r]; if (!v) break;
      const tip = new THREE.Vector3(), base = new THREE.Vector3();
      v.weaponPoints(base, tip);
      const col = ZONE_COLOR[e.z] || 0xffb050;
      fx.flare(tip, col, 1.1, 0.22, 1);
      fx.flare(tip, 0xffffff, 0.45, 0.12, 1);
      break;
    }
    case 'hit': {
      const p = hitPoint(e, st);
      const heavy = e.dmg > 30 || e.sight;
      fx.burstSparks(p, Math.round(26 + e.dmg * 2.2), 7 + e.dmg * 0.25, LOOK.fx.spark, 1, V(st.riders[e.a].facing * (e.z === 'back' ? -1 : 1), 0.3, 0));
      fx.burstSparks(p, Math.round(14 + e.dmg), 4.5, LOOK.fx.ichor, 0.8, null, 0.9); // ichor
      fx.flare(p, 0xcc3a2e, heavy ? 2.6 : 1.6, 0.16);
      fx.lights.flash(p, 0xd8402c, heavy ? 70 : 40, 0.25);
      if (heavy) fx.sigils.spawn(p, LOOK.fx.sigil, 1.8, 0.4);
      for (let i = 0; i < 6; i++) fx.puff(p, V((Math.random() - 0.5) * 3, Math.random() * 2, (Math.random() - 0.5) * 2), 0x2a201c, 0.3, 0.8, 0.4, 2.5);
      director.shake(quiet ? 0.12 : 0.32 + e.dmg * 0.012 + (heavy ? 0.2 : 0));
      director.punch(heavy ? 3 : 1.6);
      if (!quiet) post.kick({ aberration: heavy ? 0.012 : 0.006, zoom: heavy ? 0.06 : 0.025, center: screenPos(p) });
      app.views[e.d] && app.views[e.d].onHit({ ...e, dir: st.riders[e.a].facing }, true);
      sfx.play(e.band === 'saddle' || e.band === 'horse' ? 'hitLow' : 'hit', panOf(e.x), heavy ? 1.2 : 1);
      if (e.band === 'helm') sfx.play('block', panOf(e.x)); // bell-ring of steel on the helm
      if (e.shield) sfx.play('block', panOf(e.x), 0.7);
      arena.excite = Math.min(1.2, arena.excite + 0.25);
      break;
    }
    case 'block': {
      const p = hitPoint(e, st);
      fx.burstSparks(p, 50, 9, LOOK.fx.spark, 1.1);
      fx.flare(p, 0xfff0d0, 1.8, 0.12);
      fx.rings.spawn(p, 0xd9cdb5, 1.6, 0.25);
      fx.lights.flash(p, 0xeadcc0, 35, 0.18);
      director.shake(quiet ? 0.08 : 0.2);
      sfx.play('block', panOf(e.x));
      if (e.p > 0 && !quiet) hud.callout('Through the guard', 'small', 0.9);
      break;
    }
    case 'parry': {
      const p = hitPoint(e, st);
      fx.burstSparks(p, 90, 12, LOOK.fx.parry, 1.2);
      fx.flare(p, 0xeee4cf, 3.5, 0.3);
      fx.sigils.spawn(p, LOOK.fx.parry, 2.4, 0.6, { spin: 3 });
      setTimeout(() => fx.sigils.spawn(p, LOOK.fx.sigil, 3.4, 0.7, { spin: -2 }), 70);
      fx.lights.flash(p, 0xeadcc0, 90, 0.4, 12);
      director.shake(0.4); director.punch(4);
      if (!quiet) { post.kick({ aberration: 0.016, zoom: 0.09, flash: 0.18, center: screenPos(p) }); post.fx.desat = 0.6; setTimeout(() => post.fx.desat = 0, 650); hud.callout('Parried', 'ember'); }
      sfx.play('parry', panOf(e.x));
      app.views[e.a] && app.views[e.a].onHit(e, false);
      break;
    }
    case 'guardbreak': {
      const p = hitPoint(e, st);
      fx.burstSparks(p, 70, 10, LOOK.fx.spark, 1.2);
      fx.rings.spawn(p, 0xcc3a2e, 2.4, 0.3);
      director.shake(0.45); director.punch(3);
      sfx.play('block', panOf(e.x)); sfx.play('thud', panOf(e.x));
      if (!quiet) { hud.callout('Guard broken', 'blood'); post.kick({ aberration: 0.012, zoom: 0.05, center: screenPos(p) }); }
      break;
    }
    case 'clash': {
      const p = V(e.x, e.y, 0);
      fx.burstSparks(p, 120, 13, LOOK.fx.clash, 1.3);
      fx.sigils.spawn(p, LOOK.fx.clash, 1.6, 0.35, { spin: 4 });
      fx.rings.spawn(p, 0xffffff, 3.6, 0.35);
      fx.flare(p, 0xffffff, 3, 0.2);
      fx.lights.flash(p, 0xffffff, 80, 0.3, 12);
      director.shake(0.5); director.punch(3.5);
      sfx.play('clang', panOf(e.x));
      if (!quiet) { hud.callout('Steel meets steel', 'small', 1.0); post.kick({ aberration: 0.014, zoom: 0.07, flash: 0.1, center: screenPos(p) }); }
      break;
    }
    case 'poisebreak': if (!quiet) hud.callout('Staggered', 'small', 0.9); break;
    case 'partBreak': {
      sfx.play('break', panOf(e.x));
      if (!quiet && e.part === 'fairing') hud.callout('Fairing shattered', 'ember small', 1.1);
      director.shake(0.3);
      break;
    }
    case 'shift': {
      const r = st.riders[e.r];
      const p = V(r.x - r.facing * 1.3, 0.75, r.lane);
      if (e.q === 'perfect') {
        sfx.play('boost', panOf(e.x));
        fx.flare(p, 0xff6a2a, 2.0, 0.25);
        fx.sigils.spawn(p, LOOK.fx.ember, 1.4, 0.35, { normal: V(1, 0, 0), spin: 8 });
        if (live && app.humans[e.r]) hud.callout('Perfect shift', 'ember small', 0.8);
      } else if (e.q === 'early') {
        sfx.play('thud', panOf(e.x), 0.4);
        for (let i = 0; i < 6; i++) fx.puff(p, V(-r.facing * 1.5, 0.6, (Math.random() - 0.5)), 0x1a1614, 0.3, 1.2, 0.6, 3);
        if (live && app.humans[e.r]) hud.callout('Bogged', 'small', 0.7);
      } else sfx.play('ui', panOf(e.x));
      break;
    }
    case 'dent': case 'equipBreak': {
      const v = app.views[e.r];
      v && v.onEquip(e, st.riders[e.r]);
      const broke = e.type === 'equipBreak';
      sfx.play(broke ? 'break' : 'block', panOf(e.x));
      if (broke) director.shake(0.35);
      if (live) {
        const who = app.humans[e.r] ? '' : (app.humans[1 - e.r] ? 'Foe ' : RIDERS[st.riders[e.r].id].name.split(' ').pop() + ': ');
        const txt = { helmet: broke ? 'helm knocked away' : 'helm dented', shield: broke ? 'shield split' : 'shield cracked', sword: broke ? 'blade broken' : 'blade chipped' }[e.item];
        hud.callout((who + txt).replace(/^./, c => c.toUpperCase()), broke ? 'blood small' : 'small', 1.0);
      }
      break;
    }
    case 'cancel': break;
    case 'break': {
      // the lance shatters: splinters, a burst of pale light
      const v = app.views[e.r];
      v && v.breakLance(st.riders[e.r]);
      const p = V(e.x, e.y, 0);
      fx.burstSparks(p, 60, 10, 0xe8d6b0, 1.1);
      fx.rings.spawn(p, 0xeee4cf, 2.2, 0.3);
      sfx.play('break', panOf(e.x));
      director.shake(0.35);
      break;
    }
    case 'score': {
      if (quiet) break;
      const who = whoName(e.r, st);
      const txt = { body: 'spear broken on the body · +1', helm: 'spear broken on the helm · +2', sight: 'on the sight of the helm · +' + e.pts, coronel: 'coronel to coronel · +3', unhorse: 'unhorses the rival · +3' }[e.kind] || ('+' + e.pts);
      const sword = st.riders[e.r].weapon === 'sword' && e.kind !== 'unhorse' && e.kind !== 'coronel';
      hud.judge(e.r, (who + ' — ' + (sword ? txt.replace('spear broken on', 'clean stroke to') : txt)), e.kind === 'sight' || e.kind === 'unhorse' ? 'gold' : 'bone');
      break;
    }
    case 'foul': {
      const who = whoName(e.r, st);
      const what = { tilt: e.by === 'bike' ? 'rode against the tilt' : 'struck the tilt', horse: 'struck the horse', saddle: 'broke on the saddle', behind: 'struck from behind', falseStart: 'false start' }[e.kind] || e.kind;
      const pen = e.dq ? 'disqualified' : e.pen ? e.pen + (Math.abs(e.pen) === 1 ? ' spear' : ' spears') : 'warning';
      sfx.play('thud', panOf(e.x), 0.6);
      if (!quiet) hud.judge(e.r, `Foul: ${who} ${what} · ${pen}`, 'blood');
      if (e.kind === 'tilt') fx.burstSparks(V(e.x, ARENA.tiltH, 0), 50, 7, 0xffb060, 1);
      break;
    }
    case 'glance': if (!quiet) hud.judge(e.a, whoName(e.a, st) + (e.low ? ' — too low, no score' : ' — a glancing hit, no break'), 'dim'); sfx.play('block', panOf(e.x), 0.6); break;
    case 'miss': if (!quiet && app.humans[e.r]) hud.judge(e.r, e.late ? 'Too late — the rival has passed' : 'Over the head — a miss', 'dim'); break;
    case 'coronel': if (!quiet) hud.callout('Coronel to coronel', 'gold', 1.6); break;
    case 'courseEnd': if (!quiet) hud.setCourse(Math.min(e.n + 1, st.coursesMax), st.coursesMax); break;
    case 'extraCourse': if (!quiet) { hud.callout('Level on points · one more course', 'gold', 2.0); hud.setCourse(e.n, st.coursesMax); } break;
    case 'judgement': break;
    case 'skid': sfx.play('skid', panOf(e.x), 1.3); if (live && app.humans[e.r]) hud.callout('Skid turn', 'small', 0.7); break;
    case 'turned':
      if (e.fresh && app.views[e.r]) { app.views[e.r].freshLance(); app.views[e.r].resetEquipment(); }
      if (live && app.humans[e.r]) sfx.play('draw', panOf(e.x), 0.8);
      break;
    case 'crossing':
      // the approach slows down: a held breath before steel
      director.punch(2.2);
      post.fx.desat = Math.max(post.fx.desat, 0.35); setTimeout(() => { if (post.fx.desat <= 0.35) post.fx.desat = 0; }, 700);
      sfx.play('toll', panOf(e.x), 0.35);
      break;
    case 'spent':
      if (live && app.humans[e.r] && performance.now() - (app.spentAt || 0) > 1400) {
        app.spentAt = performance.now();
        const r = st.riders[e.r];
        hud.callout(r.weapon === 'lance' ? (r.lanceBroken ? 'Lance broken · a new one at the end' : 'Lance spent · turn at the end') : 'Strokes spent · turn at the end', 'small', 1.0);
      }
      break;
    case 'rearm':
      if (app.humans[e.r]) { sfx.play('draw', panOf(e.x), 0.8); if (live) hud.callout('Blade ready', 'gold small', 0.7); }
      break;
    case 'turn': sfx.play('skid', panOf(e.x)); break;
    case 'wall': {
      sfx.play('thud', panOf(e.x), 0.8);
      const r = st.riders[e.r];
      fx.burstSparks(V(r.x + r.facing * 1, 0.8, r.lane), 30, 6, 0xffb060);
      director.shake(0.3);
      break;
    }
    case 'ko': onKO(e, st, live); break;
    case 'unhorse': {
      // thrown, not beaten: the light falls on the fallen, then the long walk back
      const loser = st.riders[e.r];
      const fall = V(loser.x, 0.05, loser.lane);
      sfx.play('thud', panOf(e.x), 1.3); sfx.play('toll', 0, 0.5);
      director.shake(0.7);
      fx.pillars.spawn(fall, 0xeee4cf, 2.6);
      fx.sigils.spawn(fall.clone().setY(0.06), LOOK.fx.sigil, 3.6, 2.0, { normal: V(0, 1, 0), spin: 0.8, intensity: 1.4 });
      for (let i = 0; i < 30; i++) fx.ember(fall.clone().add(V((Math.random() - 0.5) * 2, Math.random() * 2, (Math.random() - 0.5) * 2)), V((Math.random() - 0.5) * 1.5, 1 + Math.random() * 2, (Math.random() - 0.5) * 1.5), Math.random() < 0.5 ? 0xab2629 : 0xeee4cf, 0.08, 2.2);
      if (live) {
        post.kick({ aberration: 0.018, zoom: 0.08, flash: 0.2 });
        arena.excite = 1.5; setTimeout(() => { arena.excite = 0.4; }, 2500);
        const solo = app.humans[0] !== app.humans[1];
        hud.callout(solo ? (app.humans[e.r] ? 'Unhorsed! Get back to your bike' : 'Foe unhorsed! +3') : RIDERS[loser.id].name + ' unhorsed', app.humans[e.r] && solo ? 'blood' : 'gold', 1.8);
      }
      break;
    }
    case 'remount': if (live && app.humans[e.r]) hud.callout('Back in the saddle · ride to your end', 'small', 1.2); break;
    case 'wide': sfx.play('skid', panOf(e.x), 1.4); if (live && app.humans[e.r]) hud.callout('Wide turn · brake earlier', 'small', 0.9); break;
    case 'roundStart': {
      app.views.forEach(v => v.resetRound());
      fx.debris.clear();
      if (live) {
        hud.hideBanner();
        post.fx.desat = 0; post.fx.red = 0; post.fx.bars = 0.6;
        director.setMode('fight');
        hud.callout('The joust · ' + (ROMAN[st.coursesMax] || st.coursesMax) + ' courses', 'gold', 1.8);
        hud.setCourse(1, st.coursesMax);
        sfx.play('toll', 0, 1);
      }
      break;
    }
    case 'ride':
      if (live) {
        if (e.again) { hud.callout('Course ' + (ROMAN[st.course] || st.course) + ' · Laissez aller!', 'ember small', 1.0); sfx.play('horn', 0, 0.6); }
        else { hud.callout('Laissez aller!', 'ember', 1.2); sfx.play('horn'); }
        post.fx.bars = 0;
      }
      break;
    case 'timeout': if (live) hud.callout('Time', 'blood'); break;
    case 'matchEnd': if (live) { app.endT = 0.001; } break;
  }
}

function whoName(i, st) {
  if (app.humans[0] !== app.humans[1]) return app.humans[i] ? 'You' : 'Your rival';
  return RIDERS[st.riders[i].id].name;
}
function onKO(e, st, live) {
  const loser = st.riders[e.r];
  const v = app.views[e.r];
  if (e.kind === 'unhorsed') sfx.play('thud', panOf(e.x), 1.3);
  director.shake(e.kind === 'unhorsed' ? 0.7 : 0.2);
  // a column of pale light falls on the fallen; a sigil burns into the stones
  const fall = V(loser.x, 0.05, loser.lane);
  fx.pillars.spawn(fall, 0xeee4cf, 3.4);
  fx.sigils.spawn(fall.clone().setY(0.06), LOOK.fx.sigil, 4.5, 2.6, { normal: V(0, 1, 0), spin: 0.8, intensity: 1.6 });
  for (let i = 0; i < 40; i++) fx.ember(fall.clone().add(V((Math.random() - 0.5) * 2, Math.random() * 2, (Math.random() - 0.5) * 2)), V((Math.random() - 0.5) * 1.5, 1 + Math.random() * 2, (Math.random() - 0.5) * 1.5), Math.random() < 0.5 ? 0xab2629 : 0xeee4cf, 0.08, 2.5);
  if (!live) return;
  sfx.play('toll', 0, 0.5); sfx.play('roar');
  arena.excite = 1.5;
  setTimeout(() => { arena.excite = 0.4; }, 3000);
  post.kick({ aberration: 0.02, zoom: 0.1, flash: 0.25 });
  post.fx.bars = 1; post.fx.desat = 0.5;
  director.setMode('ko', { focus: V(loser.x, 0.8, loser.lane), dir: loser.facing });
  const name = RIDERS[loser.id].name;
  const winnerHuman = e.w !== undefined && app.humans[e.w];
  const loserHuman = app.humans[e.r];
  const solo = app.humans[0] !== app.humans[1];
  const wname = RIDERS[st.riders[e.w].id].name;
  const why = { behind: 'for striking from behind', tilt: 'for striking the tilt three times', horse: 'for striking the horse', unhelmed: 'for losing the helm twice' }[e.why] || '';
  const by = { coronel: 'on coronel-to-coronel breaks', sight: 'on hits to the sight', spears: 'on spears' }[e.why] || '';
  let title, sub;
  if (e.kind === 'unhorsed') { title = solo ? (loserHuman ? 'Unhorsed' : 'Foe unhorsed') : name + ' unhorsed'; sub = wname + ' holds the lists'; }
  else if (e.kind === 'disqualified') { title = solo ? (loserHuman ? 'Disqualified' : 'Foe disqualified') : name + ' disqualified'; sub = 'The judges rule ' + why; }
  else { title = solo ? (winnerHuman ? 'The judges award you the prize' : 'The judges award the prize') : wname + ' wins'; sub = 'Decided ' + by; }
  hud.showBanner(title, sub, solo ? winnerHuman : true);
  if (solo && loserHuman) post.fx.red = 0.35;
}

function showResults() {
  const st = app.state;
  app.resultsShown = true;
  hud.show(false); $('#touch').hidden = true;
  const w = st.matchWinner;
  const solo = app.humans[0] !== app.humans[1];
  const youWon = solo ? app.humans[w] : true;
  const title = $('#rs-title');
  title.textContent = solo ? (youWon ? 'Victory' : 'Defeat') : RIDERS[st.riders[w].id].name + ' triumphs';
  title.classList.toggle('loss', solo && !youWon);
  $('#rs-eyebrow').textContent = st.verdict.startsWith('unhorse') ? 'By unhorsing' : st.verdict.startsWith('dq') ? 'By disqualification' : 'On the judges\' count · ' + st.crossings + ' courses';
  $('#rs-lore').textContent = youWon ? RIDERS[st.riders[w].id].lore : 'The causeway keeps what it takes. ' + RIDERS[st.riders[w].id].name + ' rides on.';
  // the judges' table, in Tiptoft's order of merit
  const sc = i => st.riders[i].score;
  const foulsOf = i => { const f = sc(i).fouls; return (f.tilt + f.horse + f.saddle + f.falseStart + f.behind) || 0; };
  const rows = [
    ['Unhorsings', i => sc(i).unhorse],
    ['Coronel to coronel', i => sc(i).coronel],
    ['Hits on the sight', i => sc(i).sight],
    ['Spears (net)', i => sc(i).spears],
    ['Breaks on the helm', i => sc(i).helm],
    ['Parries', i => st.riders[i].stats.parries],
    ['Fouls', i => foulsOf(i)],
  ];
  $('#rs-table').innerHTML = `<thead><tr><th></th><th>${RIDERS[st.riders[0].id].name} <small>${WEAPONS[st.riders[0].weapon].name}</small></th><th>${RIDERS[st.riders[1].id].name} <small>${WEAPONS[st.riders[1].weapon].name}</small></th></tr></thead><tbody>` +
    rows.map(([l, f]) => `<tr><td>${l}</td><td>${f(0)}</td><td>${f(1)}</td></tr>`).join('') + '</tbody>';
  const rem = $('#s-results [data-act=rematch]');
  rem.hidden = app.mode === 'online-guest';
  hud.hideBanner();
  show('results');
  director.setMode('victory', { focus: V(st.riders[w].x, 1, st.riders[w].lane), dir: 1 });
}

// ------------------------------------------------------------------ main loop
let last = performance.now();
const stances = ['high', 'high'];
function inputsFor(st) {
  const out = [EMPTY_INPUT, EMPTY_INPUT];
  const pads = connectedPads();
  const f0 = st.riders[0].facing, f1 = st.riders[1].facing;
  if (app.mode === 'bot') {
    out[0] = input.frame(0, 'solo', pads[0] ?? -1, f0, TICK);
  } else if (app.mode === 'local') {
    out[0] = input.frame(0, 'p1', pads[0] ?? -1, f0, TICK);
    out[1] = input.frame(1, 'p2', pads[1] ?? -1, f1, TICK);
  } else if (app.mode === 'online-host') {
    out[0] = input.frame(0, 'solo', pads[0] ?? -1, f0, TICK);
    out[1] = app.net ? app.net.guestInput : EMPTY_INPUT;
  }
  stances[0] = st.riders[0].stance; stances[1] = st.riders[1].stance;
  return out;
}

// ?fps: a small performance overlay (fps, worst frame, draw calls, GPU)
function makeFpsMeter() {
  const el = document.createElement('div');
  el.style.cssText = 'position:fixed;left:8px;bottom:8px;z-index:99;font:600 13px/1.35 monospace;color:#eee4cf;background:rgba(7,6,10,.85);padding:6px 9px;pointer-events:none;white-space:pre';
  document.body.appendChild(el);
  const gl = renderer.getContext(); const ext = gl.getExtension('WEBGL_debug_renderer_info');
  const gpu = ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER);
  const m = { n: 0, t: 0, worst: 0, el, gpu: String(gpu).replace(/ANGLE \(|\)$/g, '').slice(0, 70) };
  window.__fps = m;
  return m;
}
let fpsMeter = params.has('fps') ? makeFpsMeter() : null;
// F3 toggles the performance overlay at any time
addEventListener('keydown', e => {
  if (e.code !== 'F3') return;
  e.preventDefault();
  if (!fpsMeter) fpsMeter = makeFpsMeter(); else fpsMeter.el.hidden = !fpsMeter.el.hidden;
});
function tickFps(dt) {
  const m = fpsMeter; m.n++; m.t += dt; m.worst = Math.max(m.worst, dt);
  if (m.t >= 1) {
    m.fps = m.n / m.t; m.worstMs = m.worst * 1000;
    const c = renderer.getDrawingBufferSize(new THREE.Vector2());
    m.el.textContent = `${m.fps.toFixed(0)} fps · worst ${m.worstMs.toFixed(0)} ms · ${renderer.info.render.calls} calls\n${c.x}×${c.y} · ${settings.quality} · pixel ${settings.pixel ? 'on' : 'off'}\n${m.gpu}`;
    m.n = 0; m.t = 0; m.worst = 0;
  }
}

function loop(now) {
  requestAnimationFrame(loop);
  let dt = Math.min(0.1, (now - last) / 1000); last = now;
  if (fpsMeter) tickFps(dt);
  app.realDt = dt;
  if (app.frameHook) app.frameHook(dt);
  const pn = input.padNav();
  if (pn && app.screen !== 'match') padMenu(pn);
  if (pn === 'back' && app.screen === 'match' && app.mode) setPaused(true);

  // ---- simulation
  const st = app.state;
  if (app.attract && st) {
    app.acc += dt;
    while (app.acc >= TICK) {
      app.acc -= TICK;
      const ins = app.attract.bots.map(b => ({ ...botThink(b, st, TICK) }));
      step(st, ins);
      if (st.phase !== 'fight') { st.phase = 'fight'; resetAttractRound(st); }
    }
  } else if (st && app.mode && !app.paused) {
    if (app.mode === 'online-guest') {
      // the guest only sends input; the host's snapshots drive the state
      const pads = connectedPads();
      const f = input.frame(1, 'solo', pads[0] ?? -1, st.riders[1].facing, TICK);
      stances[1] = st.riders[1].stance || 'horiz';
      app.net && app.net.sendInput && app.net.sendInput(f);
      smoothMirror(st, dt);
      const stale = app.net && app.net.lastSnap ? (performance.now() - app.net.lastSnap) : 0;
      hud.setNet(stale > 1500 ? 'Connection unstable…' : 'Online');
    } else {
      app.acc += dt * app.timeScale;
      let n = 0;
      while (app.acc >= TICK && n < 12 * app.timeScale) {
        app.acc -= TICK; n++;
        const ins = inputsFor(st);
        for (const i of [0, 1]) if (app.bots[i]) ins[i] = { ...botThink(app.bots[i], st, TICK) };
        step(st, ins);
      }
      if (app.mode === 'online-host' && app.net) {
        app.net.sendAcc = (app.net.sendAcc || 0) + dt;
        if (app.net.sendAcc >= 1 / 30) {
          app.net.sendAcc = 0;
          app.net.t.send({ role: 'host', phase: 'play', m: app.net.match, cfg: { riders: st.cfg.riders, weapons: st.cfg.weapons }, s: encodeSnapshot(st, 0) });
        }
      }
    }
    if (st.phase === 'matchEnd' && !app.resultsShown) {
      app.endT += dt;
      if (app.endT > 0.001 && director.mode !== 'victory') director.setMode('victory', { focus: V(st.riders[st.matchWinner].x, 1, st.riders[st.matchWinner].lane), dir: 1 });
      if (app.endT > 2.2) showResults();
    }
  }
  input.endFrame();

  // ---- events
  if (st) {
    for (const e of st.events) if (e.id > app.lastEv) { app.lastEv = e.id; handleEvent(e, st, !!app.mode); }
    if (st.phase === 'intro' && app.mode && director.mode !== 'intro') director.setMode('intro');
    if ((st.phase === 'ready' || st.phase === 'fight') && app.mode && (director.mode === 'intro' || director.mode === 'ko')) director.setMode('fight');
  }

  // ---- render-side updates
  const rdt = app.paused ? 0 : dt * (st && st.slowT > 0 ? Math.max(0.3, st.slowScale) : 1) * (st && st.hitstop > 0 ? 0.15 : 1);
  if (app.select && app.screen === 'select') {
    app.select.views.forEach((v, i) => { if (v) { const f = app.select.fake[i]; f.throttle = Math.sin(performance.now() / 700 + i * 2) > 0.85 ? 1 : 0; v.update(dt, f, app.select.fake[1 - i], null); } });
    director.update(dt, app.select.fake, 'select');
  } else if (st) {
    app.views.forEach((v, i) => v.update(rdt, st.riders[i], st.riders[1 - i], st));
    updateTrails(st, rdt);
    updateStrikeCues(st);
    if (app.camOverride) { const o = app.camOverride; camera.position.set(...o.pos); camera.lookAt(...o.look); camera.fov = o.fov || 30; camera.updateProjectionMatrix(); }
    else director.update(dt, st.riders, st.phase);
    // engines
    st.riders.forEach((r, i) => sfx.updateEngine(i, r.v, r.throttle, r.perfectT > 0, panOf(r.x) * 0.8, r.act !== 'down' && !app.paused && (app.mode || app.screen === 'menu' || app.screen === 'title'), r.engine < 30));
    if (app.mode) hud.update(dt, st, camera, stances, canvas.getBoundingClientRect());
  }
  if (arena) arena.update(rdt || dt * 0.2, st ? (st.riders[0].x + st.riders[1].x) / 2 : 0);
  if (fx) fx.update(rdt);
  if (post && arena && arena.rayTarget) {
    const v = arena.rayTarget.clone().project(camera);
    const on = v.z < 1 && Math.abs(v.x) < 1.6 && Math.abs(v.y) < 1.6;
    post.rayPos = new THREE.Vector2(v.x * 0.5 + 0.5, v.y * 0.5 + 0.5);
    const edge = on ? Math.max(0, 1 - Math.max(Math.abs(v.x), Math.abs(v.y)) / 1.6) : 0;
    post.rays = (settings.quality === 'low' ? 0 : 1.3) * edge;
  }
  if (post) post.render(scene, camera, dt);
}

function resetAttractRound(st) {
  // endless backdrop duel: reset riders when someone falls
  if (app.attract.resetT === undefined) app.attract.resetT = 0;
}
function updateTrails(st, dt) {
  const b = new THREE.Vector3(), t = new THREE.Vector3();
  app.trailClock = (app.trailClock || 0) + dt;
  app.trails.forEach((tr, i) => {
    const r = st.riders[i], v = app.views[i];
    if (!v) return;
    if (tr.mesh.parent !== v.root) v.root.add(tr.mesh);
    v.weaponPoints(b, t);
    v.root.worldToLocal(b); v.root.worldToLocal(t);
    tr.push(b, t, app.trailClock);
    tr.target = (r.act === 'active' || (r.act === 'recover' && r.actT < 0.08) || (r.act === 'windup' && r.actT > 0.6 * r.actDur)) ? (r.riposteT > 0 ? 1.3 : 1) : 0;
    tr.mat.uniforms.uColor.value.set(ZONE_COLOR[{ thrust: 'horiz', smash: 'over', cut: 'diag', slash: 'back' }[r.atk]] || 0xff8a40);
    tr.update(app.realDt || dt);
  });
}

function padMenu(dir) {
  if (app.screen === 'title') { sfx.unlock(); show('menu'); return; }
  if (dir === 'up') navMove(-1);
  else if (dir === 'down') navMove(1);
  else if (dir === 'ok') { document.activeElement && document.activeElement.click && document.activeElement.click(); }
  else if (dir === 'back') { if (app.screen === 'pause') setPaused(false); else if (app.screen === 'select' || app.screen === 'lobby') { leaveNet(); toMenu(); } else back(); }
  else if (app.screen === 'select' && (dir === 'left' || dir === 'right')) cycle(0, 'rider', dir === 'left' ? -1 : 1);
}

// endless attract: when a backdrop rider falls, start a fresh pass a bit later
setInterval(() => {
  if (!app.attract) return;
  const st = app.attract.state;
  const down = st.riders.some(r => r.act === 'down');
  if (down) {
    app.attract.downT = (app.attract.downT || 0) + 0.5;
    if (app.attract.downT > 4) { app.attract.downT = 0; if (app.screen === 'title' || app.screen === 'menu') startAttract(); }
  }
}, 500);

// touch controls feed the same key set as the keyboard
const touchCapable = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
$$('#touch button').forEach(b => {
  const k = b.dataset.k;
  const down = (e) => { e.preventDefault(); sfx.unlock(); if (k === 'Escape') { setPaused(!app.paused); return; } input.down.add(k); input.pressedThisFrame.add(k); b.classList.add('on'); };
  const up = (e) => { e.preventDefault(); input.down.delete(k); b.classList.remove('on'); };
  b.addEventListener('pointerdown', down); b.addEventListener('pointerup', up); b.addEventListener('pointercancel', up); b.addEventListener('pointerleave', up);
});
app.touch = touchCapable;
window.addEventListener('pointerdown', () => sfx.unlock(), { once: false });
window.addEventListener('keydown', () => sfx.unlock());
document.addEventListener('visibilitychange', () => { if (document.hidden && app.mode && !app.mode.startsWith('online') && !app.resultsShown) setPaused(true); });

boot().catch(err => {
  console.error(err);
  const m = $('#load-msg'); if (m) m.textContent = 'The forge failed to light: ' + (err && err.message ? err.message : err) + '. Try the Low picture setting or another browser.';
});
