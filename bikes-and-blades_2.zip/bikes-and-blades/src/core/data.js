// Bikes & Blades — gameplay data (v3: the joust at the tilt). All tuning lives here.
// Rulebook: Tiptoft's ordinances for jousts (England, 1466), adapted to motorbikes.
// Anything marked [adapted] is a game adaptation, not history.

export const TICK = 1 / 60;

// The lists: 68 m end to end, tilt down the middle (z = 0).
export const ARENA = {
  half: 34,             // the lists proper: |x| ≤ half
  runoff: 10,           // open ground past each end of the lists, room for a wide U-turn
  lanes: [-1.55, 1.55], // P1 far side of the tilt, P2 near side (sign only; distance comes from `line`)
  start: 29,            // start position, inside the turning end
  endZone: 24,          // |x| beyond this is a turning end: the only place a bike may turn
  crossHalf: 7,         // the crossing zone, |x| < 7
  tiltH: 0.9,           // top of the tilt barrier: a weapon tip below this strikes the tilt
  courses: 5,           // courses in a match (extra courses on a tie) [adapted count]
  readyTime: 2.0,       // herald's call before the first course
  againTime: 0.7,       // ...and before each later course, once both riders have turned
};

// Lateral line: how close to the tilt the bike rides. 0 = outer edge, 1 = against the tilt.
export const LINE = {
  far: 2.2, near: 0.62, // metres from the tilt at line 0 and line 1
  rate: 0.9,            // line units per second while steering
  scrapeSpeed: 9,       // at line ≥ 0.97 above this speed the bike rubs the tilt...
  scrapeTime: 0.45,     // ...and after this long it counts as striking the tilt [adapted]
};
export const laneOffset = line => LINE.far + (LINE.near - LINE.far) * line;

// Automatic five-speed gearbox.
export const GEARS = [
  { lo: 0,    hi: 6.5,  accel: 15 },
  { lo: 4.2,  hi: 10.5, accel: 11.5 },
  { lo: 7.5,  hi: 14.5, accel: 9 },
  { lo: 10.5, hi: 18.5, accel: 7 },
  { lo: 13.5, hi: 22.5, accel: 5.5 },
];

export const BIKE = {
  brake: 26,
  drag: 2.0,
  clutchTime: 0.08,
  turnMaxSpeed: 6.5,    // a plain turn only below this speed...
  turnTime: 1.35,       // ...an arc out and round, so it takes a while
  skidMaxSpeed: 12,     // brake late into the end: a skid turn below this speed
  skidTime: 0.9,        // a skid is quicker...
  skidBalance: 8,       // ...but costs balance
  // the turn is an arc: the bike yaws through 180° while it slows to its exit speed
  turnExit: 3, skidExit: 4, wideExit: 6,
  wideTime: 1.0,        // no brake at all: past the end of the lists the bike carves a wide U-turn
  wideSlow: 11,         // speed shed per second during the wide turn
};

// Unhorsed: the rider lies, gets up, walks back to the bike, lifts it and rides on [adapted].
export const DOWN = { lie: 2.2, getup: 1.0, walk: 2.4, mount: 1.2, slide: 9.6, balanceBack: 70 };

// Ease of the turn's yaw (shared by the sim and the renderer, so the arc matches the motion).
export function turnEase(kind, k) {
  if (kind === 'skid') return 1 - Math.pow(1 - k, 2.6);
  if (kind === 'wide') return k;
  return k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
}

export const RIDER = {
  balance: 100,         // runs out = unhorsed [adapted]
  balanceOnTurn: 8,     // recovered at each turn
  helmet: 100, shield: 100, sword: 100,
  parryWindow: 0.15, parryWindowCracked: 0.1,
  hp: 100,              // alias of balance, for older UI code
};

// Weapons. Weight sets aim speed (how fast the weapon follows your aim),
// wind-ups and damage. `reach` = how far across the tilt it strikes (lateral),
// `fwd` = how far ahead along the lists it meets the rival.
export const WEAPONS = {
  lance: {
    id: 'lance', name: 'Jousting lance', weight: 9, reach: 3.4, fwd: 2.6, minGap: 1.5,
    aimRate: 2.2, attacksPerCourse: 1, active: 0.12, recover: 0.5, breaks: true, breakAt: 14,
    attacks: {
      thrust: { windup: 0.16, base: 13, speedK: 1.1, tipDY: 0,     helm: 30 },
      smash:  { windup: 0.42, base: 18, speedK: 0.4, tipDY: 0.22,  helm: 50 },
      cut:    { windup: 0.40, base: 14, speedK: 0.4, tipDY: -0.12, helm: 25 },
      slash:  { windup: 0.50, base: 16, speedK: 0.35, tipDY: 0,    helm: 25, sweepsTilt: true, behind: true },
    },
  },
  sword: {
    id: 'sword', name: 'Rebated longsword', weight: 1.6, reach: 2.6, fwd: 1.8, minGap: 0,
    aimRate: 7, attacksPerCourse: 2, active: 0.14, recover: 0.22, breaks: false, breakAt: 7,
    attacks: {
      thrust: { windup: 0.14, base: 14, speedK: 0.5,  tipDY: 0,     helm: 18 },
      smash:  { windup: 0.22, base: 16, speedK: 0.25, tipDY: 0.2,   helm: 35, behind: true },
      cut:    { windup: 0.18, base: 13, speedK: 0.25, tipDY: -0.1,  helm: 15, behind: true },
      slash:  { windup: 0.20, base: 14, speedK: 0.25, tipDY: 0,     helm: 18, sweepsTilt: true, behind: true },
    },
  },
};
export const WEAPON_ORDER = ['lance', 'sword'];
export const ATTACKS = ['thrust', 'smash', 'cut', 'slash'];
export const ATTACK_NAME = { thrust: 'Thrust', smash: 'Smash', cut: 'Rising cut', slash: 'Slash' };

// Weapon aim: hand height and tip angle, both in [-1, 1].
export const AIM = {
  handY: 1.35, handRange: 0.35,  // hand height = handY + aimH × handRange
  tipLen: 1.1,                   // tip height at contact = hand + sin(angle) × tipLen + attack offset
  maxAngle: 0.62,                // radians at aimA = ±1
};

// Target bands by tip height at contact (Tiptoft's places of a break).
export const BANDS = [
  { id: 'tilt',   to: 0.9 },   // struck the tilt (foul)
  { id: 'horse',  to: 1.0 },   // struck the bike = "the horse" (foul)
  { id: 'saddle', to: 1.2 },   // broke on the saddle (−1)
  { id: 'body',   to: 1.95 },  // between saddle and helm (1 spear)
  { id: 'helm',   to: 2.45 },  // the helm (2 spears); sight inside it
  { id: 'over',   to: 99 },    // over the head: miss
];
export const SIGHT = [2.12, 2.26];  // the sight of the helm

// The game's ruleset: Tiptoft's scoring, simplified for pace. Rules switched off here
// are documented in the rulebook and can be turned back on.
export const RULES = {
  falseStart: false,    // no false-start fouls: the bikes are held until the herald's call
  saddleFoul: false,    // a hit on the saddle simply scores nothing
  horseFoul: false,     // a hit on the bike simply scores nothing
  behindFoul: false,    // (riders can no longer end up behind each other)
  unhelmedDQ: false,    // losing the helm is its own punishment
  tiltDQ: false,        // striking the tilt costs a spear each time, never the match
  syncCourses: true,    // every course starts together: whoever turns first waits for the other
  meritOrder: false,    // the match is decided on spears alone (a tie adds a course)
  unhorseEndsMatch: false, // the unhorsed rider gets up, walks back to the bike and rides on (3 spears to the victor)
};

// Scoring (Tiptoft) and penalties.
export const SCORE = {
  body: 1, helm: 2, sight: 3, unhorse: 3, coronel: 3, saddle: -1,
  tilt: [-1],                   // each time (Tiptoft: −2, −3, then disqualified)
  horse: [-2, 'dq'],            // [adapted] warning before disqualification
  falseStart: [0, -1],          // [adapted] warning, then a spear
  unhelmedDQ: 2,
};

// Balance and defence [adapted].
export const DEFENCE = {
  shieldBody: 0.5,      // a raised shield halves balance damage on the body
  parryBalance: 55, parrySlow: 0.5,
  hitSlow: 0.4,         // the rider hit loses up to 40% of their speed
  helmK: 1.15, sightK: 1.25, saddleK: 0.5, crackedHelmK: 1.2,
};

// Crossing slow motion [adapted].
export const CROSSING = { slowT: 0.9, slowScale: 0.4, lead: 0.34, minClosing: 10 };

export const FEATURES = { crossingSlowmo: true, directions: true, manualGears: false, autoTurn: false };

// Cosmetic identity of each rider.
export const RIDERS = {
  aldric: {
    id: 'aldric', name: 'Sir Aldric', title: 'of the Ashen Vow',
    helm: 'great', cape: 0x6e1414, cloth: 0x3a2a22, metal: 0x8a8c8e, trim: 0xb08a4a,
    paint: 0x5a1a16, emblem: 'sun', eye: 0xff7a2a,
    lore: 'Swore to ride until the last ember dies. It has not died. Neither has he.',
  },
  pilgrim: {
    id: 'pilgrim', name: 'The Rust Pilgrim', title: 'Walker of the Long Road',
    helm: 'pilgrim', cape: 0x5b4630, cloth: 0x4a3b2a, metal: 0x7a5a3c, trim: 0x9a7a4a,
    paint: 0x6a4a28, emblem: 'road', eye: 0xffb050,
    lore: 'His bike was a cart once. His lance was a gate bolt. Everything rusts toward him.',
  },
  maelis: {
    id: 'maelis', name: 'Maelis', title: 'Bell-Warden',
    helm: 'bell', cape: 0xb8b0a0, cloth: 0x52565c, metal: 0xb4b8bc, trim: 0xd8c690,
    paint: 0x3c4450, emblem: 'bell', eye: 0x9fd8ff,
    lore: 'Each foe she unhorses rings a bell in a tower no one has seen.',
  },
  vorn: {
    id: 'vorn', name: 'Gravecaller Vorn', title: 'Keeper of the Unburied',
    helm: 'hood', cape: 0x1c2620, cloth: 0x222a24, metal: 0x4a4e48, trim: 0xcfc6ae,
    paint: 0x1e2a22, emblem: 'skull', eye: 0x7dff9a,
    lore: 'Rides with a lantern full of names. He means to add yours.',
  },
};
export const RIDER_ORDER = ['aldric', 'pilgrim', 'maelis', 'vorn'];

// Bots send the same inputs as a player. aimErr = how far off their tip height is (m),
// timing = release jitter (s), guard/parry = how often they raise the shield / try a parry.
export const BOT_LEVELS = {
  0: { name: 'Squire',         aimErr: 0.32, timing: 0.10, guard: 0.35, parry: 0.02, reaction: 0.3,  helmGoal: 0.15, skid: 0.0, lineSkill: 0.5 },
  1: { name: 'Knight',         aimErr: 0.18, timing: 0.05, guard: 0.6,  parry: 0.08, reaction: 0.2,  helmGoal: 0.4,  skid: 0.4, lineSkill: 0.8 },
  2: { name: 'Lord of Cinder', aimErr: 0.09, timing: 0.025, guard: 0.8, parry: 0.16, reaction: 0.13, helmGoal: 0.6,  skid: 0.8, lineSkill: 1 },
};

export const ROMAN = ['', 'I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
