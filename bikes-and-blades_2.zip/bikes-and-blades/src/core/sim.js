// Bikes & Blades — authoritative joust simulation (v3: the joust at the tilt).
// Rules: Tiptoft's ordinances (1466) as set out in the rulebook, adapted to
// motorbikes. Pure data + logic at 60 Hz; the renderer, audio and HUD only
// read state and events.
//
// Input frame (all numbers, so it travels well over the network):
//   gas, brake     — accelerate, brake (skid-turn in a turning end)
//   inL, outL      — steer the line toward / away from the tilt
//   aimH, aimA     — weapon height and tip angle, each in [-1, 1] (mouse)
//   ac, at         — attack counter (bumps on release) and the attack type index
//   guard, gc      — shield held, and a counter of fresh shield presses (parry timing)

import {
  TICK, ARENA, LINE, laneOffset, GEARS, BIKE, RIDER, WEAPONS, ATTACKS, AIM, BANDS, SIGHT,
  SCORE, DEFENCE, CROSSING, FEATURES, RULES, DOWN, turnEase,
} from './data.js';

export const EMPTY_INPUT = Object.freeze({ gas: 0, brake: 0, inL: 0, outL: 0, aimH: 0, aimA: 0, ac: 0, at: 0, guard: 0, gc: 0 });

function newScore() {
  return { spears: 0, breaks: 0, helm: 0, sight: 0, coronel: 0, unhorse: 0, misses: 0,
    fouls: { tilt: 0, horse: 0, saddle: 0, falseStart: 0, behind: 0 }, unhelmed: 0, dq: '' };
}

function newRider(i, riderId, weapon) {
  const W = WEAPONS[weapon] || WEAPONS.lance;
  return {
    i, id: riderId, weapon: W.id,
    x: 0, v: 0, facing: 1, line: 0.5, lane: 0, side: Math.sign(ARENA.lanes[i]),
    gear: 0, rpm: 0, clutchT: 0, throttle: 0, braking: 0,
    balance: RIDER.balance, hp: RIDER.balance,
    helmet: RIDER.helmet, shield: RIDER.shield, sword: RIDER.sword, lanceBroken: false,
    aimH: 0, aimA: 0,
    act: 'free', actKind: '', actT: 0, actDur: 0, atk: 'thrust', zone: 'horiz',
    attacksLeft: W.attacksPerCourse, hitDone: false, brakeFrom: 0, turned: false, waiting: false, tipY: 0, guardStart: -9, shieldUp: false, scrapeT: 0, scraped: false,
    koKind: '', bodyX: 0, drawn: 1, stance: 'horiz', charge: 0, riposteT: 0, perfectT: 0,
    prev: { ac: 0, gc: 0 },
    score: newScore(),
    stats: { hits: 0, blocks: 0, parries: 0, dealt: 0, breaks: 0, partsBroken: 0, perfectShifts: 0, helmetsBroken: 0 },
  };
}

export function createMatch(cfg) {
  const weapons = cfg.weapons || ['lance', 'lance'];
  const ids = cfg.riders || ['aldric', 'vorn'];
  const s = {
    cfg: { riders: ids, weapons, mode: cfg.mode || 'bot' },
    time: 0, tick: 0, phase: 'intro', phaseT: 0,
    course: 1, round: 1, coursesMax: ARENA.courses, crossings: 0, lastSide: 0, endT: -1,
    wins: [0, 0], timer: 0, hitstop: 0, slowT: 0, slowScale: 1,
    roundWinner: -1, matchWinner: -1, verdict: '', crossReady: true,
    events: [], evId: 0,
    riders: [0, 1].map(i => newRider(i, ids[i], weapons[i])),
  };
  placeAtStart(s);
  return s;
}

function placeAtStart(s) {
  for (const r of s.riders) {
    r.x = r.i === 0 ? -ARENA.start : ARENA.start;
    r.facing = r.i === 0 ? 1 : -1;
    r.v = 0; r.gear = 0; r.act = 'free'; r.actT = 0;
    r.lane = r.side * laneOffset(r.line);
  }
  s.lastSide = Math.sign(s.riders[1].x - s.riders[0].x);
}

function emit(s, type, data) {
  s.events.push(Object.assign({ id: ++s.evId, type, t: s.time }, data));
  if (s.events.length > 60) s.events.splice(0, s.events.length - 60);
}
function setAct(r, act, dur = 0, kind = '') { r.act = act; r.actT = 0; r.actDur = dur; r.actKind = kind; }
const W = r => WEAPONS[r.weapon];

// Tip height at contact, and the band it lands in.
export function tipHeight(r, atk = r.atk) {
  const a = W(r).attacks[atk] || W(r).attacks.thrust;
  return AIM.handY + r.aimH * AIM.handRange + Math.sin(r.aimA * AIM.maxAngle) * AIM.tipLen + a.tipDY;
}
export function bandOf(y) { return BANDS.find(b => y < b.to).id; }
export function lateralGap(a, b) { return laneOffset(a.line) + laneOffset(b.line); }

// ---------------------------------------------------------------------------

export function step(s, inputs) {
  if (s.hitstop > 0) { s.hitstop = Math.max(0, s.hitstop - TICK); return; }
  const scale = s.slowT > 0 ? s.slowScale : 1;
  if (s.slowT > 0) s.slowT = Math.max(0, s.slowT - TICK);
  const dt = TICK * scale;
  s.time += dt; s.tick++; s.phaseT += TICK;
  const inp = i => inputs[i] || EMPTY_INPUT;

  switch (s.phase) {
    case 'intro':
      for (const r of s.riders) idle(r, inp(r.i));
      if (s.phaseT >= 2.8) { s.phase = 'ready'; s.phaseT = 0; emit(s, 'roundStart', { round: s.course }); }
      return;
    case 'ready': {
      // the bikes may rev and creep, but crossing the start line before the call is a false start
      for (const r of s.riders) ride(s, r, inp(r.i), dt, true);
      const early = RULES.falseStart && s.riders.find(r => Math.abs(r.x) < ARENA.start - 1.5);
      if (early) { falseStart(s, early); return; }
      if (s.phaseT >= ARENA.readyTime) { s.phase = 'fight'; s.phaseT = 0; emit(s, 'ride', {}); }
      return;
    }
    case 'fight':
      for (const r of s.riders) ride(s, r, inp(r.i), dt, false);
      if (RULES.syncCourses) syncCourse(s, dt);
      if (FEATURES.crossingSlowmo) crossingSlowmo(s);
      resolveCombat(s);
      checkCrossing(s);
      if (s.phase === 'fight' && s.endT >= 0) {
        s.endT += dt;
        if (s.endT > 1.6) judge(s);
      }
      return;
    case 'ko':
      for (const r of s.riders) ride(s, r, r.act === 'down' ? EMPTY_INPUT : { ...EMPTY_INPUT, brake: 1 }, dt, true);
      if (s.phaseT >= 3.6) { s.phase = 'matchEnd'; s.phaseT = 0; emit(s, 'matchEnd', { w: s.matchWinner }); }
      return;
    case 'matchEnd':
      for (const r of s.riders) ride(s, r, { ...EMPTY_INPUT, brake: 1 }, dt, true);
      return;
  }
}

// Every course starts together: a rider who has turned waits at the end until the
// rival has turned too, then the herald sends both off at once, so neither ever
// chases the other's back and both arrive at the crossing on equal terms.
function syncCourse(s, dt) {
  const [a, b] = s.riders;
  if (!(a.waiting || b.waiting)) return;
  if (a.turned && b.turned) {
    s.againT = (s.againT || 0) + dt;
    if (s.againT >= ARENA.againTime) {
      a.waiting = b.waiting = false; s.againT = 0;
      emit(s, 'ride', { again: 1, course: s.course });
    }
  }
}

function idle(r, inp) {
  r.throttle = inp.gas ? 1 : 0;
  r.rpm += ((inp.gas ? 0.85 : 0.08) - r.rpm) * 0.08;
  r.prev.ac = inp.ac; r.prev.gc = inp.gc;
  r.aimH = inp.aimH || 0; r.aimA = inp.aimA || 0;
}

function falseStart(s, r) {
  r.score.fouls.falseStart++;
  const pen = SCORE.falseStart[Math.min(r.score.fouls.falseStart, SCORE.falseStart.length) - 1];
  r.score.spears += pen;
  emit(s, 'foul', { r: r.i, kind: 'falseStart', pen, n: r.score.fouls.falseStart, x: r.x });
  placeAtStart(s);
  s.phaseT = 0;
}

// ---------------------------------------------------------------------------
// One rider: aim, line, shield, attacks, bike.

function ride(s, r, inp, dt, held) {
  inp = inp || EMPTY_INPUT;
  const Wp = W(r);
  const attackPressed = inp.ac !== r.prev.ac;
  const guardPressed = inp.gc !== r.prev.gc;
  r.prev.ac = inp.ac; r.prev.gc = inp.gc;

  if (r.act === 'down' || r.act === 'getup' || r.act === 'walk' || r.act === 'mount') { unhorsedStep(s, r, dt); return; }

  // weapon aim follows the input at the weapon's own speed (weight); locked during a blow
  const swinging = r.act === 'windup' || r.act === 'active';
  if (!swinging) {
    const k = Wp.aimRate * dt;
    r.aimH += Math.max(-k, Math.min(k, (inp.aimH || 0) - r.aimH));
    r.aimA += Math.max(-k, Math.min(k, (inp.aimA || 0) - r.aimA));
  }
  r.tipY = tipHeight(r);

  // line toward / away from the tilt
  const steer = (inp.inL ? 1 : 0) - (inp.outL ? 1 : 0);
  if (r.act !== 'turn' && r.act !== 'skid' && r.act !== 'wide') r.line = Math.max(0, Math.min(1, r.line + steer * LINE.rate * dt));
  r.lane = r.side * laneOffset(r.line);
  if (!held && s.phase === 'fight' && r.line >= 0.97 && r.v > LINE.scrapeSpeed) {
    r.scrapeT += dt;
    if (r.scrapeT >= LINE.scrapeTime && !r.scraped) { r.scraped = true; foul(s, r, 'tilt', { by: 'bike' }); }
  } else r.scrapeT = 0;

  // the shield is in the left hand: it can be raised whatever the weapon arm is doing
  const canGuard = r.shield > 0 && r.act !== 'turn' && r.act !== 'skid' && r.act !== 'wide' && !held;
  const up = !!inp.guard && canGuard;
  if (up && (!r.shieldUp || guardPressed)) r.guardStart = s.time;
  r.shieldUp = up;

  // actions
  r.actT += dt;
  if (!held) switch (r.act) {
    case 'free':
      if (attackPressed) {
        if (r.attacksLeft > 0 && !(r.weapon === 'lance' && r.lanceBroken)) { startAttack(s, r, ATTACKS[inp.at] || 'thrust'); break; }
        emit(s, 'spent', { r: r.i, x: r.x });
      }
      break;
    case 'windup':
      if (r.actT >= r.actDur) { setAct(r, 'active', Wp.active); r.hitDone = false; onActive(s, r); }
      break;
    case 'active':
      if (r.actT >= r.actDur) setAct(r, 'recover', Wp.recover);
      break;
    case 'recover': case 'stagger':
      if (r.actT >= r.actDur) setAct(r, 'free');
      break;
    case 'turn': case 'skid': case 'wide': {
      // slow toward the exit speed while yawing round; the motion below follows the arc
      const exit = r.act === 'turn' ? BIKE.turnExit : r.act === 'skid' ? BIKE.skidExit : BIKE.wideExit;
      const rate = r.act === 'wide' ? BIKE.wideSlow : BIKE.brake * 0.9;
      r.v = r.v > exit ? Math.max(exit, r.v - rate * dt) : r.v + (exit - r.v) * Math.min(1, dt * 2);
      if (r.actT >= r.actDur) finishTurn(s, r);
      break;
    }
  }

  // bike: automatic gearbox, gas, brake; turn only inside the turning end ahead
  const G = GEARS[r.gear];
  r.rpm = Math.max(0, Math.min(1.05, (r.v - G.lo) / Math.max(0.1, G.hi - G.lo)));
  r.clutchT = Math.max(0, r.clutchT - dt);
  const turning = r.act === 'turn' || r.act === 'skid' || r.act === 'wide';
  const gas = !!inp.gas && !turning && r.act !== 'stagger';
  r.throttle = gas ? 1 : inp.brake ? -1 : 0;
  if (inp.brake && !r.braking) r.brakeFrom = r.x * r.facing; // where this brake began
  r.braking = inp.brake ? 1 : 0;
  if (gas && r.gear < GEARS.length - 1 && r.rpm >= 0.9 && r.clutchT <= 0) {
    r.gear++; r.clutchT = BIKE.clutchTime; emit(s, 'shift', { r: r.i, q: 'auto', g: r.gear, x: r.x });
  }
  if (turning) {
    // braking handled by the action
  } else if (gas && r.clutchT <= 0) {
    if (r.rpm < 1) r.v += G.accel * (1 - 0.7 * r.rpm ** 3) * dt;
    else r.v = Math.min(r.v, G.hi);
  } else if (inp.brake) {
    r.v = Math.max(0, r.v - BIKE.brake * dt);
    const inEnd = r.x * r.facing > ARENA.endZone;
    const canAct = r.act === 'free' || r.act === 'recover';
    if (inEnd && canAct && !held && s.phase === 'fight') {
      if (r.v < BIKE.turnMaxSpeed) { setAct(r, 'turn', BIKE.turnTime); emit(s, 'turn', { r: r.i, x: r.x }); }
      else if (r.v < BIKE.skidMaxSpeed && r.brakeFrom > ARENA.endZone) { // braked late: skid round
        setAct(r, 'skid', BIKE.skidTime);
        emit(s, 'skid', { r: r.i, x: r.x, v: r.v });
        loseBalance(s, r, BIKE.skidBalance, 1 - r.i);
      }
    }
  } else {
    r.v = Math.max(0, r.v - BIKE.drag * dt);
  }
  // ran past the end of the lists without turning: the bike carves a wide U-turn on the open ground
  if (!turning && !held && s.phase === 'fight' && r.x * r.facing > ARENA.half && (r.act === 'free' || r.act === 'recover' || r.act === 'stagger')) {
    setAct(r, 'wide', BIKE.wideTime + r.v * 0.02);
    emit(s, 'wide', { r: r.i, x: r.x, v: r.v });
  }
  while (r.gear > 0 && r.v < GEARS[r.gear].lo * 0.9) r.gear--;
  if (held && s.phase === 'ready') r.v = RULES.falseStart ? Math.min(r.v, 4) : 0; // held at the line
  if (r.waiting) r.v = Math.max(0, r.v - BIKE.brake * dt); // turned: rolls to a stop and waits for the rival

  // during a turn the bike travels along the arc: forward, then back the way it came
  const arcK = (r.act === 'turn' || r.act === 'skid' || r.act === 'wide') ? Math.cos(Math.PI * turnEase(r.act, Math.min(1, r.actT / r.actDur))) : 1;
  r.x += r.facing * r.v * arcK * dt;
  clampEnds(s, r, held);
}

// The open run-off past the lists ends in the gates; there is no crash wall, the bike
// just runs out of ground and stops (in practice the wide turn brings it round first).
function clampEnds(s, r) {
  const h = ARENA.half + ARENA.runoff;
  if (Math.abs(r.x) <= h) return;
  r.x = Math.sign(r.x) * h;
  if (r.act !== 'turn' && r.act !== 'skid' && r.act !== 'wide') { r.v = 0; r.gear = 0; }
}

// Unhorsed [adapted]: the bike slides on and stops; the rider lies, gets up, walks back
// to the bike, lifts it and mounts. Then they ride to their end as usual.
function unhorsedStep(s, r, dt) {
  r.throttle = 0; r.shieldUp = false;
  r.v = Math.max(0, r.v - 9 * dt);
  r.x += r.facing * r.v * dt; clampEnds(s, r);
  r.actT += dt;
  const lim = ARENA.half + ARENA.runoff;
  if (r.act === 'down' && r.actT >= DOWN.lie) setAct(r, 'getup', DOWN.getup);
  else if (r.act === 'getup' && r.actT >= DOWN.getup) setAct(r, 'walk');
  else if (r.act === 'walk') {
    const d = r.x - r.bodyX;
    r.bodyX += Math.sign(d) * Math.min(Math.abs(d), DOWN.walk * dt);
    r.bodyX = Math.max(-lim, Math.min(lim, r.bodyX));
    if (Math.abs(r.x - r.bodyX) < 0.45 && r.v < 0.5) setAct(r, 'mount', DOWN.mount);
  } else if (r.act === 'mount' && r.actT >= DOWN.mount) {
    setAct(r, 'free'); r.v = 0; r.gear = 0;
    r.balance = r.hp = DOWN.balanceBack;
    emit(s, 'remount', { r: r.i, x: r.x });
  }
}

function finishTurn(s, r) {
  r.facing *= -1; r.gear = 0; // keeps the exit speed: the arc runs on into the next charge
  setAct(r, 'free');
  r.balance = Math.min(RIDER.balance, r.balance + RIDER.balanceOnTurn); r.hp = r.balance;
  r.attacksLeft = W(r).attacksPerCourse; r.scraped = false;
  r.turned = true; if (RULES.syncCourses) r.waiting = true;
  const fresh = r.lanceBroken || r.helmet <= 0;
  r.lanceBroken = false;
  if (r.helmet <= 0) r.helmet = 60; // the squire laces a helm back on
  emit(s, 'turned', { r: r.i, x: r.x, fresh: fresh ? 1 : 0 });
}

function startAttack(s, r, atk) {
  const a = W(r).attacks[atk];
  setAct(r, 'windup', a.windup);
  r.atk = atk; r.zone = atk; r.attacksLeft--; r.hitDone = false;
  const o = s.riders[1 - r.i]; r.atkAlong = (o.x - r.x) * r.facing;
  emit(s, 'windup', { r: r.i, z: atk });
}

// The blow arrives: a weapon passing below the top of the tilt strikes it first.
function onActive(s, r) {
  emit(s, 'swing', { r: r.i, z: r.atk });
  const a = W(r).attacks[r.atk];
  const y = tipHeight(r);
  if (y < ARENA.tiltH || (a.sweepsTilt && y < ARENA.tiltH + 0.35)) {
    r.hitDone = true;
    if (r.weapon === 'lance') { r.lanceBroken = true; emit(s, 'break', { r: r.i, x: r.x + r.facing * 1.5, y: ARENA.tiltH, tilt: 1 }); }
    foul(s, r, 'tilt', { by: 'weapon', y });
  }
}

// ---------------------------------------------------------------------------
// Combat: contact, bands, breaks, parries, balance.

function inContact(A, D) {
  const along = (D.x - A.x) * A.facing;
  const Wp = W(A);
  const gap = lateralGap(A, D);
  if (gap > Wp.reach) return { ok: false, behind: false, along, gap };
  // only a swung blow can reach a rider already passed; a couched point cannot
  // and only a blow begun after the crossing counts as striking from behind; a late one is a miss
  const canBehind = !!Wp.attacks[A.atk].behind && A.atkAlong < 0;
  return { ok: along >= -0.4 && along <= Wp.fwd, behind: canBehind && along < -0.4 && along > -1.6, along, gap };
}

function resolveCombat(s) {
  const [a, b] = s.riders;
  const live = (A, D) => A.act === 'active' && !A.hitDone && !['down', 'getup', 'walk', 'mount'].includes(D.act);
  // coronel to coronel: both couched thrusts meet tip to tip
  if (live(a, b) && live(b, a) && a.weapon === 'lance' && b.weapon === 'lance' && a.atk === 'thrust' && b.atk === 'thrust') {
    const ca = inContact(a, b), cb = inContact(b, a);
    if (ca.ok && cb.ok && Math.abs(tipHeight(a) - tipHeight(b)) < 0.15) {
      a.hitDone = b.hitDone = true;
      for (const r of [a, b]) { r.lanceBroken = true; r.score.coronel++; r.score.breaks++; r.score.spears += SCORE.coronel; emit(s, 'score', { r: r.i, pts: SCORE.coronel, kind: 'coronel', x: r.x }); }
      emit(s, 'coronel', { x: (a.x + b.x) / 2, y: tipHeight(a) });
      emit(s, 'clash', { x: (a.x + b.x) / 2, y: tipHeight(a), z: 'thrust' });
      s.hitstop = 0.18; s.slowT = 0.6; s.slowScale = 0.35;
      return;
    }
  }
  const order = (b.actT > a.actT) ? [[b, a], [a, b]] : [[a, b], [b, a]];
  // both blows of the same instant are resolved, even if the first one decides the match
  const both = order.filter(([A, D]) => live(A, D));
  for (const [A, D] of both) if (s.phase === 'fight' || both.length === 2) strikeCheck(s, A, D);
}

function strikeCheck(s, A, D) {
  const c = inContact(A, D);
  if (c.behind) {
    // a blow at a rider already passed: the ordinances disqualify it (off in the game ruleset: a miss)
    A.hitDone = true;
    if (RULES.behindFoul) foul(s, A, 'behind', {});
    else { A.score.misses++; emit(s, 'miss', { r: A.i, x: A.x, y: tipHeight(A), z: A.atk, late: 1 }); }
    return;
  }
  if (!c.ok) {
    if (c.along < -0.4 && c.gap <= W(A).reach) { A.hitDone = true; A.score.misses++; emit(s, 'miss', { r: A.i, x: A.x, y: tipHeight(A), z: A.atk, late: 1 }); }
    return;
  }
  A.hitDone = true;
  const Wp = W(A), a = Wp.attacks[A.atk];
  const y = tipHeight(A);
  const band = bandOf(y);
  const x = (A.x + D.x) / 2;
  if (band === 'over') { A.score.misses++; emit(s, 'miss', { r: A.i, x, y, z: A.atk }); return; }
  if (band === 'tilt') { foul(s, A, 'tilt', { by: 'weapon', y }); return; }
  if (band === 'horse') {
    emit(s, 'hit', { a: A.i, d: D.i, x, y, z: A.atk, dmg: 4, band, brk: 0 });
    if (RULES.horseFoul) foul(s, A, 'horse', { y });
    else emit(s, 'glance', { a: A.i, d: D.i, x, y, z: A.atk, low: 1 });
    return;
  }
  const closing = Math.max(0, A.v + D.v);
  let dmg = a.base * (1 + a.speedK * closing / 30);
  const sight = band === 'helm' && y >= SIGHT[0] && y <= SIGHT[1];

  // the parry: the shield raised on the instant of impact turns the blow aside [adapted]
  const win = D.shield < 50 ? RIDER.parryWindowCracked : RIDER.parryWindow;
  if (D.shieldUp && D.shield > 0 && s.time - D.guardStart <= win && band !== 'saddle') {
    setAct(A, 'stagger', 0.9, 'parried');
    A.v *= DEFENCE.parrySlow;
    D.stats.parries++;
    wear(s, D, 'shield', 4);
    emit(s, 'parry', { a: A.i, d: D.i, x, y, z: A.atk });
    s.hitstop = 0.16; s.slowT = 0.75; s.slowScale = 0.33;
    loseBalance(s, A, DEFENCE.parryBalance, D.i);
    return;
  }

  if (band === 'saddle') {
    dmg *= DEFENCE.saddleK;
    if (A.weapon === 'lance') A.lanceBroken = true;
    emit(s, 'hit', { a: A.i, d: D.i, x, y, z: A.atk, dmg, band, brk: A.weapon === 'lance' ? 1 : 0 });
    if (RULES.saddleFoul) {
      A.score.fouls.saddle++; A.score.spears += SCORE.saddle;
      emit(s, 'foul', { r: A.i, kind: 'saddle', pen: SCORE.saddle, n: A.score.fouls.saddle, x });
    } else emit(s, 'glance', { a: A.i, d: D.i, x, y, z: A.atk, low: 1 });
    if (A.weapon === 'lance') emit(s, 'break', { r: A.i, x, y });
    loseBalance(s, D, dmg, A.i);
    return;
  }

  const shieldUp = D.shieldUp && D.shield > 0;
  if (band === 'helm') dmg *= sight ? DEFENCE.sightK : DEFENCE.helmK * (D.helmet < 50 ? DEFENCE.crackedHelmK : 1);
  else if (shieldUp) dmg *= DEFENCE.shieldBody;
  if (A.weapon === 'lance' && c.gap < Wp.minGap) dmg *= 0.4; // too close to couch the lance

  const breaks = dmg >= Wp.breakAt;
  A.stats.hits++; A.stats.dealt += dmg;
  if (breaks) {
    const pts = sight && !RULES.meritOrder ? SCORE.sight : band === 'helm' ? SCORE.helm : SCORE.body;
    A.score.spears += pts; A.score.breaks++;
    if (band === 'helm') A.score.helm++;
    if (sight) A.score.sight++;
    if (A.weapon === 'lance') { A.lanceBroken = true; A.stats.breaks++; }
    emit(s, 'score', { r: A.i, pts, kind: sight ? 'sight' : band, x });
  } else emit(s, 'glance', { a: A.i, d: D.i, x, y, z: A.atk });

  emit(s, 'hit', { a: A.i, d: D.i, x, y, z: A.atk, dmg, band, brk: breaks && A.weapon === 'lance' ? 1 : 0, sight: sight ? 1 : 0, closing, shield: shieldUp ? 1 : 0 });
  if (breaks && A.weapon === 'lance') emit(s, 'break', { r: A.i, x, y });
  if (band === 'helm') wear(s, D, 'helmet', a.helm * (breaks ? 1 : 0.5));
  else if (shieldUp) { wear(s, D, 'shield', dmg * 0.5); D.stats.blocks++; }
  if (A.weapon === 'sword') wear(s, A, 'sword', 3);
  D.v *= 1 - DEFENCE.hitSlow * Math.min(1, dmg / 50);
  // no flinch: a blow landed first never spoils the rival's, so the exchange is simultaneous
  s.hitstop = Math.min(0.16, 0.06 + dmg * 0.002);
  loseBalance(s, D, dmg, A.i); // the second blow of an exchange still shakes its target
}

function loseBalance(s, r, n, byIdx) {
  r.balance -= n; r.hp = Math.max(0, r.balance);
  if (r.balance <= 0 && s.phase === 'fight' && !['down', 'getup', 'walk', 'mount'].includes(r.act)) {
    const w = s.riders[byIdx];
    w.score.unhorse++; w.score.spears += SCORE.unhorse;
    emit(s, 'score', { r: w.i, pts: SCORE.unhorse, kind: 'unhorse', x: r.x });
    if (RULES.unhorseEndsMatch) { ko(s, r, 'unhorsed', w.i); return; }
    // thrown off: the body slides on past the bike, then the long walk back
    r.balance = r.hp = 0;
    r.bodyX = r.x + r.facing * Math.min(16, r.v * r.v / (2 * DOWN.slide));
    setAct(r, 'down', DOWN.lie, 'unhorsed'); r.koKind = 'unhorsed';
    r.attacksLeft = 0; r.waiting = false;
    emit(s, 'unhorse', { r: r.i, w: w.i, x: r.x, v: r.v });
    s.hitstop = 0.2; s.slowT = 1.2; s.slowScale = 0.3;
  }
}

function wear(s, r, item, amount) {
  const before = r[item];
  if (before <= 0) return;
  r[item] = Math.max(0, before - amount);
  const after = r[item];
  if (before > 60 && after <= 60) emit(s, 'dent', { r: r.i, item, lvl: 1, x: r.x });
  if (before > 25 && after <= 25) emit(s, 'dent', { r: r.i, item, lvl: 2, x: r.x });
  if (after <= 0) {
    emit(s, 'equipBreak', { r: r.i, item, x: r.x });
    if (item === 'helmet') {
      r.score.unhelmed++;
      s.riders[1 - r.i].stats.helmetsBroken++;
      if (RULES.unhelmedDQ && r.score.unhelmed >= SCORE.unhelmedDQ) disqualify(s, r, 'unhelmed');
    }
  }
}

// Fouls and the judges' penalties.
function foul(s, r, kind, info) {
  const f = r.score.fouls;
  f[kind] = (f[kind] || 0) + 1;
  const table = kind === 'tilt' ? (RULES.tiltDQ ? [-2, -3, 'dq'] : SCORE.tilt) : kind === 'horse' ? SCORE.horse : kind === 'behind' ? ['dq'] : [0];
  const pen = table[Math.min(f[kind], table.length) - 1];
  if (pen === 'dq') { emit(s, 'foul', { r: r.i, kind, pen: 0, n: f[kind], dq: 1, x: r.x, ...info }); disqualify(s, r, kind); return; }
  r.score.spears += pen;
  emit(s, 'foul', { r: r.i, kind, pen, n: f[kind], x: r.x, ...info });
}

function disqualify(s, r, why) {
  if (s.phase !== 'fight') return;
  r.score.dq = why;
  ko(s, r, 'disqualified', 1 - r.i, why);
}

function ko(s, loser, kind, winnerIdx, why = '') {
  if (s.phase !== 'fight') return;
  loser.koKind = kind;
  if (kind === 'unhorsed') setAct(loser, 'down');
  s.phase = 'ko'; s.phaseT = 0;
  s.roundWinner = s.matchWinner = winnerIdx;
  s.wins[winnerIdx] = 1;
  s.verdict = kind === 'unhorsed' ? 'unhorse' : kind === 'disqualified' ? 'dq:' + why : 'points:' + why;
  emit(s, 'ko', { r: loser.i, kind, w: winnerIdx, x: loser.x, v: loser.v, why });
  if (kind === 'unhorsed') { s.hitstop = 0.22; s.slowT = 1.5; s.slowScale = 0.25; }
}

// ---------------------------------------------------------------------------
// Courses, crossings and the judges' decision.

function checkCrossing(s) {
  const [a, b] = s.riders;
  const side = Math.sign(b.x - a.x) || s.lastSide;
  if (side !== s.lastSide) {
    s.lastSide = side;
    s.crossings++;
    a.turned = b.turned = false;
    emit(s, 'courseEnd', { n: s.crossings, x: (a.x + b.x) / 2 });
    if (s.crossings >= s.coursesMax) s.endT = 0;
    else { s.course = s.crossings + 1; s.round = s.course; }
  }
}

// Tiptoft's order of merit: unhorsing (already decided), coronel to coronel,
// the sight, then the spear count.
export function compare(a, b, merit = RULES.meritOrder) {
  const keys = merit ? ['coronel', 'sight', 'spears'] : ['spears'];
  for (const k of keys) if (a.score[k] !== b.score[k]) return { w: a.score[k] > b.score[k] ? a.i : b.i, by: k };
  return { w: -1, by: 'tie' };
}

function judge(s) {
  const [a, b] = s.riders;
  const res = compare(a, b);
  s.endT = -1;
  if (res.w < 0) {
    s.coursesMax++; s.course = s.crossings + 1; s.round = s.course;
    emit(s, 'extraCourse', { n: s.course });
    return;
  }
  emit(s, 'judgement', { w: res.w, by: res.by });
  ko(s, s.riders[1 - res.w], 'points', res.w, res.by);
}

// Slow motion on the approach to each crossing, once per pass [adapted].
function crossingSlowmo(s) {
  const [a, b] = s.riders;
  const gap = Math.abs(a.x - b.x);
  const approaching = (b.x - a.x) * a.facing > 0 && (a.x - b.x) * b.facing > 0;
  const closing = approaching ? a.v + b.v : 0;
  const fwd = Math.max(W(a).fwd, W(b).fwd);
  if (s.crossReady && approaching && closing > CROSSING.minClosing && gap < fwd + closing * CROSSING.lead) {
    s.crossReady = false;
    if (s.slowT <= 0) { s.slowT = CROSSING.slowT; s.slowScale = CROSSING.slowScale; }
    emit(s, 'crossing', { x: (a.x + b.x) / 2, v: closing });
  }
  if (!approaching && gap > 10) s.crossReady = true;
}
