// Bikes & Blades — joust bot (v3). It sends the same input frames as a player
// and obeys the same rules: one lance attack (or two sword strokes) per course,
// turns only inside the turning ends, the same fouls. Its skill is how close it
// aims to the band it wants, how well it times the release, and how often it
// guards or tries a parry.
import { BOT_LEVELS, WEAPONS, ATTACKS, AIM, ARENA, BIKE, laneOffset } from './data.js';

export function createBot(index, level = 1, seed = 1) {
  return {
    i: index, level, L: BOT_LEVELS[level],
    rng: mulberry(seed * 9301 + index * 49297 + 7),
    out: { gas: 0, brake: 0, inL: 0, outL: 0, aimH: 0, aimA: 0, ac: 0, at: 0, guard: 0, gc: 0 },
    plan: null, facing: 0,
  };
}

function mulberry(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Hand height and tip angle that put the tip at height y for this attack.
export function aimFor(weapon, atk, y) {
  const dy = WEAPONS[weapon].attacks[atk].tipDY;
  const want = y - AIM.handY - dy;
  const H = Math.max(-1, Math.min(1, want / AIM.handRange));
  const rest = want - H * AIM.handRange;
  const A = Math.max(-1, Math.min(1, Math.asin(Math.max(-1, Math.min(1, rest / AIM.tipLen))) / AIM.maxAngle));
  return { H, A };
}

function newPlan(bot, me) {
  const R = bot.rng, L = bot.L;
  const helm = R() < L.helmGoal;
  const y = (helm ? 2.19 : 1.6) + (R() * 2 - 1) * L.aimErr;
  let atk = 'thrust';
  if (me.weapon === 'lance') { if (helm && R() < 0.25) atk = 'smash'; }
  else atk = helm ? (R() < 0.6 ? 'smash' : 'thrust') : (R() < 0.5 ? 'thrust' : 'cut');
  return {
    y, atk, aim: aimFor(me.weapon, atk, y),
    jitter: (R() * 2 - 1) * L.timing,
    guard: R() < L.guard, parry: R() < L.parry, parried: false,
    skid: R() < L.skid,
    line: me.weapon === 'sword' ? 0.93 : 0.45 + 0.25 * L.lineSkill + (R() - 0.5) * 0.1,
  };
}

export function botThink(bot, s, dt) {
  const me = s.riders[bot.i], op = s.riders[1 - bot.i];
  const o = bot.out, L = bot.L, R = bot.rng;
  o.gas = 0; o.brake = 0; o.inL = 0; o.outL = 0;
  if (!bot.plan || bot.facing !== me.facing) { bot.plan = newPlan(bot, me); bot.facing = me.facing; }
  const P = bot.plan;
  o.aimH = P.aim.H; o.aimA = P.aim.A;
  if (s.phase === 'ready' || s.phase === 'intro') { o.guard = 0; return o; } // wait for the herald
  if (s.phase !== 'fight') { o.brake = 1; o.guard = 0; return o; }

  const Wp = WEAPONS[me.weapon];
  const along = (op.x - me.x) * me.facing;
  const approaching = along > 0 && (me.x - op.x) * op.facing > 0;
  const closing = me.v + op.v;

  // line
  if (me.line < P.line - 0.03) o.inL = 1; else if (me.line > P.line + 0.03) o.outL = 1;

  // ride: gas toward the rival; after the crossing ride on, then brake into the turning end
  const pos = me.x * me.facing;
  if (along > 0) {
    o.gas = me.act === 'turn' || me.act === 'skid' ? 0 : 1;
  } else {
    // a plain turn: brake early enough to be slow inside the end; a skid: brake late, inside it
    const vt = BIKE.turnMaxSpeed - 1.5;
    const stop = Math.max(0, (me.v * me.v - vt * vt) / (2 * BIKE.brake));
    const skidOk = P.skid && me.v < BIKE.skidMaxSpeed + 4;
    const brakeAt = skidOk ? ARENA.endZone + 0.8 : ARENA.endZone + 1.5 - stop;
    if (pos >= brakeAt || me.braking) o.brake = 1; else o.gas = 1;
  }

  // shield: read the rival's wind-up
  let guard = false;
  const winding = op.act === 'windup' && op.actT >= L.reaction;
  const striking = op.act === 'active' && !op.hitDone;
  const threat = (winding || striking) && (approaching || Math.abs(along) < 2);
  // a plain guard goes up early, on the approach, so it blocks rather than parries
  if (P.guard && approaching && along < 14 + closing * 0.4) guard = true;
  if (threat && P.parry) {
    // raise the shield just as the blade should arrive: the end of the wind-up plus the time to close
    const remain = (winding ? op.actDur - op.actT : 0) ;
    const reachT = Math.max(0, (Math.abs(along) - WEAPONS[op.weapon].fwd * 0.6) / Math.max(1, closing));
    if (Math.max(remain, reachT) <= 0.06) { guard = true; if (!P.parried) { o.gc++; P.parried = true; } }
    else if (P.parried) guard = true;
  }
  if (guard && !o.guard) o.gc++;
  o.guard = guard ? 1 : 0;

  // the blow: release so it lands just inside reach
  const gap = laneOffset(me.line) + laneOffset(op.line);
  const free = me.act === 'free';
  const canStrike = free && me.attacksLeft > 0 && !(me.weapon === 'lance' && me.lanceBroken) && gap <= Wp.reach;
  if (canStrike && approaching && closing > 1) {
    const wind = Wp.attacks[P.atk].windup;
    const tContact = (along - Wp.fwd * 0.55) / closing;
    if (tContact <= wind + P.jitter && along > 0.3) { o.at = ATTACKS.indexOf(P.atk); o.ac++; }
  } else if (canStrike && me.weapon === 'sword' && approaching && along > 0.5 + closing * 0.16 && along < Wp.fwd + closing * 0.16 && me.attacksLeft < Wp.attacksPerCourse) {
    // second sword stroke while still level with the rival
    o.at = ATTACKS.indexOf('thrust'); o.ac++;
  }
  return o;
}
