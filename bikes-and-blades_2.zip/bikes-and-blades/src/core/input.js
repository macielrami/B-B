// Mouse + keyboard + gamepad → joust input frames (v3).
// Frame: { gas, brake, inL, outL, aimH, aimA, ac, at, guard, gc }
//   aimH / aimA  weapon height and tip angle in [-1, 1]
//   ac / at      attack counter (bumps when an attack is released) and its type index
//   gc           counts fresh shield presses, so a parry tap is never lost
import { ATTACKS } from './data.js';

export const BINDINGS = {
  p1: { gas: ['KeyW'], brake: ['KeyS'], inL: ['KeyA'], outL: ['KeyD'], mouse: true,
        aimUp: [], aimDown: [], aimL: [], aimR: [], attack: [], guard: [] },
  p2: { gas: ['ArrowUp'], brake: ['ArrowDown'], inL: ['ArrowLeft'], outL: ['ArrowRight'], mouse: false,
        aimUp: ['KeyI'], aimDown: ['KeyK'], aimL: ['KeyJ'], aimR: ['KeyL'], attack: ['KeyU'], guard: ['KeyO'] },
  // single player: the mouse, plus either key set
  solo: { gas: ['KeyW', 'ArrowUp'], brake: ['KeyS', 'ArrowDown'], inL: ['KeyA', 'ArrowLeft'], outL: ['KeyD', 'ArrowRight'], mouse: true,
          aimUp: ['KeyI'], aimDown: ['KeyK'], aimL: ['KeyJ'], aimR: ['KeyL'], attack: ['KeyU'], guard: ['KeyO'] },
};

const FLICK = 0.06;  // a flick shorter than this (in screen fractions) is a plain thrust

// Which attack a gesture means, relative to the way the rider faces:
// toward the rival = thrust, down = smash, up = rising cut, back = slash across the tilt.
export function gestureAttack(dx, dyUp, facing) {
  const fwd = dx * (facing || 1);
  if (Math.hypot(dx, dyUp) < FLICK) return 'thrust';
  if (Math.abs(dyUp) > Math.abs(fwd)) return dyUp > 0 ? 'cut' : 'smash';
  return fwd >= 0 ? 'thrust' : 'slash';
}

export class Input {
  constructor() {
    this.down = new Set();
    this.pressedThisFrame = new Set();
    this.releasedThisFrame = new Set();
    this.listeners = [];
    this.gamepadPrev = {};
    this.slots = {};
    this.lastDevice = 'keyboard';
    this.mouse = { x: 0, y: 0, lmb: false, rmb: false, start: null, releases: [], rPress: 0, active: false };
    window.addEventListener('keydown', e => {
      if (e.repeat) return;
      this.down.add(e.code);
      this.pressedThisFrame.add(e.code);
      this.lastDevice = 'keyboard';
      for (const fn of this.listeners) fn(e.code, e);
      if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Slash'].includes(e.code) && !isTyping(e)) e.preventDefault();
    });
    window.addEventListener('keyup', e => { this.down.delete(e.code); this.releasedThisFrame.add(e.code); });
    window.addEventListener('blur', () => { this.down.clear(); this.mouse.lmb = this.mouse.rmb = false; });
    const M = this.mouse;
    const pos = e => { M.x = (e.clientX / innerWidth) * 2 - 1; M.y = -((e.clientY / innerHeight) * 2 - 1); };
    window.addEventListener('pointermove', e => { pos(e); if (e.pointerType === 'mouse') { M.active = true; M.moves = (M.moves || 0) + 1; } });
    window.addEventListener('pointerdown', e => {
      if (e.pointerType !== 'mouse' || !M.capture) return;
      pos(e);
      if (e.button === 0) { M.lmb = true; M.start = { x: M.x, y: M.y }; M.lock = { x: M.x, y: M.y }; }
      if (e.button === 2) { M.rmb = true; M.rPress++; }
    });
    window.addEventListener('pointerup', e => {
      if (e.pointerType !== 'mouse') return;
      pos(e);
      if (e.button === 0 && M.lmb) { M.lmb = false; M.releases.push({ dx: M.x - M.start.x, dy: M.y - M.start.y }); M.start = null; M.lock = null; }
      if (e.button === 2) M.rmb = false;
    });
    window.addEventListener('contextmenu', e => { if (M.capture) e.preventDefault(); });
  }

  // main.js turns mouse capture on during a match, so menus keep normal clicks
  setCapture(on) { this.mouse.capture = on; if (!on) { this.mouse.lmb = this.mouse.rmb = false; this.mouse.releases = []; } }
  onKey(fn) { this.listeners.push(fn); return () => { this.listeners = this.listeners.filter(f => f !== fn); }; }
  any(codes) { return codes.some(c => this.down.has(c)); }
  pressed(codes) { return codes.some(c => this.pressedThisFrame.has(c)); }
  released(codes) { return codes.some(c => this.releasedThisFrame.has(c)); }

  // facing: the rider's direction (+1 right on screen, −1 left) — the gesture is read against it
  frame(slot, bindingName, pad = -1, facing = 1, dt = 1 / 60) {
    const b = BINDINGS[bindingName];
    const S = this.slots[slot] || (this.slots[slot] = { ac: 0, at: 0, gc: 0, kH: 0, kA: 0, kDir: null, usedKeys: false });
    const f = {
      gas: this.any(b.gas) ? 1 : 0, brake: this.any(b.brake) ? 1 : 0,
      inL: this.any(b.inL) ? 1 : 0, outL: this.any(b.outL) ? 1 : 0,
      aimH: 0, aimA: 0, ac: 0, at: 0, guard: 0, gc: 0,
    };

    // keyboard aim (P2, or anyone without a mouse): I/K raise and lower, J/L tilt the tip
    const kRate = 1.8 * dt;
    const attackHeld = this.any(b.attack);
    if (!attackHeld) {
      if (this.any(b.aimUp)) { S.kH = Math.min(1, S.kH + kRate); S.usedKeys = true; }
      if (this.any(b.aimDown)) { S.kH = Math.max(-1, S.kH - kRate); S.usedKeys = true; }
      if (this.any(b.aimR)) { S.kA = Math.min(1, S.kA + kRate); S.usedKeys = true; }
      if (this.any(b.aimL)) { S.kA = Math.max(-1, S.kA - kRate); S.usedKeys = true; }
    } else {
      // while the attack key is held, a direction key picks the attack
      if (this.pressed(b.aimUp)) S.kDir = [0, 1];
      if (this.pressed(b.aimDown)) S.kDir = [0, -1];
      if (this.pressed(b.aimR)) S.kDir = [1, 0];
      if (this.pressed(b.aimL)) S.kDir = [-1, 0];
    }
    if (this.released(b.attack)) {
      const d = S.kDir || [0, 0];
      S.at = ATTACKS.indexOf(gestureAttack(d[0], d[1], facing)); S.ac++; S.kDir = null;
    }
    if (this.pressed(b.guard)) S.gc++;
    f.guard = this.any(b.guard) ? 1 : 0;
    f.aimH = S.kH; f.aimA = S.kA;

    // mouse: position = aim (frozen while the button is held), button flick = attack, right button = shield
    const M = this.mouse;
    if (b.mouse && M.moves !== S.mSeen) { S.mSeen = M.moves; S.usedKeys = false; }
    if (b.mouse && M.active && !S.usedKeys) {
      const p = M.lock || M;
      f.aimH = clamp(p.y * 1.25); f.aimA = clamp(p.x * 1.25);
    }
    if (b.mouse) {
      while (M.releases.length) {
        const r = M.releases.shift();
        S.at = ATTACKS.indexOf(gestureAttack(r.dx, r.dy, facing)); S.ac++;
      }
      if (M.rPress !== S.rSeen) { S.gc += M.rPress - (S.rSeen || 0); S.rSeen = M.rPress; }
      if (M.rmb) f.guard = 1;
    }

    // gamepad: RT gas, LT brake, left stick line, right stick aim; hold RB, flick the right stick, release = attack; LB shield
    const gp = pad >= 0 ? readPad(pad) : null;
    if (gp) {
      const prev = this.gamepadPrev[pad] || {};
      const ax = gp.axes[0] || 0, rx = gp.axes[2] || 0, ry = -(gp.axes[3] || 0);
      const btn = i => !!(gp.buttons[i] && gp.buttons[i].pressed);
      const val = i => (gp.buttons[i] ? gp.buttons[i].value || (gp.buttons[i].pressed ? 1 : 0) : 0);
      const g = { gas: val(7) > 0.3, brake: val(6) > 0.3, inL: ax < -0.4 || btn(14), outL: ax > 0.4 || btn(15), atk: btn(5), guard: btn(4) || btn(1) };
      if (g.gas || g.brake || g.atk || g.guard || Math.hypot(rx, ry) > 0.3) this.lastDevice = 'gamepad';
      f.gas |= g.gas; f.brake |= g.brake; f.inL |= g.inL; f.outL |= g.outL;
      if (Math.hypot(rx, ry) > 0.2 && !g.atk) { f.aimH = ry; f.aimA = rx; S.padAim = [rx, ry]; }
      else if (S.padAim) { f.aimH = S.padAim[1]; f.aimA = S.padAim[0]; }
      if (g.atk && !prev.atk) S.padStart = [rx, ry];
      if (!g.atk && prev.atk) { const st = S.padStart || [0, 0]; S.at = ATTACKS.indexOf(gestureAttack((rx - st[0]) * 0.3, (ry - st[1]) * 0.3, facing)); S.ac++; }
      if (g.guard) f.guard = 1;
      if (g.guard && !prev.guard) S.gc++;
      this.gamepadPrev[pad] = g;
    }
    f.ac = S.ac; f.at = S.at; f.gc = S.gc;
    return f;
  }

  // The attack the mouse gesture would make right now (for the HUD preview).
  pendingGesture(facing) {
    const M = this.mouse;
    if (!M.lmb || !M.start) return null;
    return gestureAttack(M.x - M.start.x, M.y - M.start.y, facing);
  }

  padNav() {
    const pads = safePads();
    for (const gp of pads) {
      if (!gp) continue;
      const key = 'nav' + gp.index;
      const prev = this.gamepadPrev[key] || {};
      const ay = gp.axes[1] || 0, ax = gp.axes[0] || 0;
      const btn = i => !!(gp.buttons[i] && gp.buttons[i].pressed);
      const now = { up: ay < -0.5 || btn(12), down: ay > 0.5 || btn(13), left: ax < -0.5 || btn(14), right: ax > 0.5 || btn(15), ok: btn(0), back: btn(1) || btn(9) };
      this.gamepadPrev[key] = now;
      for (const k of ['up', 'down', 'left', 'right', 'ok', 'back']) if (now[k] && !prev[k]) { this.lastDevice = 'gamepad'; return k; }
    }
    return null;
  }

  endFrame() { this.pressedThisFrame.clear(); this.releasedThisFrame.clear(); }
}

const clamp = v => Math.max(-1, Math.min(1, v));
// Some hosts (an embedded frame with a permissions policy) forbid the Gamepad API and
// throw on access: treat that as "no gamepads" rather than crashing the game loop.
let padsBlocked = false;
function safePads() {
  if (padsBlocked || !navigator.getGamepads) return [];
  try { return navigator.getGamepads() || []; } catch { padsBlocked = true; return []; }
}
function readPad(i) { return safePads()[i] || null; }
function isTyping(e) { const t = e.target; return t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA'); }
export function connectedPads() { const pads = safePads(); return [...pads].filter(Boolean).map(p => p.index); }
