// Joust HUD: balance, score in spears, helm/shield wear, weapon state, course
// count, the judges' calls, aim and tell markers, banner.
import { RIDER, RIDERS, ROMAN, WEAPONS, ATTACK_NAME, laneOffset } from '../core/data.js';
import * as THREE from 'three';

const $ = (s, r = document) => r.querySelector(s);
const ATK_ANGLE = { thrust: 0, smash: -60, cut: 60, slash: 180 };
const BAND_LABEL = { tilt: 'Tilt · foul', horse: 'Bike · foul', saddle: 'Saddle · −1', body: 'Body · 1', helm: 'Helm · 2', sight: 'Sight · 2', over: 'Over the head', reach: 'Out of reach · ride closer' };

export class Hud {
  constructor() {
    this.root = $('#hud');
    this.sides = [this.side($('#hud-p1')), this.side($('#hud-p2'))];
    this.timer = $('#hud-timer');
    this.roundLabel = $('#hud-round');
    this.callouts = $('#callouts');
    this.judges = $('#judges');
    this.markerRoot = $('#markers');
    this.hint = $('#hud-hint');
    this.netstat = $('#netstat');
    this.banner = $('#banner');
    this.markers = [this.mkMarker(), this.mkMarker()];
    this.ghost = [1, 1]; this.ghostHold = [0, 0]; this.lastHp = [1, 1];
    this.v = new THREE.Vector3();
  }
  side(el) {
    return {
      el, name: $('.pname', el), tag: $('.ptag', el),
      vigor: $('.vigor .fill', el), ghost: $('.vigor .ghost', el),
      spears: $('.score .spears', el), detail: $('.score .sc-detail', el),
      equip: ['helmet', 'shieldp'].map(k => ({ el: $('.' + k, el), pips: [...el.querySelectorAll('.' + k + ' .pips i')], key: k === 'shieldp' ? 'shield' : 'helmet' })),
      weap: $('.swordp', el), weapPips: [...el.querySelectorAll('.swordp .pips i')], weapStat: $('.weapstat', el),
      tach: $('.tach', el), gear: $('.tach .gear', el), needle: $('.tach .needle', el),
    };
  }
  mkMarker() {
    const m = document.createElement('div'); m.className = 'marker high';
    m.innerHTML = '<span class="tag"></span><span class="arrow">→</span>';
    this.markerRoot.appendChild(m);
    return m;
  }
  show(on) { this.root.hidden = !on; }
  setup(state, labels, humans, hintHtml) {
    state.riders.forEach((r, i) => {
      const s = this.sides[i];
      s.name.textContent = RIDERS[r.id].name;
      s.tag.textContent = labels[i];
    });
    this.humans = humans;
    this.hint.innerHTML = hintHtml || '';
    this.ghost = [1, 1]; this.lastHp = [1, 1];
    this.markers.forEach(m => { m.style.opacity = 0; });
    this.sides.forEach((s, i) => s.tach.classList.toggle('off', !humans[i]));
    this.callouts.innerHTML = ''; this.judges.innerHTML = '';
    this.setCourse(1, state.coursesMax);
  }
  showHints(on) { this.hint.hidden = !on; }
  setCourse(n, max) {
    this.timer.textContent = ROMAN[n] || n;
    this.roundLabel.textContent = n > max ? 'Extra course' : `Course ${ROMAN[n] || n} of ${ROMAN[max] || max}`;
  }

  // The judges' call: a line in the judges' panel, kept for a few seconds.
  judge(side, text, cls = 'bone') {
    const d = document.createElement('div');
    d.className = 'call ' + cls + (side === 1 ? ' right' : '');
    d.textContent = text;
    this.judges.appendChild(d);
    while (this.judges.children.length > 3) this.judges.firstChild.remove();
    setTimeout(() => d.classList.add('out'), 3600);
    setTimeout(() => d.remove(), 4200);
  }

  update(dt, state, camera, stances, canvasRect) {
    state.riders.forEach((r, i) => {
      const s = this.sides[i];
      const hp = Math.max(0, r.balance ?? r.hp) / RIDER.balance;
      s.vigor.style.transform = `scaleX(${hp})`;
      if (hp < this.lastHp[i] - 0.001) this.ghostHold[i] = 0.55;
      this.lastHp[i] = hp;
      this.ghostHold[i] -= dt;
      if (this.ghostHold[i] <= 0) this.ghost[i] += (hp - this.ghost[i]) * Math.min(1, dt * 3);
      if (this.ghost[i] < hp) this.ghost[i] = hp;
      s.ghost.style.transform = `scaleX(${this.ghost[i]})`;
      // score: spears, then the details the judges rank by
      const sc = r.score || { spears: 0, helm: 0, sight: 0, coronel: 0, fouls: {} };
      if (s.spears.textContent !== String(sc.spears)) { s.spears.textContent = sc.spears; s.spears.classList.remove('bump'); void s.spears.offsetWidth; s.spears.classList.add('bump'); }
      const f = sc.fouls || {};
      const nf = (f.tilt || 0) + (f.horse || 0) + (f.saddle || 0) + (f.falseStart || 0);
      const det = [sc.helm ? `helm ${sc.helm}` : '', sc.sight ? `sight ${sc.sight}` : '', sc.coronel ? `coronel ${sc.coronel}` : '', nf ? `fouls ${nf}` : ''].filter(Boolean).join(' · ');
      if (s.detail.textContent !== det) s.detail.textContent = det;
      for (const q of s.equip) {
        const v = r[q.key] === undefined ? 100 : r[q.key];
        const lost = v <= 0 ? 3 : v <= 25 ? 2 : v <= 60 ? 1 : 0;
        q.pips.forEach((p, k) => p.classList.toggle('lost', k >= 3 - lost));
        q.el.classList.toggle('dented', lost === 1 || lost === 2);
        q.el.classList.toggle('broken', lost === 3);
      }
      // weapon: attacks left this course
      const Wp = WEAPONS[r.weapon] || WEAPONS.lance;
      const left = r.weapon === 'lance' && r.lanceBroken ? 0 : r.attacksLeft ?? Wp.attacksPerCourse;
      s.weapPips.forEach((p, k) => { p.hidden = k >= Wp.attacksPerCourse; p.classList.toggle('lost', k >= left); });
      const stat = r.weapon === 'lance' ? (r.lanceBroken ? 'Broken · new lance at the end' : left ? 'Lance couched' : 'Spent this course') : (left ? `${left} stroke${left > 1 ? 's' : ''}` : 'Strokes spent');
      if (s.weapStat.textContent !== stat) s.weapStat.textContent = stat;
      s.weap.classList.toggle('spent', state.phase === 'fight' && !left);
      if (this.humans[i]) {
        s.gear.textContent = (r.gear || 0) + 1;
        s.needle.style.left = Math.min(98, (r.rpm || 0) * 100) + '%';
      }

      // markers: your aim band as you approach; the rival's attack while it winds up
      const m = this.markers[i];
      const busy = r.act === 'windup';
      const fallen = ['down', 'getup', 'walk', 'mount'].includes(r.act);
      const showOwn = this.humans[i] && state.phase === 'fight' && (fallen || r.cueBand || r.shieldUp || r.act === 'turn' || r.act === 'skid' || r.waiting || state.riders[1 - i].waiting);
      const showTell = !this.humans[i] && busy && state.phase === 'fight';
      if (showOwn || showTell) {
        this.v.set(r.x, 3.05, r.lane).project(camera);
        const x = (this.v.x * 0.5 + 0.5) * canvasRect.width, y = (-this.v.y * 0.5 + 0.5) * canvasRect.height;
        m.style.left = x + 'px'; m.style.top = y + 'px';
        let tag, cls = '', ang = null;
        if (showTell) { tag = ATTACK_NAME[r.atk] || 'Attack'; cls = ' tell'; ang = ATK_ANGLE[r.atk] ?? 0; }
        else if (fallen) { tag = { down: 'Unhorsed', getup: 'Getting up…', walk: 'Back to the bike', mount: 'Lifting the bike' }[r.act]; cls = ' spent'; }
        else if (r.act === 'turn' || r.act === 'skid' || r.act === 'wide') tag = r.act === 'skid' ? 'Skid turn' : r.act === 'wide' ? 'Wide turn' : 'Turning';
        else if (r.waiting) { tag = 'Waiting for the rival'; cls = ' spent'; }
        else if (state.riders[1 - i].waiting) { tag = 'Ride to the end and turn · your rival waits'; cls = ' tell'; }
        else if (r.cue === 'now') { tag = 'Release!'; cls = ' tell'; }
        else if (r.cueBand) { tag = BAND_LABEL[r.cueBand] || r.cueBand; cls = /foul|reach/.test(tag) ? ' spent' : ''; }
        else tag = 'Shield up';
        if (r.shieldUp && !showTell && r.cue !== 'now') tag += ' · shield';
        m.className = 'marker' + cls;
        if (m.firstChild.textContent !== tag) m.firstChild.textContent = tag;
        m.lastChild.style.display = ang === null ? 'none' : '';
        if (ang !== null) m.lastChild.style.transform = `rotate(${r.facing > 0 ? ang : 180 - ang}deg)`;
        m.style.opacity = showTell ? 1 : 0.9;
      } else m.style.opacity = 0;
    });
  }

  callout(text, cls = '', dur = 1.25) {
    const d = document.createElement('div');
    d.className = 'callout ' + cls;
    d.textContent = text;
    d.style.animationDuration = dur + 's';
    this.callouts.appendChild(d);
    while (this.callouts.children.length > 3) this.callouts.firstChild.remove();
    setTimeout(() => d.remove(), dur * 1000 + 50);
  }

  showBanner(text, sub, win) {
    this.banner.hidden = false;
    this.banner.classList.toggle('win', !!win);
    const t = this.banner.querySelector('.btext'), s = this.banner.querySelector('.bsub');
    t.textContent = text; s.textContent = sub || '';
    t.style.animation = 'none'; s.style.animation = 'none'; void t.offsetWidth;
    t.style.animation = ''; s.style.animation = '';
  }
  hideBanner() { this.banner.hidden = true; }
  setNet(text) { this.netstat.hidden = !text; this.netstat.textContent = text || ''; }
}
