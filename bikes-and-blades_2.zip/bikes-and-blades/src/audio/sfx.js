// Minimal procedural SFX (Web Audio). No samples: everything is synthesized.
export class Sfx {
  constructor() {
    this.ctx = null; this.enabled = false;
    this.vol = { master: 0.8, sfx: 0.9 };
    this.engines = [];
  }

  // Must be called from a user gesture.
  unlock() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const c = this.ctx = new AC();
    this.master = c.createGain(); this.master.gain.value = this.vol.master;
    const comp = c.createDynamicsCompressor(); comp.threshold.value = -14; comp.ratio.value = 4;
    this.master.connect(comp); comp.connect(c.destination);
    this.bus = c.createGain(); this.bus.gain.value = this.vol.sfx; this.bus.connect(this.master);
    // reverb send: generated stone-hall impulse
    this.verb = c.createConvolver(); this.verb.buffer = this.impulse(2.6, 2.2);
    this.verbIn = c.createGain(); this.verbIn.gain.value = 0.35;
    this.verbIn.connect(this.verb); this.verb.connect(this.bus);
    this.noise = this.noiseBuffer(2);
    this.enabled = true;
    this.startWind();
  }

  setVolumes(master, sfx) {
    this.vol.master = master; this.vol.sfx = sfx;
    if (this.ctx) { this.master.gain.value = master; this.bus.gain.value = sfx; }
  }

  impulse(sec, decay) {
    const c = this.ctx, n = Math.floor(c.sampleRate * sec), b = c.createBuffer(2, n, c.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = b.getChannelData(ch); for (let i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, decay); }
    return b;
  }
  noiseBuffer(sec) {
    const c = this.ctx, n = Math.floor(c.sampleRate * sec), b = c.createBuffer(1, n, c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    return b;
  }

  out(pan = 0, wet = 0.3) {
    const c = this.ctx, g = c.createGain();
    const p = c.createStereoPanner ? c.createStereoPanner() : null;
    if (p) { p.pan.value = Math.max(-1, Math.min(1, pan)); g.connect(p); p.connect(this.bus); if (wet) { const s = c.createGain(); s.gain.value = wet; p.connect(s); s.connect(this.verbIn); } }
    else g.connect(this.bus);
    return g;
  }
  env(g, t, a, peak, d) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(peak, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }
  noiseSrc(t, dur) {
    const s = this.ctx.createBufferSource(); s.buffer = this.noise; s.loop = true;
    s.start(t, Math.random() * 1.5); s.stop(t + dur + 0.05); return s;
  }
  tone(type, f0, f1, t, dur, peak, dest, a = 0.003) {
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
    this.env(g, t, a, peak, dur); o.connect(g); g.connect(dest); o.start(t); o.stop(t + dur + a + 0.05);
  }
  filtered(type, freq, q, t, dur, peak, dest, f1 = freq, a = 0.004) {
    const n = this.noiseSrc(t, dur + a), f = this.ctx.createBiquadFilter(), g = this.ctx.createGain();
    f.type = type; f.frequency.setValueAtTime(freq, t); f.Q.value = q;
    if (f1 !== freq) f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    this.env(g, t, a, peak, dur); n.connect(f); f.connect(g); g.connect(dest);
  }

  // ---------------------------------------------------------------- one-shots
  play(name, pan = 0, k = 1) {
    if (!this.enabled) return;
    const c = this.ctx, t = c.currentTime;
    switch (name) {
      case 'swing': {
        const o = this.out(pan, 0.15);
        this.filtered('bandpass', 500, 1.6, t, 0.22 * k, 0.5, o, 2600);
        break;
      }
      case 'swingHeavy': {
        const o = this.out(pan, 0.2);
        this.filtered('bandpass', 260, 1.2, t, 0.34, 0.7, o, 1400);
        break;
      }
      case 'clang': case 'block': {
        const o = this.out(pan, 0.45);
        const base = name === 'clang' ? 620 : 430;
        [1, 2.41, 3.83, 5.2, 6.9].forEach((m, i) => this.tone('sine', base * m * (0.98 + Math.random() * 0.04), base * m, t, 0.9 / (1 + i * 0.6), 0.22 / (1 + i), o));
        this.filtered('highpass', 3000, 0.7, t, 0.05, 0.6, o);
        this.tone('triangle', 160, 70, t, 0.12, 0.35, o);
        break;
      }
      case 'parry': {
        const o = this.out(pan, 0.7);
        [1, 1.5, 2.0, 2.98, 4.1].forEach((m, i) => this.tone('sine', 880 * m, 880 * m * 0.995, t, 1.8 / (1 + i * 0.4), 0.16 / (1 + i * 0.5), o));
        this.filtered('highpass', 5000, 0.5, t, 0.08, 0.5, o);
        this.filtered('bandpass', 2000, 2, t + 0.02, 0.6, 0.15, o, 6000);
        break;
      }
      case 'hit': {
        const o = this.out(pan, 0.25);
        this.tone('sine', 140 * k, 38, t, 0.22, 0.9, o);
        this.filtered('lowpass', 1800, 0.8, t, 0.12, 0.8, o, 300);
        this.filtered('bandpass', 3200, 3, t, 0.08, 0.35, o);
        [1, 2.7, 4.4].forEach((m, i) => this.tone('square', 300 * m, 280 * m, t, 0.08, 0.03, o));
        break;
      }
      case 'hitLow': {
        const o = this.out(pan, 0.25);
        this.tone('sine', 110, 32, t, 0.25, 0.9, o);
        this.filtered('bandpass', 1400, 2, t, 0.18, 0.7, o, 600);
        [1, 1.9, 3.1].forEach((m) => this.tone('sawtooth', 210 * m, 190 * m, t, 0.12, 0.05, o));
        break;
      }
      case 'break': {
        const o = this.out(pan, 0.4);
        this.filtered('bandpass', 2500, 1.2, t, 0.35, 0.9, o, 900);
        for (let i = 0; i < 6; i++) this.tone('sine', 700 + Math.random() * 2400, 600, t + i * 0.05 + Math.random() * 0.04, 0.25, 0.12, o);
        this.tone('sine', 90, 40, t, 0.3, 0.7, o);
        break;
      }
      case 'explode': {
        const o = this.out(pan, 0.6);
        this.filtered('lowpass', 2400, 0.7, t, 1.6, 1.0, o, 120);
        this.tone('sine', 70, 28, t, 1.4, 1.0, o);
        this.filtered('bandpass', 900, 1, t + 0.05, 0.9, 0.4, o, 200);
        break;
      }
      case 'boost': {
        const o = this.out(pan, 0.2);
        this.filtered('highpass', 800, 0.6, t, 0.5, 0.5, o, 3000);
        this.tone('sawtooth', 90, 220, t, 0.45, 0.18, o);
        break;
      }
      case 'skid': {
        const o = this.out(pan, 0.15);
        this.filtered('bandpass', 1700, 4, t, 0.42, 0.35, o, 1100);
        this.filtered('lowpass', 500, 0.7, t, 0.4, 0.3, o);
        break;
      }
      case 'thud': {
        const o = this.out(pan, 0.3);
        this.tone('sine', 90, 30, t, 0.3, 0.9 * k, o);
        this.filtered('lowpass', 900, 0.7, t, 0.2, 0.6 * k, o, 200);
        break;
      }
      case 'toll': {
        // funeral bell for round start / KO
        const o = this.out(pan, 0.9);
        const f = 110 * k;
        [0.5, 1, 1.19, 1.5, 2.0, 2.52, 3.0].forEach((m, i) => this.tone('sine', f * m, f * m * 0.998, t, 4.5 / (1 + i * 0.35), 0.22 / (1 + i * 0.4), o, 0.002));
        break;
      }
      case 'horn': {
        const o = this.out(0, 0.6);
        const g = c.createGain(); g.connect(o);
        this.env(g, t, 0.08, 0.5, 1.0);
        [146.8, 220, 293.6].forEach(f => {
          const osc = c.createOscillator(), fl = c.createBiquadFilter();
          osc.type = 'sawtooth'; osc.frequency.setValueAtTime(f * 0.97, t); osc.frequency.linearRampToValueAtTime(f, t + 0.12);
          fl.type = 'lowpass'; fl.frequency.setValueAtTime(400, t); fl.frequency.linearRampToValueAtTime(1600, t + 0.3); fl.frequency.linearRampToValueAtTime(700, t + 1.1);
          osc.connect(fl); fl.connect(g); osc.start(t); osc.stop(t + 1.2);
        });
        break;
      }
      case 'roar': {
        const o = this.out(0, 0.6);
        this.filtered('bandpass', 420, 0.9, t, 2.4, 0.35, o, 300, 0.5);
        this.filtered('bandpass', 900, 1.4, t + 0.1, 1.8, 0.15, o, 600, 0.4);
        break;
      }
      case 'thunder': {
        const o = this.out((Math.random() - 0.5) * 1.2, 0.8);
        this.filtered('lowpass', 300, 0.6, t + 0.2, 3.2, 0.5, o, 60, 0.3);
        break;
      }
      case 'ui': {
        const o = this.out(0, 0.1);
        this.tone('triangle', 660, 640, t, 0.06, 0.12, o);
        break;
      }
      case 'uiOk': {
        const o = this.out(0, 0.3);
        this.tone('triangle', 440, 440, t, 0.1, 0.14, o);
        this.tone('triangle', 660, 660, t + 0.06, 0.18, 0.12, o);
        break;
      }
      case 'draw': {
        // steel sliding out of a leather scabbard
        const o = this.out(pan, 0.25);
        this.filtered('bandpass', 2400, 3, t, 0.22, 0.25, o, 5200);
        this.tone('sine', 1800, 2600, t + 0.16, 0.5, 0.05, o);
        break;
      }
      case 'charge': {
        const o = this.out(pan, 0.2);
        this.tone('sawtooth', 120, 360, t, 0.6, 0.06, o, 0.05);
        break;
      }
    }
  }

  // ---------------------------------------------------------------- loops
  startWind() {
    const c = this.ctx;
    const n = c.createBufferSource(); n.buffer = this.noise; n.loop = true;
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = 380; f.Q.value = 0.6;
    const g = c.createGain(); g.gain.value = 0.06;
    const lfo = c.createOscillator(), lg = c.createGain(); lfo.frequency.value = 0.09; lg.gain.value = 180;
    lfo.connect(lg); lg.connect(f.frequency); lfo.start();
    n.connect(f); f.connect(g); g.connect(this.bus); n.start();
    this.wind = g;
  }

  engine(i) {
    if (!this.enabled) return null;
    if (this.engines[i]) return this.engines[i];
    const c = this.ctx;
    const o1 = c.createOscillator(), o2 = c.createOscillator(), o3 = c.createOscillator();
    o1.type = 'sawtooth'; o2.type = 'square'; o3.type = 'sine';
    const f = c.createBiquadFilter(); f.type = 'lowpass'; f.Q.value = 3;
    const g = c.createGain(); g.gain.value = 0;
    const p = c.createStereoPanner ? c.createStereoPanner() : null;
    // a slow "lope" amplitude wobble for a V-twin feel
    const am = c.createGain(); am.gain.value = 1;
    const lope = c.createOscillator(), lg = c.createGain(); lope.frequency.value = 9; lg.gain.value = 0.35;
    lope.connect(lg); lg.connect(am.gain); lope.start();
    o1.connect(f); o2.connect(f); o3.connect(f); f.connect(am); am.connect(g);
    if (p) { g.connect(p); p.connect(this.bus); } else g.connect(this.bus);
    o1.start(); o2.start(); o3.start();
    const e = { o1, o2, o3, f, g, p, lope, rpm: 0 };
    this.engines[i] = e;
    return e;
  }
  updateEngine(i, speed, throttle, boost, pan, alive, damaged) {
    const e = this.engine(i);
    if (!e) return;
    const t = this.ctx.currentTime;
    const target = 30 + speed * 3.4 + Math.max(0, throttle) * 14 + (boost ? 40 : 0);
    e.rpm += (target - e.rpm) * 0.12;
    const f = e.rpm * (damaged ? 0.92 + Math.random() * 0.12 : 1);
    e.o1.frequency.setTargetAtTime(f, t, 0.03);
    e.o2.frequency.setTargetAtTime(f * 0.5, t, 0.03);
    e.o3.frequency.setTargetAtTime(f * 0.25, t, 0.03);
    e.lope.frequency.setTargetAtTime(6 + speed * 0.5, t, 0.1);
    e.f.frequency.setTargetAtTime(220 + speed * 38 + Math.max(0, throttle) * 260 + (boost ? 900 : 0), t, 0.05);
    e.g.gain.setTargetAtTime(alive ? 0.045 + Math.max(0, throttle) * 0.035 + (boost ? 0.04 : 0) : 0, t, 0.08);
    if (e.p) e.p.pan.setTargetAtTime(Math.max(-1, Math.min(1, pan)), t, 0.05);
  }
  silenceEngines() {
    if (!this.ctx) return;
    for (const e of this.engines) if (e) e.g.gain.setTargetAtTime(0, this.ctx.currentTime, 0.1);
  }
}
