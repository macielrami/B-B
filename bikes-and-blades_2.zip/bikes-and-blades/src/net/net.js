// Online duel: host-authoritative simulation.
// The host runs the sim and publishes compact snapshots; the guest publishes
// its input frame. Both travel as "latest state" messages, so a dropped packet
// is simply superseded by the next one.
//
// Two transports share one tiny interface:
//   RoomTransport — Claude artifact `room` capability (named rooms + presence)
//   WsTransport   — the bundled relay server (server/relay.mjs)
// interface: { selfId, send(obj), onPeer(fn(id, state)), onLeave(fn(id)), close() }

const ACTS = ['free', 'windup', 'active', 'recover', 'stagger', 'turn', 'skid', 'wide', 'down', 'getup', 'walk', 'mount'];
const KINDS = ['', 'parried', 'flinch', 'wall'];
const KO = ['', 'unhorsed', 'disqualified', 'points'];
const PHASES = ['intro', 'ready', 'fight', 'ko', 'matchEnd'];
const ATK = ['thrust', 'smash', 'cut', 'slash'];
const EV_KEYS = ['type', 'id', 't', 'r', 'a', 'd', 'x', 'y', 'z', 'dmg', 'band', 'brk', 'sight', 'shield', 'pts', 'kind', 'pen', 'n', 'dq', 'by', 'late', 'fresh', 'again', 'low', 'w', 'v', 'why', 'round', 'closing', 'q', 'g', 'item', 'lvl', 'tilt'];
const SCORE_KEYS = ['spears', 'breaks', 'helm', 'sight', 'coronel', 'unhorse', 'misses', 'unhelmed'];
const FOUL_KEYS = ['tilt', 'horse', 'saddle', 'falseStart', 'behind'];

const r2 = v => Math.round(v * 100) / 100;

export function encodeSnapshot(s, sinceEv) {
  const R = s.riders.map(r => [
    r2(r.x), r2(r.v), r.facing, r2(r.balance), r2(r.line), r2(r.lane),
    ACTS.indexOf(r.act), KINDS.indexOf(r.actKind), r2(r.actT), r2(r.actDur), ATK.indexOf(r.atk),
    r2(r.aimH), r2(r.aimA), r2(r.tipY), r.shieldUp ? 1 : 0, r.throttle, KO.indexOf(r.koKind), r.hitDone ? 1 : 0,
    r.gear, r2(r.rpm), r2(r.helmet), r2(r.shield), r2(r.sword), r.lanceBroken ? 1 : 0, r.attacksLeft, r.waiting ? 1 : 0, r2(r.bodyX || 0),
    ...SCORE_KEYS.map(k => r.score[k] || 0), ...FOUL_KEYS.map(k => r.score.fouls[k] || 0),
    r.stats.parries || 0,
  ]);
  const ev = s.events.filter(e => e.id > sinceEv).slice(-12).map(e => EV_KEYS.map(k => {
    const v = e[k]; return typeof v === 'number' ? r2(v) : v === undefined ? null : v;
  }));
  return {
    v: 4, ph: PHASES.indexOf(s.phase), pt: r2(s.phaseT), co: s.course, cm: s.coursesMax, cr: s.crossings,
    hs: r2(s.hitstop), sl: r2(s.slowT), ss: r2(s.slowScale), mw: s.matchWinner, vd: s.verdict,
    cfg: { riders: s.cfg.riders, weapons: s.cfg.weapons, mode: s.cfg.mode }, R, ev, eid: s.evId,
  };
}

// Applies a snapshot onto a guest-side mirror state (same shape as sim state).
export function applySnapshot(mirror, snap) {
  mirror.phase = PHASES[snap.ph]; mirror.phaseT = snap.pt; mirror.course = mirror.round = snap.co; mirror.coursesMax = snap.cm; mirror.crossings = snap.cr;
  mirror.hitstop = snap.hs; mirror.slowT = snap.sl; mirror.slowScale = snap.ss;
  mirror.matchWinner = mirror.roundWinner = snap.mw; mirror.verdict = snap.vd || '';
  snap.R.forEach((a, i) => {
    const r = mirror.riders[i];
    let k = 0; const n = () => a[k++];
    r.netX = n(); r.v = n(); r.facing = n(); r.balance = r.hp = n(); r.line = n(); r.lane = n();
    r.act = ACTS[n()] || 'free'; r.actKind = KINDS[n()] || ''; r.actT = n(); r.actDur = n(); r.atk = ATK[n()] || 'thrust';
    r.aimH = n(); r.aimA = n(); r.tipY = n(); r.shieldUp = !!n(); r.throttle = n(); r.koKind = KO[n()] || ''; r.hitDone = !!n();
    r.gear = n(); r.rpm = n(); r.helmet = n(); r.shield = n(); r.sword = n(); r.lanceBroken = !!n(); r.attacksLeft = n(); r.waiting = !!n(); r.bodyX = n();
    for (const key of SCORE_KEYS) r.score[key] = n();
    for (const key of FOUL_KEYS) r.score.fouls[key] = n();
    r.stats.parries = n();
    if (r.x === undefined || Math.abs(r.x - r.netX) > 6) r.x = r.netX;
    r.netT = performance.now();
  });
  for (const row of snap.ev) {
    const e = {}; EV_KEYS.forEach((key, j) => { if (row[j] !== null) e[key] = row[j]; });
    if (e.id > (mirror.evId || 0)) { mirror.events.push(e); mirror.evId = e.id; }
  }
  if (mirror.events.length > 60) mirror.events.splice(0, mirror.events.length - 60);
}

// Smooth guest-side positions toward the (extrapolated) authoritative ones.
export function smoothMirror(mirror, dt) {
  const now = performance.now();
  for (const r of mirror.riders) {
    if (r.netX === undefined) continue;
    const lead = Math.min(0.12, (now - r.netT) / 1000);
    const target = r.netX + (['down', 'getup', 'walk', 'mount', 'turn', 'skid', 'wide'].includes(r.act) ? 0 : r.facing * r.v * lead);
    r.x += (target - r.x) * Math.min(1, dt * 14);
  }
}

// ---------------------------------------------------------------- transports
export async function roomAvailable() {
  try {
    if (!window.claude || typeof window.claude.use !== 'function') return null;
    const room = await window.claude.use('room');
    return room || null;
  } catch { return null; }
}

export class RoomTransport {
  static async open(room, name) {
    const t = new RoomTransport();
    t.room = await room.join(name);
    t.peerFns = []; t.leaveFns = [];
    t.known = new Map();
    t.unsub = t.room.onPeers(change => {
      for (const p of change.peers) {
        if (p.sameTab) { t.selfId = p.peer; continue; }
        const st = p.presence || {};
        if (t.known.get(p.peer) !== st) { t.known.set(p.peer, st); for (const f of t.peerFns) f(p.peer, st); }
      }
      for (const p of change.left) { t.known.delete(p.peer); for (const f of t.leaveFns) f(p.peer); }
    }, () => {});
    return t;
  }
  send(obj) { this.room.presence(obj).catch(() => {}); }
  onPeer(fn) { this.peerFns.push(fn); }
  onLeave(fn) { this.leaveFns.push(fn); }
  connected() { return this.room.connected(); }
  close() { try { this.unsub && this.unsub(); this.room.leave(); } catch {} }
}

export class WsTransport {
  static open(url, name) {
    return new Promise((resolve, reject) => {
      const t = new WsTransport();
      t.peerFns = []; t.leaveFns = [];
      let ws;
      try { ws = new WebSocket(url); } catch (e) { reject(e); return; }
      t.ws = ws;
      const timer = setTimeout(() => { reject(new Error('timeout')); try { ws.close(); } catch {} }, 5000);
      ws.onopen = () => { ws.send(JSON.stringify({ t: 'join', room: name })); };
      ws.onerror = () => { clearTimeout(timer); reject(new Error('Could not reach the relay server at ' + url)); };
      ws.onclose = () => { t.closed = true; for (const f of t.leaveFns) f('*'); };
      ws.onmessage = (m) => {
        let d; try { d = JSON.parse(m.data); } catch { return; }
        if (d.t === 'joined') { t.selfId = d.id; clearTimeout(timer); resolve(t); }
        else if (d.t === 'p') for (const f of t.peerFns) f(d.id, d.s);
        else if (d.t === 'left') for (const f of t.leaveFns) f(d.id);
      };
    });
  }
  send(obj) {
    if (this.ws.readyState !== 1) return;
    // coalesce to ~60 Hz like presence
    this.pending = obj;
    if (!this.flushTimer) this.flushTimer = setTimeout(() => { this.flushTimer = null; if (this.ws.readyState === 1) this.ws.send(JSON.stringify({ t: 'p', s: this.pending })); }, 14);
  }
  onPeer(fn) { this.peerFns.push(fn); }
  onLeave(fn) { this.leaveFns.push(fn); }
  connected() { return this.ws.readyState === 1; }
  close() { try { this.ws.close(); } catch {} }
}

export function makeCode() {
  const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
  let s = ''; for (let i = 0; i < 4; i++) s += A[Math.floor(Math.random() * A.length)];
  return s;
}
export function roomName(code) { return 'bikes-blades-' + code.toLowerCase(); }
