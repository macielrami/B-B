# Test record

All tests below were run on the current build (v3: the joust at the tilt, lance or sword, plus the Reliquary look). They ran on a cloud Linux machine with no GPU, using headless Chromium 1194 with WebGL2 through SwiftShader. Frame rates there are 0.3 to 2 fps, so the browser tests drive the game by frames and conditions, not by wall-clock time.

## How to run

```bash
npm install && npm run build
node tests/sim.test.mjs          # headless simulation (LVL=0|1|2, N=matches)
node tests/rules.test.mjs        # the rulebook, rule by rule
npm start &                      # relay + static server on :8787 (the browser tests use it)
Q=low node tests/smoke.mjs       # UI + keyboard + match flow
node tests/online.mjs            # two browsers, host + guest over the relay
node tests/artifact.mjs          # the publishable page with three.js via import map
node tests/poses2.mjs            # pose gallery: every strike line and shield line
node tests/board-frames.mjs      # renders the art-board frames (key art, hero, combat, riders)
```

The browser tests expect Chromium at `/opt/pw-browsers/chromium-1194/chrome-linux/chrome`; edit `executablePath` to point at your own.

## Results

All results below are for v3, the joust at the tilt.

### 1. Rules (`tests/rules.test.mjs`)

All 28 checks pass. Each one is a scripted pass with no bots and no chance. They cover the game ruleset and, with the switches turned back on, the historical one.

- Scores in the game ruleset: body 1, helm 2, the sight 3. The saddle and the bike score nothing, and the tilt costs 1.
- Historical rules, when switched on, still work:
  - saddle −1;
  - the horse −2 with a warning;
  - the tilt −2;
  - a blow from behind disqualifies;
  - false starts are fouls;
  - the judges rank sight hits above spears.
- A miss over the head, the held shield, the parry, and two parries unhorsing.
- Turns happen only inside a turning end and take time; a late brake skids at a cost in balance.
- In the game ruleset the bikes are held until the herald's call.
- The first rider to turn waits until both have turned, then both ride off together.
- Both blows of a simultaneous exchange land.
- An unhorsed rider lies, gets up, walks back to the bike, mounts and rides on with 70 balance; the victor scores 3 and the match continues.
- There is no crash wall: riding past the end without braking carves a wide U-turn within the 10 m run-off.

### 1b. Simulation (`tests/sim.test.mjs`)

This runs bot-vs-bot for all four weapon pairings, 12 seeds each, at each level. Matches finish with 0 failures. Breaks, helm and body hits, parries, coronel-to-coronel, turns, skids and the judges' decisions all occur. Lance-vs-sword win rates sit between 0.4 and 0.75 for the lance, by design: the lance is the joust weapon.

A scripted player that aims at the body and releases at the gate won 80 to 95 % against Squire and Knight and 40 % against Lord of Cinder. A player who never rides lost every match.

Balance problems this test found and fixed:

| Problem | Fix |
| --- | --- |
| One lance hit unhorsed (matches lasted 17 s). | Balance damage cut by about two thirds. |
| Bots always skidded and never turned normally. | A skid happens only when the brake starts inside the turning end. |
| Late sword strokes counted as striking from behind. | Only a blow begun after the crossing counts; a late one is a miss. |
| The sword lost almost every match against the lance. | Sword reach 2.35 → 2.6 m, and a lance hit no longer cancels a sword wind-up. |
| Bots could not parry while attacking. | The shield is in the left hand and works during an attack. |
| With simultaneous exchanges, most matches ended in unhorsing. | Balance damage lowered about 20%, helm and sight multipliers lowered, and bots parry less often. |
| A plain raised guard counted as a parry. | Bots raise a plain guard early, on the approach. |

### 2. UI and input smoke test (`tests/smoke.mjs`)

All 23 checks pass, with real keyboard and mouse events:

- Boot, menu, How to Ride and settings work.
- Rider select works: `D` cycles riders, `S` cycles weapons.
- In the match:
  - `W` rides and the gearbox shifts on its own.
  - `A` moves the bike toward the tilt.
  - Moving the mouse up raises the weapon.
  - Holding the button, flicking down and releasing makes a smash.
  - A second lance attack in the same course is refused.
  - The right button raises the shield.
- Pause stops the simulation; Resume and Forfeit work.
- No page errors.

### 3. Online over the relay (`tests/online.mjs`)

All 11 checks pass, with two browser contexts connected through `server/relay.mjs`:

- The duel code handshake works, and both sides enter the match with the same riders.
- The guest's gas (`W`) moves the host's P2, and a guest attack (`U`) starts a wind-up on the host.
- Guest positions track the host, and host events reach the guest.
- When the guest leaves, the host returns to the menu.
- No page errors.

### 4. Publishable page (`tests/artifact.mjs`)

All 5 checks pass. `dist/artifact.html` boots, three.js and its addons resolve through the import map, a match starts, and there are no page errors.

### Visual review

- A pose gallery of throttle/scabbard, all five strike lines and all six shield lines.
- Art-board frames at 1920×1080 in pixel mode.

Fixes made from these:

- The rose window was hidden by the gallery.
- The moon was out of frame.
- God rays were too weak.
- Candles were oversized.
- The window light washed out the towers.
- The key-art flash overexposed the riders.
- The shader expected 25 palette colours instead of 24.

## Not verified here

- Frame rate on real GPUs.
- Gamepads. The mapping is implemented but no pad was connected.
- Online inside a published Claude artifact (the `room` transport), which needs two signed-in viewers.
- Touch controls on a real touch device.

### Blocked gamepads (`tests/gamepad-blocked.mjs`)

Inside a frame whose permissions policy forbids the Gamepad API (as the Claude artifact viewer does), `navigator.getGamepads()` throws a SecurityError. The game falls back to mouse and keyboard, plays a match, and logs no page errors.
