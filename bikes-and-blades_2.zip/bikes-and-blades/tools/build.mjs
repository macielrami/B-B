// Build: bundles src/ into single-file HTML pages.
//   dist/index.html     — standalone: three.js bundled in, runs offline / from the relay server
//   dist/artifact.html  — publishable page: three.js loaded from jsDelivr via an import map
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const THREE_VER = JSON.parse(fs.readFileSync(path.join(root, 'node_modules/three/package.json'), 'utf8')).version;
const CDN = `https://cdn.jsdelivr.net/npm/three@${THREE_VER}`;
const template = fs.readFileSync(path.join(root, 'src/ui/template.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/ui/style.css'), 'utf8');
fs.mkdirSync(path.join(root, 'dist'), { recursive: true });

async function bundle(external) {
  const r = await esbuild.build({
    entryPoints: [path.join(root, 'src/main.js')], bundle: true, format: 'esm', minify: !process.env.DEBUG, sourcemap: process.env.DEBUG ? 'inline' : false, write: false,
    target: ['es2020'], external, legalComments: 'none', logLevel: 'warning',
  });
  return r.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
}

const fill = (t, js, importmap) => {
  let out = t.replace('/*__CSS__*/', () => css).replace('/*__JS__*/', () => js);
  if (importmap) out = out.replace('__THREE_URL__', `${CDN}/build/three.module.min.js`).replace('__THREE_ADDONS__', `${CDN}/examples/jsm/`);
  else out = out.replace(/<script type="importmap">.*?<\/script>\n?/s, '');
  return out;
};

const jsCdn = await bundle(['three', 'three/*']);
const jsFull = await bundle([]);
const artifact = fill(template, jsCdn, true);
const standalone = '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"></head><body>\n' + fill(template, jsFull, false) + '\n</body></html>\n';
fs.writeFileSync(path.join(root, 'dist/artifact.html'), artifact);
fs.writeFileSync(path.join(root, 'dist/index.html'), standalone);
console.log(`three ${THREE_VER}`);
console.log(`dist/artifact.html  ${(artifact.length / 1024).toFixed(0)} KB (three.js from CDN)`);
console.log(`dist/index.html     ${(standalone.length / 1024).toFixed(0)} KB (standalone)`);
