#!/usr/bin/env bash
# Builds and zips the project (sources + built dist, no node_modules).
set -euo pipefail
cd "$(dirname "$0")/.."
node tools/build.mjs
OUT="${1:-../bikes-and-blades.zip}"
rm -f "$OUT"
cd ..
zip -qr "$OUT" bikes-and-blades -x 'bikes-and-blades/node_modules/*' 'bikes-and-blades/.git/*'
echo "wrote $(cd "$(dirname "$OUT")" && pwd)/$(basename "$OUT")"
