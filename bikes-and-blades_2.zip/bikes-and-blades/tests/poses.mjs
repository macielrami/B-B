// Pose gallery: freezes the sim and dresses both riders in each action state.
import { execFileSync } from 'node:child_process';
const out = process.argv[2] || '/tmp/claude-0/poses';
const weapons = (process.argv[3] || 'lance,flail').split(',');
const riders = (process.argv[4] || 'aldric,vorn').split(',');
const poses = (process.argv[5] || 'free:high,windup:high,active:high,windup:low,active:low,guard:high,guard:low,stagger:high').split(',');
const steps = [
  { until: 'window.__bb && window.__bb.screen==="title"', timeout: 90000 },
  { eval: `window.__bb.quickStart({mode:'local', riders:${JSON.stringify(riders)}, weapons:${JSON.stringify(weapons)}}); 1` },
  { wait: 1500 },
  { eval: `(()=>{const A=window.__bb; A.timeScale=0; const s=A.state; s.phase='fight'; s.riders[0].x=-1.7; s.riders[1].x=1.7; s.riders[0].v=0; s.riders[1].v=0; A.director.setMode('select'); document.querySelector('#hud').hidden=true; return 1})()` },
];
for (const p of poses) {
  const [act, h] = p.split(':');
  steps.push({ eval: `(()=>{const s=window.__bb.state; for(const r of s.riders){r.act='${act}'; r.height='${h}'; r.actT=${act === 'active' ? 0.05 : 0.1}; r.actKind='flinch'; r.actDur=1; r.charge=0;} return 1})()` });
  steps.push({ wait: 3500 });
  steps.push({ shot: `${riders[0]}-${weapons[0]}-${act}-${h}` });
}
execFileSync('node', ['tests/shoot.mjs', out, JSON.stringify(steps), 'test'], { stdio: 'inherit' });
