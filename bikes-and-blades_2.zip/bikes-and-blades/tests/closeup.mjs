// Character close-ups: each rider + weapon, side-on, in a guard and a strike pose.
import { execFileSync } from 'node:child_process';
const out = process.argv[2] || '/tmp/claude-0/close';
const pairs = (process.argv[3] || 'aldric:lance,pilgrim:axe,maelis:mace,vorn:flail').split(',').map(p => p.split(':'));
const pose = process.argv[4] || 'free:high';
const steps = [{ until: 'window.__bb && window.__bb.screen==="title"', timeout: 90000 }];
for (const [rider, weapon] of pairs) {
  const [act, h] = pose.split(':');
  steps.push({ eval: `(()=>{const A=window.__bb; A.quickStart({mode:'local', riders:['${rider}','vorn'], weapons:['${weapon}','sword']}); A.timeScale=0; const s=A.state; s.phase='fight'; s.riders[0].x=0; s.riders[1].x=30; document.querySelector('#hud').hidden=true; A.camOverride={pos:[0.2,1.9,${'${'}0}], look:[0,1.5,-1.55], fov:30}; for(const r of [s.riders[0]]){r.act='${act}'; r.height='${h}'; r.actT=0.1; r.actDur=9;} return 1})()`.replace('${0}', '4.6') });
  steps.push({ wait: 4000 });
  steps.push({ shot: `${rider}-${weapon}-${act}-${h}` });
}
execFileSync('node', ['tests/shoot.mjs', out, JSON.stringify(steps), 'test'], { stdio: 'inherit' });
