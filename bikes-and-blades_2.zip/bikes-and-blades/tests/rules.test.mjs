// The rulebook, checked rule by rule with scripted inputs (no bots, no chance).
import { createMatch, step, EMPTY_INPUT, tipHeight, compare } from '../src/core/sim.js';
import { aimFor } from '../src/core/ai.js';
import { ARENA, ATTACKS, RULES } from '../src/core/data.js';
const withHistoric = (fn) => { const save = { ...RULES }; Object.assign(RULES, { falseStart: true, saddleFoul: true, horseFoul: true, behindFoul: true, unhelmedDQ: true, tiltDQ: true, meritOrder: true }); try { fn(); } finally { Object.assign(RULES, save); } };

const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const fight = (w = ['lance', 'lance']) => { const s = createMatch({ riders: ['aldric', 'vorn'], weapons: w }); while (s.phase !== 'fight') step(s, [EMPTY_INPUT, EMPTY_INPUT]); return s; };
const ev = (s, type, f = () => true) => s.events.filter(e => e.type === type && f(e));

// A scripted pass: both ride at each other; rider 0 aims at height y and releases `atk`
// at the right moment; rider 1 rides straight (optionally guarding / parrying).
function pass(s, { y = 1.6, atk = 'thrust', guard = false, parry = false, line0 = 0.5 } = {}) {
  const a = s.riders[0], b = s.riders[1];
  a.line = line0;
  const aim = aimFor(a.weapon, atk, y);
  let i0 = { ...EMPTY_INPUT, gas: 1, aimH: aim.H, aimA: aim.A }, i1 = { ...EMPTY_INPUT, gas: 1 };
  for (let t = 0; t < 60 * 20 && s.phase === 'fight'; t++) {
    const along = (b.x - a.x) * a.facing, closing = a.v + b.v;
    const wind = { lance: { thrust: .16, smash: .42, cut: .4, slash: .5 }, sword: { thrust: .14, smash: .22, cut: .18, slash: .2 } }[a.weapon][atk];
    if (a.act === 'free' && a.attacksLeft > 0 && along > 0 && (along - 1.3) / Math.max(1, closing) <= wind) i0 = { ...i0, ac: i0.ac + 1, at: ATTACKS.indexOf(atk) };
    if (guard) i1 = { ...i1, guard: 1 };
    if (parry && a.act === 'windup' && a.actDur - a.actT < 0.05 && !i1.guard) i1 = { ...i1, guard: 1, gc: i1.gc + 1 };
    step(s, [i0, i1]);
    if (s.crossings >= 1 && a.act !== 'windup' && a.act !== 'active') break;
  }
}

{ const s = fight(); pass(s, { y: 1.6 });
  ok(ev(s, 'score', e => e.r === 0 && e.kind === 'body').length === 1 && s.riders[0].score.spears === 1, 'a lance broken on the body scores 1 spear');
  ok(s.riders[0].lanceBroken && ev(s, 'break').length === 1, 'a clean hit breaks the lance'); }
{ const s = fight(); pass(s, { y: 2.05 });
  ok(s.riders[0].score.spears === 2 && s.riders[0].score.helm === 1, 'a break on the helm scores 2 spears'); }
{ const s = fight(); pass(s, { y: 2.19 });
  ok(s.riders[0].score.sight === 1 && s.riders[0].score.spears === 3, 'a break on the sight of the helm scores 3 spears (game ruleset)'); }
withHistoric(() => { const s = fight(); pass(s, { y: 2.19 });
  ok(s.riders[0].score.sight === 1 && s.riders[0].score.spears === 2, 'historical: the sight counts a sight and 2 spears'); });
{ const s = fight(); pass(s, { y: 1.1 });
  ok(s.riders[0].score.spears === 0 && ev(s, 'glance').length >= 1, 'a hit on the saddle scores nothing (game ruleset)'); }
withHistoric(() => { const s = fight(); pass(s, { y: 1.1 });
  ok(s.riders[0].score.spears === -1 && s.riders[0].score.fouls.saddle === 1, 'historical: a break on the saddle costs 1 spear'); });
{ const s = fight(); pass(s, { y: 0.95 });
  ok(s.riders[0].score.spears === 0 && s.riders[0].score.fouls.horse === 0, 'a hit on the bike scores nothing, no foul (game ruleset)'); }
withHistoric(() => { const s = fight(); pass(s, { y: 0.95 });
  ok(s.riders[0].score.fouls.horse === 1 && s.riders[0].score.spears === -2, 'historical: striking the horse, −2 and a warning'); });
{ const s = fight(); pass(s, { y: 0.7 });
  ok(s.riders[0].score.fouls.tilt === 1 && s.riders[0].score.spears === -1, 'a weapon below the tilt strikes it: −1 spear'); }
withHistoric(() => { const s = fight(); pass(s, { y: 0.7 });
  ok(s.riders[0].score.spears === -2, 'historical: striking the tilt, −2'); });
{ const s = fight(); pass(s, { y: 2.7, atk: 'smash' });
  ok(s.riders[0].score.spears === 0 && ev(s, 'miss').length === 1, 'over the head is a miss, no score'); }
{ const s = fight(); pass(s, { y: 1.6, guard: true });
  ok(s.riders[0].score.spears === 1 && s.riders[1].balance > 100 - 30, 'a held shield halves the balance cost but the break still scores'); }
{ const s = fight(); pass(s, { y: 1.6, parry: true });
  const a = s.riders[0];
  ok(ev(s, 'parry').length === 1 && a.score.spears === 0 && a.balance <= 45 && !a.lanceBroken, 'a parry on impact: no break, no score, the attacker loses 55 balance'); }
{ const s = fight(); const a = s.riders[0];
  a.balance = 100 - 55; // balance left after one parry
  pass(s, { y: 1.6, parry: true });
  ok(a.act === 'down' && s.riders[1].score.unhorse === 1 && s.riders[1].score.spears === 3 && s.phase === 'fight', 'a second parry unhorses the attacker: 3 spears to the defender, and the match goes on'); }
{ // the unhorsed rider lies, gets up, walks back to the bike, lifts it and rides on
  const s = fight(); const a = s.riders[0];
  a.x = -5; a.v = 12; a.balance = 5;
  s.events.length = 0;
  // knock him off with a body hit from the rival
  const b = s.riders[1]; b.x = -3; b.facing = -1; b.v = 10;
  const aim = aimFor('lance', 'thrust', 1.6);
  Object.assign(b, { aimH: aim.H, aimA: aim.A, act: 'active', actT: 0, actDur: 0.12, atk: 'thrust', hitDone: false });
  const seen = new Set(); let t = 0;
  for (; t < 60 * 20 && !(seen.has('mount') && a.act === 'free'); t++) { step(s, [EMPTY_INPUT, { ...EMPTY_INPUT, aimH: aim.H, aimA: aim.A }]); seen.add(a.act); }
  ok(['down', 'getup', 'walk', 'mount'].every(k => seen.has(k)) && a.act === 'free' && a.balance === 70 && ev(s, 'remount').length === 1,
    `unhorsed → lies, gets up, walks to the bike, mounts (${(t / 60).toFixed(1)} s), back with 70 balance`); }
{ // no wall: running past the end of the lists without braking carves a wide U-turn on the open ground
  const s = fight(); const a = s.riders[0];
  a.x = ARENA.half - 2; a.v = 20; a.facing = 1; s.riders[1].x = -20;
  let maxX = 0, t = 0;
  for (; t < 60 * 6 && a.facing === 1; t++) { step(s, [{ ...EMPTY_INPUT, gas: 1 }, EMPTY_INPUT]); maxX = Math.max(maxX, a.x); }
  ok(ev(s, 'wide').length === 1 && a.facing === -1 && maxX <= ARENA.half + ARENA.runoff && !ev(s, 'wall').length && a.v > 0,
    `no crash wall: a wide U-turn on the run-off (furthest ${(maxX - ARENA.half).toFixed(1)} m past the lists, exits at ${a.v.toFixed(1)} m/s)`); }
withHistoric(() => { const s = fight(['sword', 'lance']); const a = s.riders[0];
  // a sword stroke begun after the crossing reaches the rider from behind: disqualified
  a.x = 1; s.riders[1].x = 0; a.facing = 1; s.riders[1].facing = -1; a.line = 1; s.riders[1].line = 1; s.lastSide = -1;
  let i0 = { ...EMPTY_INPUT, ac: 1, at: ATTACKS.indexOf('slash'), aimH: 0.6 };
  for (let t = 0; t < 40 && s.phase === 'fight'; t++) step(s, [i0, EMPTY_INPUT]);
  ok(s.riders[0].score.dq === 'behind' && s.matchWinner === 1, 'historical: a blow struck from behind disqualifies'); });
{ const s = fight(); const a = s.riders[0];
  a.x = 0; s.riders[1].x = 30; a.v = 5;
  for (let t = 0; t < 30; t++) step(s, [{ ...EMPTY_INPUT, brake: 1 }, EMPTY_INPUT]);
  ok(a.act !== 'turn' && a.facing === 1, 'no turning mid-lists, only inside a turning end');
  a.x = ARENA.endZone + 2; a.v = 4;
  for (let t = 0; t < 110; t++) step(s, [{ ...EMPTY_INPUT, brake: 1 }, EMPTY_INPUT]);
  ok(a.facing === -1 && ev(s, 'turned', e => e.r === 0).length === 1, 'braking inside the turning end turns the bike (not instantly)'); }
{ const s = fight(); const a = s.riders[0];
  a.x = ARENA.endZone + 1; a.v = 10; a.balance = 90;
  let minB = 100;
  for (let t = 0; t < 60; t++) { step(s, [{ ...EMPTY_INPUT, brake: 1 }, EMPTY_INPUT]); minB = Math.min(minB, a.balance); }
  ok(ev(s, 'skid', e => e.r === 0).length === 1 && minB < 90, 'braking late inside the end skids round, at a cost in balance'); }
{ const s = createMatch({ riders: ['aldric', 'vorn'] });
  while (s.phase !== 'ready') step(s, [EMPTY_INPUT, EMPTY_INPUT]);
  const x0 = s.riders[0].x;
  for (let t = 0; t < 60 && s.phase === 'ready'; t++) step(s, [{ ...EMPTY_INPUT, gas: 1 }, EMPTY_INPUT]);
  ok(s.riders[0].x === x0 && !ev(s, 'foul').length, 'the bikes are held until the herald\'s call: no false starts (game ruleset)'); }
withHistoric(() => { const s = createMatch({ riders: ['aldric', 'vorn'] });
  while (s.phase !== 'ready') step(s, [EMPTY_INPUT, EMPTY_INPUT]);
  for (let t = 0; t < 60 && s.phase === 'ready'; t++) step(s, [{ ...EMPTY_INPUT, gas: 1 }, EMPTY_INPUT]);
  ok(ev(s, 'foul', e => e.kind === 'falseStart').length >= 1, 'historical: moving off before the call is a false start'); });
{ const a = { i: 0, score: { coronel: 0, sight: 1, spears: 3 } }, b = { i: 1, score: { coronel: 0, sight: 0, spears: 6 } };
  ok(compare(a, b).w === 1, 'the match is decided on spears (game ruleset)');
  ok(compare(a, b, true).w === 0 && compare(a, b, true).by === 'sight', 'historical: the judges rank sight hits above the spear count'); }
{ // every course starts together: the first to turn waits at the end for the rival
  const s = fight(); const a = s.riders[0], b = s.riders[1];
  a.x = 10; a.facing = 1; b.x = 5; b.facing = -1; s.lastSide = -1; s.crossings = 1; a.turned = b.turned = false;
  a.x = ARENA.endZone + 2; a.v = 3; b.x = -10; b.v = 15;
  let waited = 0, t = 0;
  for (; t < 60 * 8 && !(ev(s, 'ride', e => e.again).length); t++) {
    step(s, [{ ...EMPTY_INPUT, gas: a.facing === -1 ? 1 : 0, brake: a.facing === 1 ? 1 : 0 }, { ...EMPTY_INPUT, gas: b.x * b.facing < ARENA.endZone ? 1 : 0, brake: b.x * b.facing >= ARENA.endZone ? 1 : 0 }]);
    if (a.waiting && a.v === 0) waited++;
  }
  ok(waited > 30 && a.facing === -1 && b.facing === 1 && ev(s, 'ride', e => e.again).length === 1, `the first rider to turn waits (${(waited / 60).toFixed(1)} s) until both have turned, then both ride off together`); }
{ // the exchange is simultaneous: both blows of the same instant land
  const s = fight(); const a = s.riders[0], b = s.riders[1];
  const aim = aimFor('lance', 'thrust', 1.6);
  a.x = -1.0; b.x = 1.0; a.v = b.v = 12;
  for (const r of [a, b]) { r.aimH = aim.H; r.aimA = aim.A; r.act = 'active'; r.actT = 0; r.actDur = 0.12; r.atk = 'thrust'; r.hitDone = false; }
  b.aimA = aim.A + 0.5; // different heights: no coronel
  step(s, [{ ...EMPTY_INPUT, aimH: aim.H, aimA: aim.A }, { ...EMPTY_INPUT, aimH: aim.H, aimA: aim.A + 0.5 }]);
  ok(ev(s, 'hit').length === 2, 'both blows of a simultaneous exchange land; neither cancels the other'); }
{ const s = fight(); pass(s, { y: 1.6 });
  const a = s.riders[0];
  ok(tipHeight({ ...a, aimH: 1, aimA: 1, weapon: 'lance' }) > tipHeight({ ...a, aimH: -1, aimA: -1, weapon: 'lance' }), 'aim height and angle move the tip'); }
