// Headless joust simulation: bot vs bot for every weapon pairing, many seeds,
// at one bot level (LVL env). Checks that matches finish, nothing goes NaN, the
// rules fire (breaks, bands, parries, fouls, turns), and prints how matches end.
import { createMatch, step } from '../src/core/sim.js';
import { createBot, botThink } from '../src/core/ai.js';
import { TICK, RIDER_ORDER, WEAPON_ORDER } from '../src/core/data.js';

const LVL = +(process.env.LVL ?? 1);
const N = +(process.env.N || 12);
const ev = {}, verdicts = {}, bands = {}, fouls = {}, atk = {};
let failures = 0, secs = 0, p1wins = 0, n = 0;
const byPair = {};
for (const w0 of WEAPON_ORDER) for (const w1 of WEAPON_ORDER) for (let seed = 1; seed <= N; seed++) {
  const riders = [RIDER_ORDER[seed % 4], RIDER_ORDER[(seed + 1) % 4]];
  const s = createMatch({ riders, weapons: [w0, w1] });
  const bots = [createBot(0, LVL, seed), createBot(1, LVL, seed + 1000)];
  let ticks = 0, last = 0;
  while (s.phase !== 'matchEnd' && ticks < 60 * 60 * 6) {
    step(s, bots.map(b => ({ ...botThink(b, s, TICK) })));
    ticks++;
    for (const e of s.events) if (e.id > last) {
      last = e.id; ev[e.type] = (ev[e.type] || 0) + 1;
      if (e.type === 'hit') bands[e.band] = (bands[e.band] || 0) + 1;
      if (e.type === 'foul') fouls[e.kind] = (fouls[e.kind] || 0) + 1;
      if (e.type === 'windup') atk[e.z] = (atk[e.z] || 0) + 1;
    }
    for (const r of s.riders) if (!Number.isFinite(r.x + r.v + r.balance + r.aimH + r.line)) { failures++; console.log('NaN', r); break; }
  }
  if (s.phase !== 'matchEnd') { failures++; console.log('did not finish', w0, w1, seed, s.phase, s.crossings); }
  verdicts[s.verdict.split(':')[0] + (s.verdict.includes(':') ? ':' + s.verdict.split(':')[1] : '')] = (verdicts[s.verdict] || 0) + 1;
  const k = w0 + ' vs ' + w1; byPair[k] = byPair[k] || { p1: 0, n: 0 }; byPair[k].n++;
  if (s.matchWinner === 0) { p1wins++; byPair[k].p1++; }
  secs += ticks * TICK; n++;
}
console.log(`level ${LVL}: ${n} matches, avg ${(secs / n).toFixed(0)} s, failures ${failures}, P1 win rate ${(p1wins / n).toFixed(2)}`);
console.log('by pairing (P1 win rate):', Object.fromEntries(Object.entries(byPair).map(([k, v]) => [k, +(v.p1 / v.n).toFixed(2)])));
console.log('verdicts', verdicts);
console.log('hit bands', bands, 'fouls', fouls, 'attacks', atk);
console.log('events', ev);
const need = ['windup', 'swing', 'hit', 'score', 'break', 'turn', 'turned', 'courseEnd', 'ko', 'crossing'];
const missing = need.filter(k => !ev[k]);
if (missing.length) { console.log('MISSING events:', missing.join(', ')); failures++; }
if (failures) process.exitCode = 1;
