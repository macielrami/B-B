// Renders the art-direction board frames straight from the engine (Reliquary look).
// usage: W=1920 H=1080 node tests/board-frames.mjs <outdir> [only,frames]
import { execFileSync } from 'node:child_process';
const out = process.argv[2] || '/tmp/claude-0/board';
const only = process.argv[3] ? process.argv[3].split(',') : null;

const setup = (riders, hud = false) => `(()=>{const A=window.__bb; A.quickStart({mode:'local', riders:${JSON.stringify(riders)}}); A.timeScale=0;
  const s=A.state; s.phase='fight'; s.timer=63; document.querySelector('#hud').hidden=${!hud}; document.querySelector('#hud-hint').hidden=true;
  A.camOverride=null; return 1})()`;
const post = `(()=>{const P=window.__bb.renderer && window.__bb; return 1})()`;
const rider = (i, o) => `(()=>{const r=window.__bb.state.riders[${i}]; Object.assign(r, ${JSON.stringify(o)}); return 1})()`;
const cam = (pos, look, fov) => `(()=>{window.__bb.camOverride={pos:${JSON.stringify(pos)}, look:${JSON.stringify(look)}, fov:${fov}}; return 1})()`;
const noBars = `(()=>{const p=window.__bbPost; return 1})()`;

const frames = {
  hero: [
    { eval: setup(['aldric', 'vorn']) },
    { eval: rider(0, { x: -7, v: 17, throttle: 1, drawn: 0, act: 'free' }) },
    { eval: rider(1, { x: 5, v: 17, throttle: 1, drawn: 0, act: 'free' }) },
    { eval: cam([1, 5.4, 27], [-2, 7.6, -10], 46) },
    { wait: 9000 }, { shot: 'hero' },
  ],
  read: [
    { eval: setup(['maelis', 'pilgrim'], true) },
    { eval: rider(0, { x: -3.0, v: 12, act: 'windup', zone: 'over', actT: 0.2, actDur: 9, drawn: 1, gear: 3, rpm: 0.86, stance: 'over', helmet: 70, shield: 90 }) },
    { eval: rider(1, { x: 3.0, v: 13, act: 'guard', zone: 'diag', actT: 0.2, drawn: 1, stance: 'diag', helmet: 40, shield: 55, sword: 45 }) },
    { wait: 9000 }, { shot: 'combat-read' },
  ],
  gate: [
    { eval: setup(['maelis', 'pilgrim'], true) },
    { eval: `(()=>{window.__bb.humans=[true,false]; return 1})()` },
    { eval: rider(0, { x: -4.4, v: 13, act: 'free', drawn: 1, armed: 1 }) },
    { eval: rider(1, { x: 4.4, v: 13, act: 'free', drawn: 0, throttle: 1 }) },
    { wait: 9000 }, { shot: 'gate' },
  ],
  parry: [
    { eval: setup(['aldric', 'vorn'], true) },
    { eval: rider(0, { x: -0.9, v: 8, act: 'stagger', actKind: 'parried', actT: 0.05, actDur: 9, zone: 'over', drawn: 1 }) },
    { eval: rider(1, { x: 0.9, v: 12, act: 'guard', zone: 'over', actT: 0.2, drawn: 1, riposteT: 1 }) },
    { wait: 7000 },
    { eval: `(()=>{window.__bb.emit({type:'parry', a:0, d:1, x:0, y:2.05, z:'over'}); return 1})()` },
    { wait: 1200 }, { shot: 'combat-parry' },
  ],
  helm: [
    { eval: setup(['pilgrim', 'maelis']) },
    { eval: rider(0, { x: 0.4, v: 10, act: 'active', zone: 'over', actT: 0.05, actDur: 9, drawn: 1 }) },
    { eval: rider(1, { x: 1.6, v: 10, act: 'stagger', actKind: 'flinch', actT: 0.05, actDur: 9, helmet: 0 }) },
    { eval: cam([1.2, 2.4, 7.5], [1.0, 1.9, 0], 34) },
    { wait: 7000 },
    { eval: `(()=>{const A=window.__bb; A.emit({type:'hit', a:0, d:1, x:1.0, y:2.05, z:'over', dmg:22, c:0.6}); A.emit({type:'equipBreak', r:1, item:'helmet', x:1.6}); return 1})()` },
    { wait: 1800 }, { shot: 'combat-helm' },
  ],
  ko: [
    { eval: setup(['vorn', 'aldric']) },
    { eval: rider(0, { x: -4, v: 9, act: 'recover', zone: 'horiz', actT: 0.05, actDur: 9, drawn: 1 }) },
    { eval: rider(1, { x: 2.5, v: 7, act: 'down', koKind: 'unhorsed', facing: -1 }) },
    { eval: cam([0.5, 3.2, 13], [0.5, 3.4, -2], 40) },
    { wait: 3500 },
    { eval: `(()=>{window.__bb.emit({type:'ko', r:1, kind:'unhorsed', x:2.5, w:0}); return 1})()` },
    { wait: 6000 }, { shot: 'combat-ko' },
  ],
  saint: [
    { eval: setup(['aldric', 'vorn']) },
    { eval: rider(0, { x: -30 }) }, { eval: rider(1, { x: 30 }) },
    { eval: cam([8, 12, -14], [15, 19, -42], 38) },
    { wait: 8000 }, { shot: 'detail-saint' },
  ],
  wheel: [
    { eval: setup(['aldric', 'vorn']) },
    { eval: rider(0, { x: -30 }) }, { eval: rider(1, { x: 30 }) },
    { eval: cam([-6, 9, -10], [-9, 13.5, -34], 40) },
    { wait: 8000 }, { shot: 'detail-wheel' },
  ],
  key: [
    { eval: setup(['aldric', 'vorn']) },
    { eval: rider(0, { x: -1.3, v: 18, act: 'active', zone: 'horiz', actT: 0.05, actDur: 9, drawn: 1 }) },
    { eval: rider(1, { x: 1.3, v: 18, act: 'active', zone: 'horiz', actT: 0.05, actDur: 9, drawn: 1 }) },
    { eval: cam([0.4, 3.2, 15.5], [-1.0, 5.3, -10], 42) },
    { wait: 8000 },
    { eval: `(()=>{const A=window.__bb, T=A.THREE, p=new T.Vector3(0, 1.6, 0); A.fx.burstSparks(p, 140, 11, 0xf6dcb4, 1.3); A.fx.flare(p, 0xf6dcb4, 0.9, 0.3); A.fx.sigils.spawn(p, 0xcc3a2e, 1.3, 1.4, { spin: 2, intensity: 1.6 }); A.fx.lights.flash(p, 0xeadcc0, 45, 1.4, 8); return 1})()` },
    { wait: 1500 }, { shot: 'keyart' },
  ],
};
for (const [id, r] of [['aldric', 'Aldric'], ['pilgrim', 'Pilgrim'], ['maelis', 'Maelis'], ['vorn', 'Vorn']]) {
  frames['rider-' + id] = [
    { eval: setup([id, id === 'vorn' ? 'aldric' : 'vorn']) },
    { eval: rider(0, { x: 0, v: 0, act: 'windup', zone: 'diag', actT: 0.3, actDur: 9, drawn: 1 }) },
    { eval: rider(1, { x: 40 }) },
    { eval: cam([0.25, 1.95, 5.0], [0, 1.6, -1.55], 32) },
    { wait: 7000 }, { shot: 'rider-' + id },
  ];
}

const steps = [{ until: 'window.__bb && window.__bb.screen==="title"', timeout: 150000 }];
for (const [k, list] of Object.entries(frames)) {
  if (only && !only.includes(k)) continue;
  steps.push(...list);
  steps.push({ eval: `(()=>{const A=window.__bb; if (A.mode) { A.camOverride=null; } return 1})()` });
}
execFileSync('node', ['tests/shoot.mjs', out, JSON.stringify(steps), 'test&board'], { stdio: 'inherit', env: { ...process.env } });
