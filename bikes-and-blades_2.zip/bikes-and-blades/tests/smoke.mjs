// Browser smoke test with real keyboard input through the actual UI.
// title → menu → how-to → settings → select (cycle rider/weapon) → match →
// ride, strike, guard → pause → resume → forfeit → menu.
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const URL = (process.env.URL || 'http://localhost:8787/') + '?test&quality=' + (process.env.Q || 'high');
const OUT = process.env.OUT || '/tmp/claude-0/smoke';
fs.mkdirSync(OUT, { recursive: true });
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
const errs = [];
page.on('pageerror', e => errs.push(e.message));
page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|404|fonts/.test(m.text())) errs.push(m.text()); });
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };
const screen = () => page.evaluate(() => window.__bb.screen);
// inputs are sampled once per rendered frame, so hold keys for whole frames
const frames = (n) => page.evaluate(n => new Promise(r => { let k = 0; const f = () => (++k >= n ? r() : requestAnimationFrame(f)); requestAnimationFrame(f); }), n);
const waitScreen = (s, t = 30000) => page.waitForFunction(x => window.__bb.screen === x, s, { timeout: t }).catch(() => {});

const t0 = Date.now();
await page.goto(URL);
await waitScreen('title', 120000);
ok(await screen() === 'title', `boots to the title screen (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
await page.keyboard.press('Space');
await waitScreen('menu');
ok(await screen() === 'menu', 'any key opens the main menu');
// keyboard navigation moves focus
await page.keyboard.press('ArrowDown');
const focused = await page.evaluate(() => document.activeElement && document.activeElement.dataset.act);
ok(focused === 'online', 'arrow keys move menu focus (now on ' + focused + ')');

await page.evaluate(() => document.querySelector('#s-menu [data-act=howto]').click());
await waitScreen('howto');
ok(await screen() === 'howto', 'How to Ride opens');
await page.keyboard.press('Escape');
await waitScreen('menu');
ok(await screen() === 'menu', 'Escape returns to the menu');
await page.evaluate(() => document.querySelector('#s-menu [data-act=settings]').click());
await waitScreen('settings');
await page.selectOption('#st-shake', '0.5');
const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('bikes-blades-settings-v1') || '{}').shake);
ok(saved === 0.5, 'settings persist (shake = ' + saved + ')');
await page.click('#st-back');

await page.evaluate(() => document.querySelector('#s-menu [data-act=bot]').click());
await waitScreen('select');
ok(await screen() === 'select', 'Duel the Hollow opens rider select');
const r0 = await page.evaluate(() => document.querySelector('#sel-p1 .rname').textContent);
await page.keyboard.press('KeyD');
const r1 = await page.evaluate(() => document.querySelector('#sel-p1 .rname').textContent);
ok(r0 !== r1, `D cycles riders (${r0} → ${r1})`);
const wp0 = await page.evaluate(() => document.querySelector('#sel-p1 .wname').textContent);
await page.keyboard.press('KeyS');
const wp1 = await page.evaluate(() => document.querySelector('#sel-p1 .wname').textContent);
ok(wp0 !== wp1, `S cycles weapons (${wp0} → ${wp1})`);
await page.keyboard.press('KeyW');
await page.evaluate(() => document.querySelector('#sel-diff [data-lvl="0"]').click());
await page.waitForTimeout(3000);
await page.screenshot({ path: OUT + '/select.png' });
await page.keyboard.press('Enter');
await page.waitForFunction(() => window.__bb.mode === 'bot', null, { timeout: 20000 }).catch(() => {});
ok(await page.evaluate(() => window.__bb.mode) === 'bot', 'Enter starts the match');
await page.waitForFunction(() => window.__bb.mode === 'bot' && window.__bb.state.phase === 'fight', null, { timeout: 420000 }).catch(() => {});
ok(await page.evaluate(() => window.__bb.mode === 'bot' && window.__bb.state.phase === 'fight'), 'intro and round call lead into the fight');

// riding: W is the gas, the gearbox shifts itself
await page.keyboard.down('KeyW');
await page.waitForFunction(() => window.__bb.state.riders[0].v > 3, null, { timeout: 120000 }).catch(() => {});
const v = await page.evaluate(() => window.__bb.state.riders[0].v);
ok(v > 3, 'holding W rides forward (v = ' + v.toFixed(1) + ')');
await page.waitForFunction(() => window.__bb.state.events.some(e => e.type === 'shift' && e.r === 0), null, { timeout: 120000 }).catch(() => {});
ok(await page.evaluate(() => window.__bb.state.events.some(e => e.type === 'shift' && e.r === 0)), 'the gearbox shifts up on its own');
// the line: A moves the bike toward the tilt
const l0 = await page.evaluate(() => window.__bb.state.riders[0].line);
await page.keyboard.down('KeyA'); await frames(4); await page.keyboard.up('KeyA');
const l1 = await page.evaluate(() => window.__bb.state.riders[0].line);
ok(l1 > l0, `A steers toward the tilt (line ${l0.toFixed(2)} → ${l1.toFixed(2)})`);
await page.keyboard.up('KeyW');
// the mouse aims: moving it up raises the weapon
await page.mouse.move(640, 600); await frames(3);
const hLow = await page.evaluate(() => window.__bb.state.riders[0].aimH);
await page.mouse.move(640, 80); await frames(6);
const hHigh = await page.evaluate(() => window.__bb.state.riders[0].aimH);
ok(hHigh > hLow, `moving the mouse up raises the weapon (aim ${hLow.toFixed(2)} → ${hHigh.toFixed(2)})`);
// click = a thrust; a downward flick = a smash (next course, so just check the type of the first)
const w0 = await page.evaluate(() => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 0).length);
await page.mouse.move(640, 300);
await page.mouse.down(); await frames(2); await page.mouse.move(640, 480, { steps: 3 }); await frames(1); await page.mouse.up();
await page.waitForFunction(b => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 0).length > b, w0, { timeout: 60000 }).catch(() => {});
const wu = await page.evaluate(() => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 0).slice(-1)[0]);
ok(wu && wu.z === 'smash', 'hold click, flick down, release = a smash (' + (wu && wu.z) + ')');
// a second attack in the same course is refused
await page.waitForFunction(() => ['free'].includes(window.__bb.state.riders[0].act), null, { timeout: 60000 }).catch(() => {});
await page.mouse.down(); await frames(1); await page.mouse.up(); await frames(3);
ok(await page.evaluate(() => window.__bb.state.events.some(e => e.type === 'spent' && e.r === 0)), 'one lance attack per course: the second is refused');
// the shield: right button
await page.mouse.down({ button: 'right' });
await page.waitForFunction(() => window.__bb.state.riders[0].shieldUp, null, { timeout: 60000 }).catch(() => {});
ok(await page.evaluate(() => window.__bb.state.riders[0].shieldUp), 'right click raises the shield');
await frames(2);
await page.mouse.up({ button: 'right' });
await page.screenshot({ path: OUT + '/fight.png' });

await page.keyboard.press('Escape');
await waitScreen('pause');
ok(await screen() === 'pause' && await page.evaluate(() => window.__bb.paused), 'Escape pauses');
const tPaused = await page.evaluate(() => window.__bb.state.time);
await page.waitForTimeout(2000);
ok(await page.evaluate(() => window.__bb.state.time) === tPaused, 'the simulation stops while paused');
await page.screenshot({ path: OUT + '/pause.png' });
await page.evaluate(() => document.querySelector('#s-pause [data-act=resume]').click());
ok(await screen() === 'match' && !(await page.evaluate(() => window.__bb.paused)), 'Resume continues the match');
await page.keyboard.press('Escape');
await waitScreen('pause');
await page.evaluate(() => document.querySelector('#s-pause [data-act=quit]').click());
await waitScreen('menu');
ok(await screen() === 'menu' && await page.evaluate(() => window.__bb.mode === null), 'Forfeit returns to the menu');
const calls = await page.evaluate(() => window.__bb.renderer.info.render.calls);
console.log('draw calls (menu backdrop):', calls);
ok(errs.length === 0, 'no page errors' + (errs.length ? ': ' + errs.slice(0, 5).join(' | ') : ''));
await browser.close();
