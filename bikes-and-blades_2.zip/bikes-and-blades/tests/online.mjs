// Online duel end-to-end over the bundled relay: two browser pages, host + guest.
// Checks: lobby code handshake, match start on both, guest input reaches the
// host's simulation, host snapshots reach the guest, positions agree.
import { chromium } from 'playwright-core';

const URL = (process.env.URL || 'http://localhost:8787/') + '?test&quality=low&speed=3';
const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const ctxA = await browser.newContext({ viewport: { width: 640, height: 360 } });
const ctxB = await browser.newContext({ viewport: { width: 640, height: 360 } });
const host = await ctxA.newPage(), guest = await ctxB.newPage();
const errs = [];
for (const [n, p] of [['host', host], ['guest', guest]]) p.on('pageerror', e => errs.push(n + ': ' + e.message));
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };

await Promise.all([host.goto(URL), guest.goto(URL)]);
for (const p of [host, guest]) await p.waitForFunction(() => window.__bb && window.__bb.screen === 'title', null, { timeout: 120000 });
for (const p of [host, guest]) {
  await p.bringToFront();
  await p.keyboard.press('Enter');
  await p.waitForFunction(() => window.__bb.screen === 'menu', null, { timeout: 240000 });
  await p.evaluate(() => document.querySelector('#s-menu [data-act=online]').click());
  await p.waitForFunction(() => window.__bb.screen === 'select', null, { timeout: 240000 });
}
// different riders on each side
await guest.evaluate(() => document.querySelector('#sel-p1 .rider .arrow[data-d="1"]').click());
for (const p of [host, guest]) { await p.evaluate(() => document.querySelector('#sel-go').click()); await p.waitForFunction(() => window.__bb.screen === "lobby", null, { timeout: 240000 }); }

await host.evaluate(() => document.querySelector('#lb-host').click());
await host.waitForFunction(() => !document.querySelector('#lb-code').hidden && document.querySelector('#lb-code').textContent.length === 4, null, { timeout: 120000 });
const code = await host.evaluate(() => document.querySelector('#lb-code').textContent);
ok(/^[A-Z]{4}$/.test(code), 'host shows a duel code: ' + code);
await guest.bringToFront();
await guest.waitForFunction(() => window.__bb.screen === 'lobby', null, { timeout: 120000 });
await guest.evaluate(c => { const el = document.querySelector('#lb-input'); el.value = c; el.dispatchEvent(new Event('input')); }, code);
await guest.evaluate(() => document.querySelector('#lb-join').click());

await host.waitForFunction(() => window.__bb.mode === 'online-host', null, { timeout: 240000 }).catch(() => {});
await guest.waitForFunction(() => window.__bb.mode === 'online-guest', null, { timeout: 240000 }).catch(() => {});
ok(await host.evaluate(() => window.__bb.mode) === 'online-host', 'host entered the match');
ok(await guest.evaluate(() => window.__bb.mode) === 'online-guest', 'guest entered the match');
const cfg = await guest.evaluate(() => window.__bb.state.cfg);
const hcfg = await host.evaluate(() => window.__bb.state.cfg);
ok(JSON.stringify(cfg.riders) === JSON.stringify(hcfg.riders), 'both sides agree on riders ' + JSON.stringify(hcfg.riders));

await host.waitForFunction(() => window.__bb.state.phase === 'fight', null, { timeout: 400000 });
await guest.waitForFunction(() => window.__bb.state.phase === 'fight', null, { timeout: 120000 }).catch(() => {});
ok(await guest.evaluate(() => window.__bb.state.phase) === 'fight', 'guest mirror reached the fight phase');

// guest rides on the throttle
await guest.bringToFront();
await guest.keyboard.down('KeyW');
await host.waitForFunction(() => window.__bb.state.riders[1].v > 2, null, { timeout: 90000 }).catch(() => {});
const hv = await host.evaluate(() => ({ v: window.__bb.state.riders[1].v, x: window.__bb.state.riders[1].x }));
ok(hv.v > 2, `guest throttle moved the host's P2 (v=${hv.v.toFixed(2)}, x=${hv.x.toFixed(2)})`);
// host rides too
await host.bringToFront();
await host.keyboard.down('KeyW');
await host.waitForTimeout(8000);
const hx = await host.evaluate(() => window.__bb.state.riders.map(r => r.x));
const gx = await guest.evaluate(() => window.__bb.state.riders.map(r => r.x));
ok(Math.abs(hx[0] - gx[0]) < 6 && Math.abs(hx[1] - gx[1]) < 6, `guest positions track the host (host ${hx.map(v => v.toFixed(1))} / guest ${gx.map(v => v.toFixed(1))})`);
// guest strike reaches the host sim
await guest.bringToFront();
await guest.keyboard.up('KeyW');
const before = await host.evaluate(() => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 1).length);
await guest.waitForTimeout(1500); await guest.keyboard.down('KeyU'); await guest.waitForTimeout(1500); await guest.keyboard.up('KeyU');
await host.waitForFunction(b => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 1).length > b, before, { timeout: 90000 }).catch(() => {});
const after = await host.evaluate(() => window.__bb.state.events.filter(e => e.type === 'windup' && e.r === 1).length);
ok(after > before, 'guest attack (U) triggered a wind-up on the host');
const gEvents = await guest.evaluate(() => window.__bb.state.events.length);
ok(gEvents > 0, 'guest received host events (' + gEvents + ')');
// guest leaves → host returns to menu
await guest.close();
await host.waitForFunction(() => window.__bb.screen === 'menu', null, { timeout: 90000 }).catch(() => {});
ok(await host.evaluate(() => window.__bb.screen) === 'menu', 'host is returned to the menu when the guest leaves');
ok(errs.length === 0, 'no page errors' + (errs.length ? ': ' + errs.join(' | ') : ''));
await browser.close();
