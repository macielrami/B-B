// Verifies the publishable page (dist/artifact.html): wraps it in the same kind of
// skeleton the artifact host adds, serves jsDelivr requests from node_modules,
// and checks the game boots and a match starts with three.js loaded via import map.
import { chromium } from 'playwright-core';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const page0 = fs.readFileSync(path.join(root, 'dist/artifact.html'), 'utf8');
const html = '<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1,viewport-fit=cover"><style>:root{color-scheme:light;padding:env(safe-area-inset-top) 0 env(safe-area-inset-bottom)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style></head><body>' + page0 + '</body></html>';

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
});
const page = await browser.newPage({ viewport: { width: 960, height: 540 } });
const errs = [], cdn = [];
page.on('pageerror', e => errs.push(e.message));
page.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|fonts|404/.test(m.text())) errs.push(m.text()); });
await page.route('https://cdn.jsdelivr.net/npm/three@0.170.0/**', route => {
  const rel = route.request().url().split('/npm/three@0.170.0/')[1];
  cdn.push(rel);
  route.fulfill({ path: path.join(root, 'node_modules/three', rel), contentType: 'text/javascript', headers: { 'access-control-allow-origin': '*' } });
});
await page.route(u => u.hostname === 'artifact.test', route => route.fulfill({ body: html, contentType: 'text/html' }));
const ok = (c, m) => { console.log((c ? 'PASS ' : 'FAIL ') + m); if (!c) process.exitCode = 1; };

await page.goto('https://artifact.test/?test&quality=low');
await page.waitForFunction(() => window.__bb && window.__bb.screen === 'title', null, { timeout: 180000 }).catch(() => {});
ok(await page.evaluate(() => window.__bb && window.__bb.screen) === 'title', 'artifact page boots to the title');
ok(cdn.some(u => u.includes('build/three.module')), 'three.js core came through the import map: ' + cdn.filter(u => u.includes('build/')).join(', '));
ok(cdn.some(u => u.includes('examples/jsm/geometries/RoundedBoxGeometry.js')) && cdn.some(u => u.includes('BufferGeometryUtils')), 'addons resolved through the import map (' + cdn.length + ' files)');
await page.evaluate(() => window.__bb.quickStart({ mode: 'bot' }));
await page.waitForTimeout(4000);
ok(await page.evaluate(() => window.__bb.mode) === 'bot', 'a match starts in the artifact build');
ok(errs.length === 0, 'no page errors' + (errs.length ? ': ' + errs.join(' | ') : ''));
await browser.close();
