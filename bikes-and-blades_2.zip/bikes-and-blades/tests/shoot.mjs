// Launches the built game in headless Chromium (SwiftShader WebGL2), runs a
// script of steps, saves screenshots and reports console errors.
// usage: node tests/shoot.mjs <outdir> '<json steps>' [query]
//   steps: [{wait: ms} | {shot: name} | {eval: "js"} | {key: "KeyJ", down?:bool, up?:bool} | {click: selector}]
import { chromium } from 'playwright-core';
import fs from 'node:fs';

const [outDir = 'shots', stepsJson = '[]', query = 'test'] = process.argv.slice(2);
const steps = JSON.parse(stepsJson);
fs.mkdirSync(outDir, { recursive: true });
const W = +(process.env.W || 1280), H = +(process.env.H || 720);

const browser = await chromium.launch({
  executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome',
  args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'],
});
const page = await browser.newPage({ viewport: { width: W, height: H } });
const errors = [];
page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') errors.push(`[${m.type()}] ${m.text()}`); if (process.env.LOG) console.log('console:', m.text()); });
page.on('pageerror', e => errors.push('[pageerror] ' + e.message + '\n' + (e.stack || '').split('\n').slice(0, 4).join('\n')));
const url = (process.env.URL || 'http://localhost:8787/') + '?' + query;
const t0 = Date.now();
await page.goto(url);
for (const s of steps) {
  if (s.wait) await page.waitForTimeout(s.wait);
  if (s.until) { await page.waitForFunction(s.until, null, { timeout: s.timeout || 60000, polling: 250 }).catch(e => errors.push('[until timeout] ' + s.until)); }
  if (s.eval) { const r = await page.evaluate(s.eval).catch(e => 'ERR ' + e.message); if (r !== undefined) console.log('eval>', typeof r === 'string' ? r : JSON.stringify(r)); }
  if (s.key) { if (s.down) await page.keyboard.down(s.key); else if (s.up) await page.keyboard.up(s.key); else await page.keyboard.press(s.key); }
  if (s.click) await page.click(s.click).catch(e => errors.push('[click] ' + s.click + ' ' + e.message));
  if (s.shot) { await page.screenshot({ path: `${outDir}/${s.shot}.png` }); console.log('shot', s.shot, ((Date.now() - t0) / 1000).toFixed(1) + 's'); }
}
const fps = await page.evaluate(() => window.__fps || null).catch(() => null);
console.log('errors:', errors.length ? '\n' + errors.slice(0, 30).join('\n') : 'none');
await browser.close();
