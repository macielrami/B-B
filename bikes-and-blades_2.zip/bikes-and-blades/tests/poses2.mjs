// Pose gallery for the v2 combat: every strike line (wind-up + strike), every
// shield position, and riding on the throttle with the sword sheathed.
import { execFileSync } from 'node:child_process';
const out = process.argv[2] || '/tmp/claude-0/poses2';
const rider = process.argv[3] || 'aldric';
const poses = (process.argv[4] || 'throttle:horiz,windup:horiz,active:horiz,windup:diag,active:diag,windup:over,active:over,windup:low,active:low,windup:back,active:back,guard:over,guard:diag,guard:horiz,guard:low,guard:back').split(',');
const steps = [
  { until: 'window.__bb && window.__bb.screen==="title"', timeout: 120000 },
  { eval: `(()=>{const A=window.__bb; A.quickStart({mode:'local', riders:['${rider}','vorn']}); A.timeScale=0; const s=A.state; s.phase='fight'; s.riders[0].x=0; s.riders[1].x=40; document.querySelector('#hud').hidden=true; A.camOverride={pos:[0.3,1.95,5.2], look:[0,1.55,-1.55], fov:32}; return 1})()` },
];
for (const p of poses) {
  const [act, z] = p.split(':');
  steps.push({ eval: `(()=>{const r=window.__bb.state.riders[0]; r.act='${act === 'throttle' ? 'free' : act}'; r.zone='${z}'; r.stance='${z}'; r.actT=${act === 'active' ? 0.05 : 0.1}; r.actDur=9; r.drawn=${act === 'throttle' ? 0 : 1}; r.throttle=${act === 'throttle' ? 1 : 0}; return 1})()` });
  steps.push({ wait: 3500 });
  steps.push({ shot: `${rider}-${act}-${z}` });
}
execFileSync('node', ['tests/shoot.mjs', out, JSON.stringify(steps), 'test'], { stdio: 'inherit' });
