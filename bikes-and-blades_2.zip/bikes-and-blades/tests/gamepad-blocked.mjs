// Serve the artifact page inside an iframe whose permissions policy forbids gamepads.
import { chromium } from 'playwright-core';
import http from 'node:http'; import fs from 'node:fs';
const html = fs.readFileSync('/home/claude/bikes-and-blades/dist/index.html');
const srv = http.createServer((q, r) => {
  if (q.url.startsWith('/game')) { r.setHeader('Permissions-Policy', 'gamepad=()'); r.end(html); }
  else r.end('<iframe src="/game?test&quality=low" allow="" style="width:1200px;height:700px"></iframe>');
}).listen(8899);
const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome', args: ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage(); const errs = [];
p.on('pageerror', e => errs.push(e.message)); p.on('console', m => { if (m.type() === 'error' && !/Failed to load/.test(m.text())) errs.push(m.text()); });
await p.goto('http://localhost:8899/');
const f = () => p.frames().find(x => x.url().includes('/game'));
await new Promise(r => setTimeout(r, 3000));
await f().waitForFunction(() => window.__bb && window.__bb.screen === 'title', null, { timeout: 120000 });
const blocked = await f().evaluate(() => { try { navigator.getGamepads(); return 'allowed'; } catch (e) { return 'blocked: ' + e.name; } });
await f().evaluate(() => window.__bb.quickStart({ mode: 'bot' }));
await f().waitForFunction(() => window.__bb.state.phase === 'fight', null, { timeout: 300000 });
await new Promise(r => setTimeout(r, 4000));
console.log('gamepad API in frame:', blocked, '| phase:', await f().evaluate(() => window.__bb.state.phase), '| errors:', errs.length ? errs : 'none');
await b.close(); srv.close();
